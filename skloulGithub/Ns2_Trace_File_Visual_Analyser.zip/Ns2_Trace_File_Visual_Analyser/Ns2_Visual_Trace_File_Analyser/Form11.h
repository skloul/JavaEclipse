#pragma once
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <cstring>
#include "stdafx.h"




    
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

namespace KB950617 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
    private: String^ windir;
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			windir = System::Environment::GetEnvironmentVariable("windir");
        
			//
		}
 
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::ListBox^  listBox1;
	
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(12, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 42);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Read Text File";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(12, 60);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 42);
			this->button2->TabIndex = 2;
			this->button2->Text = L"Write Text File";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(12, 108);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 42);
			this->button3->TabIndex = 3;
			this->button3->Text = L"View File Information";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(12, 156);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 42);
			this->button4->TabIndex = 4;
			this->button4->Text = L"List Drives";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(12, 204);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 42);
			this->button5->TabIndex = 5;
			this->button5->Text = L"List Subfolders";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(12, 252);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(75, 42);
			this->button6->TabIndex = 0;
			this->button6->Text = L"List Files";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// listBox1
			// 
			this->listBox1->FormattingEnabled = true;
			this->listBox1->Location = System::Drawing::Point(106, 12);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(496, 394);
			this->listBox1->TabIndex = 6;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(704, 432);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
					// How to read a text file:
					// Use try...catch to deal with a 0-byte file or a nonexistent file.
					// char x='T';
					 int count=0;
					 int S_count=0;
					 int R_count=0;
					 int D_count=0;
					 int M_count=0;
					 int F_count=0;
			        listBox1->Items->Clear();
					try {
						StreamReader^ reader = gcnew StreamReader("c:\\MDVZRP.tr");
						 array<Char>^c = nullptr;
						do
						{
							 //listBox1->Items->Add(reader->ReadLine());
							   /*listBox1->Items->Add( (Char)reader->Read() );
								if( (Char)reader->Read() ==x)
									count++;*/
							 //This is an arbitrary size for this example.
								/*char str3[30]="";
								strncat(str3,str2,MAXSTRINGLEN-1);
								String ^text= gcnew String(str3);
								textBox1->Text=System::Convert::ToString(text);*/

							 
							 //size_t len;
							 //size_t maxsize = 100;
     					     //len = strlen(str1);

							//int numLine = strLen(line);
					        // c = gcnew array<Char>(80);
							 //reader->Read( c, 0, c->Length );
							 
								//The output will look odd, because
								//only five characters are read at a time.
								String ^str1= System::Convert::ToString(reader->ReadLine());
								listBox1->Items->Add(str1[2]);
								if( str1[0]=='s')
							       S_count++;
								if( str1[0]=='r')
							       R_count++;
								if( str1[0]=='d')
							       D_count++;
								if( str1[0]=='f')
							       F_count++;
								if( str1[0]=='M')
							       M_count++;
								count++;
							   
						}
						while(reader->Peek() != -1);
						//listBox1->Items->Add(String::Concat("Ther are " ,count," ", x));
						
						listBox1->Items->Add(String::Concat("Total Packets= ",count,'\n',"  Send= " ,S_count,"  Receive= " ,R_count,"\n","  Drop= " ,D_count,"\n","  Fail= " ,F_count,"\n","  M= " ,M_count));
					}
					catch(FileNotFoundException^ ex)
					{
						listBox1->Items->Add(ex);
					}
					catch(System::Exception^ e)
					{
						listBox1->Items->Add(e);
					}
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
// This shows you how to create and to write to a text file.
StreamWriter^ pwriter = gcnew StreamWriter("c:\\KBTest.txt");
pwriter->WriteLine("The file was created by using the StreamWriter class.");
pwriter->Close();
listBox1->Items->Clear();
String^ filew = gcnew String("File written to c:\\KBTest.txt");
listBox1->Items->Add(filew);

		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
// This code retrieves file properties. The example uses Notepad.exe.
listBox1->Items->Clear();
String^ testfile = String::Concat(windir,"\\notepad.exe");
FileInfo^ pFileProps = gcnew FileInfo(testfile);

listBox1->Items->Add(String::Concat("File Name = ", pFileProps->FullName));
listBox1->Items->Add(String::Concat("Creation Time = ", pFileProps->CreationTime.ToString()));
listBox1->Items->Add(String::Concat("Last Access Time = ", pFileProps->LastAccessTime.ToString()));
listBox1->Items->Add(String::Concat("Last Write Time = ", pFileProps->LastWriteTime.ToString()));
listBox1->Items->Add(String::Concat("Size = ", pFileProps->Length.ToString()));
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
// This shows you how to obtain a list of disk drivers.
listBox1->Items->Clear();
cli::array<String^>^ drives = Directory::GetLogicalDrives();
int numDrives = drives->Length;
for(int i=0; i<numDrives; i++)
{
    listBox1->Items->Add(drives[i]);
}
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
// This code obtains a list of folders. This example uses the Windows folder.
listBox1->Items->Clear();
cli::array<String^>^ dirs = Directory::GetDirectories(windir);
int numDirs = dirs->Length;
for(int i=0; i<numDirs; i++)
{
    listBox1->Items->Add(dirs[i]);
}

	 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
// This code obtains a list of files. This example uses the Windows folder.
listBox1->Items->Clear();
cli::array<String^>^ files = Directory::GetFiles(windir);
int numFiles = files->Length;
for(int i=0; i<numFiles; i++)
{
    listBox1->Items->Add(files[i]);
}

		 }
};
}

