#pragma once
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <cstring>
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

namespace Ns2_Visual_Trace_File_Analyser{

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	
	int Simulation_Packet_Counter;
    int routing_packets;
    double  Total_Sent_Pkt;
    double  Total_Received_Pkt;
	double  Control_Total_pkt;
    int Total_Dropped_Packets;
	int Total_Dropped_Bytes;
	double NRL;
	double PDF;
	double Throughput;
    double EEDelay;
	double Total_lost;
	double startTime;	  // for throughput
    double stopTime;	  // for throughput 
    int File_num=0;
    bool file_read=false;
	bool file_select=false;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	private: String^ windir;
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			windir = System::Environment::GetEnvironmentVariable("windir");
            
			//
		}
 
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Select_Trace_File_button;
	protected: 



	protected: 



	protected: 

	protected: 





	private: System::Windows::Forms::ListBox^  listBox1;

	private: System::Windows::Forms::Timer^  timer1;

	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::ProgressBar^  progressBar1;
	private: System::Windows::Forms::Label^  label_Record;
	private: System::Windows::Forms::Button^  Start_Analysis_button;




	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::CheckBox^  checkBox_DropBytes;

	private: System::Windows::Forms::CheckBox^  checkBox_RecvPkt;

	private: System::Windows::Forms::CheckBox^  checkBox_SentPkt;
	private: System::Windows::Forms::CheckBox^  checkBox_LostPkt;


	private: System::Windows::Forms::CheckBox^  checkBox_DropPkt;
	private: System::Windows::Forms::CheckBox^  checkBox_SimTime;


	private: System::Windows::Forms::CheckBox^  checkBox_PDF;
	private: System::Windows::Forms::CheckBox^  checkBox_NRL;
	private: System::Windows::Forms::CheckBox^  checkBox_RoutingPkt;



	private: System::Windows::Forms::CheckBox^  checkBox_EED;
	private: System::Windows::Forms::CheckBox^  checkBox_Fileinformation;
	private: System::Windows::Forms::CheckBox^  checkBox_Records;



	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Button^  Clearall_button;

	private: System::Windows::Forms::Button^  Most_used_Metrics_button;
	private: System::Windows::Forms::Button^  Set_all_Metrics_button;



	private: System::Windows::Forms::Button^  Text_Board_clear_button;



	private: System::Windows::Forms::GroupBox^  groupBox_SystemTime;

	private: System::Windows::Forms::CheckBox^  checkBox_Sys_Date;

	private: System::Windows::Forms::Label^  label_Sys_Date;

	private: System::Windows::Forms::Timer^  timer2;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::Label^  label1;



	private: System::Windows::Forms::GroupBox^  groupBox6;
	private: System::Windows::Forms::Button^  Perormance_Comparison_button;







private: System::Windows::Forms::FolderBrowserDialog^  folderBrowserDialog1;
private: System::Windows::Forms::GroupBox^  Process_Notes;
private: System::Windows::Forms::RadioButton^  radioButton_Read_error;




private: System::Windows::Forms::RadioButton^  radioButton_write_error;

private: System::Windows::Forms::GroupBox^  groupBox8;
private: System::Windows::Forms::RadioButton^  radioButton_Results_save;



private: System::Windows::Forms::RadioButton^  radioButton_Startselect;
private: System::Windows::Forms::RadioButton^  radioButton_Perfoprmance;


private: System::Windows::Forms::RadioButton^  radioButton_Fileselect;

private: System::Windows::Forms::TabPage^  tabPage1;
private: System::Windows::Forms::Label^  label5;
private: System::Windows::Forms::Label^  label6;
private: System::Windows::Forms::Label^  label7;
private: System::Windows::Forms::TabPage^  tabPage7;
private: System::Windows::Forms::CheckBox^  checkBox41;
private: System::Windows::Forms::CheckBox^  checkBox42;
private: System::Windows::Forms::CheckBox^  checkBox43;
private: System::Windows::Forms::CheckBox^  checkBox44;
private: System::Windows::Forms::CheckBox^  checkBox45;
private: System::Windows::Forms::CheckBox^  checkBox46;
private: System::Windows::Forms::CheckBox^  checkBox47;
private: System::Windows::Forms::CheckBox^  checkBox48;
private: System::Windows::Forms::CheckBox^  checkBox49;
private: System::Windows::Forms::CheckBox^  checkBox50;
private: System::Windows::Forms::TabPage^  tabPage8;
private: System::Windows::Forms::CheckBox^  checkBox51;
private: System::Windows::Forms::CheckBox^  checkBox52;
private: System::Windows::Forms::CheckBox^  checkBox53;
private: System::Windows::Forms::CheckBox^  checkBox54;
private: System::Windows::Forms::CheckBox^  checkBox55;
private: System::Windows::Forms::CheckBox^  checkBox56;
private: System::Windows::Forms::CheckBox^  checkBox57;
private: System::Windows::Forms::CheckBox^  checkBox58;
private: System::Windows::Forms::CheckBox^  checkBox59;
private: System::Windows::Forms::CheckBox^  checkBox60;
private: System::Windows::Forms::TabPage^  tabPage9;
private: System::Windows::Forms::CheckBox^  checkBox61;
private: System::Windows::Forms::CheckBox^  checkBox62;
private: System::Windows::Forms::CheckBox^  checkBox63;
private: System::Windows::Forms::CheckBox^  checkBox64;
private: System::Windows::Forms::CheckBox^  checkBox65;
private: System::Windows::Forms::CheckBox^  checkBox66;
private: System::Windows::Forms::CheckBox^  checkBox67;
private: System::Windows::Forms::CheckBox^  checkBox68;
private: System::Windows::Forms::CheckBox^  checkBox69;
private: System::Windows::Forms::CheckBox^  checkBox70;
private: System::Windows::Forms::TabPage^  tabPage10;
private: System::Windows::Forms::CheckBox^  checkBox71;
private: System::Windows::Forms::CheckBox^  checkBox72;
private: System::Windows::Forms::CheckBox^  checkBox73;
private: System::Windows::Forms::CheckBox^  checkBox74;
private: System::Windows::Forms::CheckBox^  checkBox75;
private: System::Windows::Forms::CheckBox^  checkBox76;
private: System::Windows::Forms::CheckBox^  checkBox77;
private: System::Windows::Forms::CheckBox^  checkBox78;
private: System::Windows::Forms::CheckBox^  checkBox79;
private: System::Windows::Forms::CheckBox^  checkBox80;
private: System::Windows::Forms::CheckBox^  checkBox81;
private: System::Windows::Forms::CheckBox^  checkBox82;
private: System::Windows::Forms::CheckBox^  checkBox83;
private: System::Windows::Forms::CheckBox^  checkBox84;
private: System::Windows::Forms::CheckBox^  checkBox85;
private: System::Windows::Forms::CheckBox^  checkBox86;
private: System::Windows::Forms::CheckBox^  checkBox87;
private: System::Windows::Forms::CheckBox^  checkBox88;
private: System::Windows::Forms::CheckBox^  checkBox89;
private: System::Windows::Forms::CheckBox^  checkBox90;



private: System::Windows::Forms::CheckBox^  checkBox91;
private: System::Windows::Forms::CheckBox^  checkBox92;
private: System::Windows::Forms::CheckBox^  checkBox93;
private: System::Windows::Forms::CheckBox^  checkBox94;
private: System::Windows::Forms::CheckBox^  checkBox95;
private: System::Windows::Forms::CheckBox^  checkBox96;
private: System::Windows::Forms::CheckBox^  checkBox97;
private: System::Windows::Forms::CheckBox^  checkBox98;
private: System::Windows::Forms::CheckBox^  checkBox99;
private: System::Windows::Forms::CheckBox^  checkBox100;






























private: System::Windows::Forms::TabPage^  tabPage4;
private: System::Windows::Forms::Label^  label19;
private: System::Windows::Forms::Label^  label20;
private: System::Windows::Forms::Label^  label21;
private: System::Windows::Forms::TabPage^  tabPage5;
private: System::Windows::Forms::Label^  label22;
private: System::Windows::Forms::Label^  label23;
private: System::Windows::Forms::Label^  label24;
private: System::Windows::Forms::Label^  label25;
private: System::Windows::Forms::Label^  label26;
private: System::Windows::Forms::Label^  label27;
private: System::Windows::Forms::Label^  label28;
private: System::Windows::Forms::Label^  label29;
private: System::Windows::Forms::Label^  label30;
private: System::Windows::Forms::Label^  label31;
private: System::Windows::Forms::Label^  label32;
private: System::Windows::Forms::CheckBox^  checkBox1;
private: System::Windows::Forms::CheckBox^  checkBox2;
private: System::Windows::Forms::CheckBox^  checkBox3;
private: System::Windows::Forms::CheckBox^  checkBox4;
private: System::Windows::Forms::CheckBox^  checkBox5;
private: System::Windows::Forms::CheckBox^  checkBox6;
private: System::Windows::Forms::CheckBox^  checkBox7;
private: System::Windows::Forms::CheckBox^  checkBox8;
private: System::Windows::Forms::CheckBox^  checkBox9;
private: System::Windows::Forms::CheckBox^  checkBox10;
private: System::Windows::Forms::CheckBox^  checkBox11;
private: System::Windows::Forms::Button^  Tab_Pages_clear_button;





























 









//private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_2;
//private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_2;


//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;













private: System::Windows::Forms::CheckBox^  checkBox12;
private: System::Windows::Forms::Label^  label33;
private: System::Windows::Forms::Label^  label34;
private: System::Windows::Forms::CheckBox^  checkBox13;
private: System::Windows::Forms::Label^  label35;
private: System::Windows::Forms::Label^  label36;
private: System::Windows::Forms::Label^  label37;
private: System::Windows::Forms::Label^  label38;
private: System::Windows::Forms::Label^  label39;
private: System::Windows::Forms::Label^  label40;
private: System::Windows::Forms::Label^  label41;
private: System::Windows::Forms::Label^  label42;
private: System::Windows::Forms::Label^  label43;
private: System::Windows::Forms::Label^  label44;
private: System::Windows::Forms::CheckBox^  checkBox14;
private: System::Windows::Forms::Label^  label45;
private: System::Windows::Forms::CheckBox^  checkBox15;
private: System::Windows::Forms::CheckBox^  checkBox16;
private: System::Windows::Forms::CheckBox^  checkBox17;
private: System::Windows::Forms::CheckBox^  checkBox18;
private: System::Windows::Forms::CheckBox^  checkBox19;
private: System::Windows::Forms::CheckBox^  checkBox20;
private: System::Windows::Forms::CheckBox^  checkBox21;
private: System::Windows::Forms::CheckBox^  checkBox22;
private: System::Windows::Forms::CheckBox^  checkBox23;
private: System::Windows::Forms::CheckBox^  checkBox24;
private: System::Windows::Forms::CheckBox^  checkBox25;
private: System::Windows::Forms::Label^  label46;
private: System::Windows::Forms::Label^  label47;
private: System::Windows::Forms::CheckBox^  checkBox26;
private: System::Windows::Forms::Label^  label48;
private: System::Windows::Forms::Label^  label49;
private: System::Windows::Forms::Label^  label50;
private: System::Windows::Forms::Label^  label51;
private: System::Windows::Forms::Label^  label52;
private: System::Windows::Forms::Label^  label53;
private: System::Windows::Forms::Label^  label54;
private: System::Windows::Forms::Label^  label55;
private: System::Windows::Forms::Label^  label56;
private: System::Windows::Forms::Label^  label57;
private: System::Windows::Forms::CheckBox^  checkBox27;
private: System::Windows::Forms::Label^  label58;
private: System::Windows::Forms::CheckBox^  checkBox28;
private: System::Windows::Forms::CheckBox^  checkBox29;
private: System::Windows::Forms::CheckBox^  checkBox30;
private: System::Windows::Forms::CheckBox^  checkBox31;
private: System::Windows::Forms::CheckBox^  checkBox32;
private: System::Windows::Forms::CheckBox^  checkBox33;
private: System::Windows::Forms::CheckBox^  checkBox34;
private: System::Windows::Forms::CheckBox^  checkBox35;
private: System::Windows::Forms::CheckBox^  checkBox36;
private: System::Windows::Forms::CheckBox^  checkBox37;
private: System::Windows::Forms::CheckBox^  checkBox38;
private: System::Windows::Forms::Label^  label59;
private: System::Windows::Forms::CheckBox^  checkBox39;
private: System::Windows::Forms::Label^  label60;
private: System::Windows::Forms::Label^  label61;
private: System::Windows::Forms::Label^  label62;
private: System::Windows::Forms::Label^  label63;
private: System::Windows::Forms::Label^  label64;
private: System::Windows::Forms::Label^  label65;
private: System::Windows::Forms::Label^  label66;
private: System::Windows::Forms::Label^  label67;
private: System::Windows::Forms::Label^  label68;
private: System::Windows::Forms::Label^  label69;
private: System::Windows::Forms::Label^  label70;
private: System::Windows::Forms::Label^  label71;
private: System::Windows::Forms::CheckBox^  checkBox40;
private: System::Windows::Forms::CheckBox^  checkBox101;
private: System::Windows::Forms::CheckBox^  checkBox102;
private: System::Windows::Forms::CheckBox^  checkBox103;
private: System::Windows::Forms::CheckBox^  checkBox104;
private: System::Windows::Forms::CheckBox^  checkBox105;
private: System::Windows::Forms::CheckBox^  checkBox106;
private: System::Windows::Forms::CheckBox^  checkBox107;
private: System::Windows::Forms::CheckBox^  checkBox108;
private: System::Windows::Forms::CheckBox^  checkBox109;
private: System::Windows::Forms::CheckBox^  checkBox110;
private: System::Windows::Forms::CheckBox^  checkBox111;
private: System::Windows::Forms::Label^  label72;
private: System::Windows::Forms::CheckBox^  checkBox112;
private: System::Windows::Forms::Label^  label73;
private: System::Windows::Forms::Label^  label74;
private: System::Windows::Forms::Label^  label75;
private: System::Windows::Forms::Label^  label76;
private: System::Windows::Forms::Label^  label77;
private: System::Windows::Forms::Label^  label78;
private: System::Windows::Forms::Label^  label79;
private: System::Windows::Forms::Label^  label80;
private: System::Windows::Forms::Label^  label81;
private: System::Windows::Forms::Label^  label82;
private: System::Windows::Forms::Label^  label83;
private: System::Windows::Forms::Label^  label84;
private: System::Windows::Forms::CheckBox^  checkBox113;
private: System::Windows::Forms::CheckBox^  checkBox114;
private: System::Windows::Forms::CheckBox^  checkBox115;
private: System::Windows::Forms::CheckBox^  checkBox117;
private: System::Windows::Forms::CheckBox^  checkBox118;
private: System::Windows::Forms::CheckBox^  checkBox119;
private: System::Windows::Forms::CheckBox^  checkBox120;
private: System::Windows::Forms::CheckBox^  checkBox121;
private: System::Windows::Forms::CheckBox^  checkBox122;
private: System::Windows::Forms::CheckBox^  checkBox123;
private: System::Windows::Forms::CheckBox^  checkBox124;
private: System::Windows::Forms::RadioButton^  radioButton_Startanalysis;
private: System::Windows::Forms::GroupBox^  groupBox9;
private: System::Windows::Forms::Label^  label98;
private: System::Windows::Forms::Label^  label99;
private: System::Windows::Forms::GroupBox^  groupBox_PDF;

private: System::Windows::Forms::ProgressBar^  progressBar2;
private: System::Windows::Forms::Label^  File3_bar;
private: System::Windows::Forms::Label^  File2_bar;
private: System::Windows::Forms::Label^  File1_bar;
private: System::Windows::Forms::ProgressBar^  progressBar4;
private: System::Windows::Forms::ProgressBar^  progressBar3;
private: System::Windows::Forms::RichTextBox^  richTextBox1;
private: System::Windows::Forms::GroupBox^  groupBox_Results_graphics;
private: System::Windows::Forms::GroupBox^  groupBox_EED;

private: System::Windows::Forms::RichTextBox^  richTextBox3;
private: System::Windows::Forms::Label^  label97;
private: System::Windows::Forms::Label^  label100;
private: System::Windows::Forms::Label^  label101;
private: System::Windows::Forms::ProgressBar^  progressBar8;
private: System::Windows::Forms::ProgressBar^  progressBar9;
private: System::Windows::Forms::ProgressBar^  progressBar10;
private: System::Windows::Forms::GroupBox^  groupBox_DropPkts;











private: System::Windows::Forms::Label^  label108;
private: System::Windows::Forms::Label^  label109;
private: System::Windows::Forms::Label^  label110;
private: System::Windows::Forms::ProgressBar^  progressBar17;
private: System::Windows::Forms::ProgressBar^  progressBar18;
private: System::Windows::Forms::ProgressBar^  progressBar19;
private: System::Windows::Forms::GroupBox^  groupBox_OH;









private: System::Windows::Forms::RichTextBox^  richTextBox4;
private: System::Windows::Forms::Label^  label102;
private: System::Windows::Forms::Label^  label103;
private: System::Windows::Forms::Label^  label104;
private: System::Windows::Forms::ProgressBar^  progressBar11;
private: System::Windows::Forms::ProgressBar^  progressBar12;
private: System::Windows::Forms::ProgressBar^  progressBar13;










//private: System::Windows::Forms::CheckBox^  checkBox_Overh_3;

//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;


//private: System::Windows::Forms::CheckBox^  checkBox_Overh_3;
//private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;




//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_2;
//private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;


//private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_2;
//private: System::Windows::Forms::Label^  label_Filename_3;

		 //private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;



//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;
//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;

private: System::Windows::Forms::CheckBox^  checkBox143;
private: System::Windows::Forms::CheckBox^  checkBox144;





//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_2;




//private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_2;



private: System::Windows::Forms::RichTextBox^  richTextBox6;
private: System::Windows::Forms::GroupBox^  groupBox_Throughput;
















private: System::Windows::Forms::RichTextBox^  richTextBox5;
private: System::Windows::Forms::Label^  label105;
private: System::Windows::Forms::Label^  label106;
private: System::Windows::Forms::Label^  label107;
private: System::Windows::Forms::ProgressBar^  progressBar14;
private: System::Windows::Forms::ProgressBar^  progressBar15;
private: System::Windows::Forms::ProgressBar^  progressBar16;
private: System::Windows::Forms::GroupBox^  groupBox_NRL;

private: System::Windows::Forms::RichTextBox^  richTextBox2;
private: System::Windows::Forms::Label^  label8;
private: System::Windows::Forms::Label^  label85;
private: System::Windows::Forms::Label^  label96;
private: System::Windows::Forms::ProgressBar^  progressBar5;
private: System::Windows::Forms::ProgressBar^  progressBar6;
private: System::Windows::Forms::ProgressBar^  progressBar7;
private: System::Windows::Forms::MenuStrip^  menuStrip1;
private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;

private: System::Windows::Forms::ToolStripMenuItem^  printToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  saveAsToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  OpentoolStripMenuItem;

private: System::Windows::Forms::GroupBox^  groupBox5;
private: System::Windows::Forms::GroupBox^  groupBox7;
private: System::Windows::Forms::PictureBox^  pictureBox1;


private: System::Windows::Forms::ToolStripMenuItem^  resultsTabPagesToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  textBoardToolStripMenuItem;

private: System::Windows::Forms::ToolStripMenuItem^  performanceProgressToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  systemTimeToolStripMenuItem;
private: System::Windows::Forms::TabPage^  tabPage11;
private: System::Windows::Forms::Label^  label118;
private: System::Windows::Forms::CheckBox^  checkBox_Overh_3;
private: System::Windows::Forms::CheckBox^  checkBox130;
private: System::Windows::Forms::Label^  label_Filename_3;
private: System::Windows::Forms::CheckBox^  checkBox129;
private: System::Windows::Forms::Label^  label_Unknown_3;
private: System::Windows::Forms::CheckBox^  checkBox138;
private: System::Windows::Forms::Label^  label_analysis_time_3;
private: System::Windows::Forms::Label^  label113;
private: System::Windows::Forms::Label^  label114;
private: System::Windows::Forms::Label^  label115;
private: System::Windows::Forms::Label^  label116;
private: System::Windows::Forms::Label^  label117;
private: System::Windows::Forms::Label^  label119;
private: System::Windows::Forms::Label^  label120;
private: System::Windows::Forms::Label^  label121;
private: System::Windows::Forms::Label^  label122;
private: System::Windows::Forms::CheckBox^  checkBox_Simtime_3;
private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_3;
private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_3;
private: System::Windows::Forms::CheckBox^  checkBox_Drppks_3;
private: System::Windows::Forms::CheckBox^  checkBox_Receive_3;
private: System::Windows::Forms::CheckBox^  checkBox_Sent_3;
private: System::Windows::Forms::CheckBox^  checkBox_EED_3;
private: System::Windows::Forms::CheckBox^  checkBox_NRL_3;
private: System::Windows::Forms::CheckBox^  checkBox_PDF_3;
private: System::Windows::Forms::TabPage^  tabPage6;
private: System::Windows::Forms::CheckBox^  checkBox_Simtime_2;
private: System::Windows::Forms::Label^  label_Unknown_2;
private: System::Windows::Forms::CheckBox^  checkBox125;
private: System::Windows::Forms::Label^  label_analysis_time_2;
private: System::Windows::Forms::CheckBox^  checkBox126;
private: System::Windows::Forms::Label^  label86;
private: System::Windows::Forms::Label^  label87;
private: System::Windows::Forms::Label^  label88;
private: System::Windows::Forms::Label^  label89;
private: System::Windows::Forms::Label^  label90;
private: System::Windows::Forms::Label^  label91;
private: System::Windows::Forms::Label^  label92;
private: System::Windows::Forms::Label^  label93;
private: System::Windows::Forms::Label^  label94;
private: System::Windows::Forms::Label^  label95;
private: System::Windows::Forms::Label^  label_Filename_2;
private: System::Windows::Forms::CheckBox^  checkBox127;
private: System::Windows::Forms::CheckBox^  checkBox_Overh_2;
private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_2;
private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_2;
private: System::Windows::Forms::CheckBox^  checkBox_Drppks_2;
private: System::Windows::Forms::CheckBox^  checkBox_Receive_2;
private: System::Windows::Forms::CheckBox^  checkBox_Sent_2;
private: System::Windows::Forms::CheckBox^  checkBox_EED_2;
private: System::Windows::Forms::CheckBox^  checkBox_NRL_2;
private: System::Windows::Forms::CheckBox^  checkBox_PDF_2;
private: System::Windows::Forms::TabPage^  tabPage3;
private: System::Windows::Forms::Label^  label111;
private: System::Windows::Forms::CheckBox^  checkBox_Throughput_1;
private: System::Windows::Forms::CheckBox^  checkBox_Analysis_time_1;
private: System::Windows::Forms::Label^  label_analysis_time_1;
private: System::Windows::Forms::Label^  label_Unknown_1;
private: System::Windows::Forms::CheckBox^  checkBox116;
private: System::Windows::Forms::Label^  label18;
private: System::Windows::Forms::Label^  label17;
private: System::Windows::Forms::Label^  label16;
private: System::Windows::Forms::Label^  label15;
private: System::Windows::Forms::Label^  label14;
private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::Label^  label11;
private: System::Windows::Forms::Label^  label10;
private: System::Windows::Forms::Label^  label9;
private: System::Windows::Forms::Label^  label_Filename_1;
private: System::Windows::Forms::CheckBox^  checkBox_Filename_1;
private: System::Windows::Forms::CheckBox^  checkBox_Simtime_1;
private: System::Windows::Forms::CheckBox^  checkBox_Overh_1;
private: System::Windows::Forms::CheckBox^  checkBox_Lostpkt_1;
private: System::Windows::Forms::CheckBox^  checkBox_DrpByts_1;
private: System::Windows::Forms::CheckBox^  checkBox_Drppks_1;
private: System::Windows::Forms::CheckBox^  checkBox_Receive_1;
private: System::Windows::Forms::CheckBox^  checkBox_Sent_1;
private: System::Windows::Forms::CheckBox^  checkBox_EED_1;
private: System::Windows::Forms::CheckBox^  checkBox_NRL_1;
private: System::Windows::Forms::CheckBox^  checkBox_PDF_1;
private: System::Windows::Forms::TabPage^  tabPage2;
private: System::Windows::Forms::Label^  label4;
private: System::Windows::Forms::Label^  label2;
private: System::Windows::Forms::Label^  label3;
private: System::Windows::Forms::TabControl^  tabControl1;
private: System::Windows::Forms::Label^  label112;
private: System::Windows::Forms::CheckBox^  checkBox_Throughput_2;
private: System::Windows::Forms::CheckBox^  checkBox_Throughput_3;



private: System::Windows::Forms::Label^  label123;
private: System::Windows::Forms::CheckBox^  checkBox_Throughput;
private: System::Windows::Forms::ToolStripMenuItem^  savetoolStripMenuItem;

private: System::Windows::Forms::Label^  label125;
private: System::Windows::Forms::Label^  label126;
private: System::Windows::Forms::Label^  label124;








	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->Select_Trace_File_button = (gcnew System::Windows::Forms::Button());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
			this->label_Record = (gcnew System::Windows::Forms::Label());
			this->Start_Analysis_button = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->checkBox_Throughput = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Fileinformation = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_EED = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_RoutingPkt = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_NRL = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_PDF = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_SimTime = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_LostPkt = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_DropPkt = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_DropBytes = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_RecvPkt = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_SentPkt = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Records = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->Tab_Pages_clear_button = (gcnew System::Windows::Forms::Button());
			this->Text_Board_clear_button = (gcnew System::Windows::Forms::Button());
			this->Perormance_Comparison_button = (gcnew System::Windows::Forms::Button());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->Set_all_Metrics_button = (gcnew System::Windows::Forms::Button());
			this->Most_used_Metrics_button = (gcnew System::Windows::Forms::Button());
			this->Clearall_button = (gcnew System::Windows::Forms::Button());
			this->groupBox_SystemTime = (gcnew System::Windows::Forms::GroupBox());
			this->label_Sys_Date = (gcnew System::Windows::Forms::Label());
			this->checkBox_Sys_Date = (gcnew System::Windows::Forms::CheckBox());
			this->timer2 = (gcnew System::Windows::Forms::Timer(this->components));
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->folderBrowserDialog1 = (gcnew System::Windows::Forms::FolderBrowserDialog());
			this->Process_Notes = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton_write_error = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton_Read_error = (gcnew System::Windows::Forms::RadioButton());
			this->groupBox8 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton_Fileselect = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton_Perfoprmance = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton_Results_save = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton_Startanalysis = (gcnew System::Windows::Forms::RadioButton());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->tabPage7 = (gcnew System::Windows::Forms::TabPage());
			this->checkBox41 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox42 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox43 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox44 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox45 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox46 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox47 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox48 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox49 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox50 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage8 = (gcnew System::Windows::Forms::TabPage());
			this->checkBox51 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox52 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox53 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox54 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox55 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox56 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox57 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox58 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox59 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox60 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage9 = (gcnew System::Windows::Forms::TabPage());
			this->checkBox61 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox62 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox63 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox64 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox65 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox66 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox67 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox68 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox69 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox70 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage10 = (gcnew System::Windows::Forms::TabPage());
			this->checkBox71 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox72 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox73 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox74 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox75 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox76 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox77 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox78 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox79 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox80 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox81 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox82 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox83 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox84 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox85 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox86 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox87 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox88 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox89 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox90 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox91 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox92 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox93 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox94 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox95 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox96 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox97 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox98 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox99 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox100 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage4 = (gcnew System::Windows::Forms::TabPage());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->tabPage5 = (gcnew System::Windows::Forms::TabPage());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox4 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox5 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox6 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox7 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox8 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox9 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox10 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox11 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox12 = (gcnew System::Windows::Forms::CheckBox());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->checkBox13 = (gcnew System::Windows::Forms::CheckBox());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->checkBox14 = (gcnew System::Windows::Forms::CheckBox());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->checkBox15 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox16 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox17 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox18 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox19 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox20 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox21 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox22 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox23 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox24 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox25 = (gcnew System::Windows::Forms::CheckBox());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->checkBox26 = (gcnew System::Windows::Forms::CheckBox());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->checkBox27 = (gcnew System::Windows::Forms::CheckBox());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->checkBox28 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox29 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox30 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox31 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox32 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox33 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox34 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox35 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox36 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox37 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox38 = (gcnew System::Windows::Forms::CheckBox());
			this->label59 = (gcnew System::Windows::Forms::Label());
			this->checkBox39 = (gcnew System::Windows::Forms::CheckBox());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->label62 = (gcnew System::Windows::Forms::Label());
			this->label63 = (gcnew System::Windows::Forms::Label());
			this->label64 = (gcnew System::Windows::Forms::Label());
			this->label65 = (gcnew System::Windows::Forms::Label());
			this->label66 = (gcnew System::Windows::Forms::Label());
			this->label67 = (gcnew System::Windows::Forms::Label());
			this->label68 = (gcnew System::Windows::Forms::Label());
			this->label69 = (gcnew System::Windows::Forms::Label());
			this->label70 = (gcnew System::Windows::Forms::Label());
			this->label71 = (gcnew System::Windows::Forms::Label());
			this->checkBox40 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox101 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox102 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox103 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox104 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox105 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox106 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox107 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox108 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox109 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox110 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox111 = (gcnew System::Windows::Forms::CheckBox());
			this->label72 = (gcnew System::Windows::Forms::Label());
			this->checkBox112 = (gcnew System::Windows::Forms::CheckBox());
			this->label73 = (gcnew System::Windows::Forms::Label());
			this->label74 = (gcnew System::Windows::Forms::Label());
			this->label75 = (gcnew System::Windows::Forms::Label());
			this->label76 = (gcnew System::Windows::Forms::Label());
			this->label77 = (gcnew System::Windows::Forms::Label());
			this->label78 = (gcnew System::Windows::Forms::Label());
			this->label79 = (gcnew System::Windows::Forms::Label());
			this->label80 = (gcnew System::Windows::Forms::Label());
			this->label81 = (gcnew System::Windows::Forms::Label());
			this->label82 = (gcnew System::Windows::Forms::Label());
			this->label83 = (gcnew System::Windows::Forms::Label());
			this->label84 = (gcnew System::Windows::Forms::Label());
			this->checkBox113 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox114 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox115 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox117 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox118 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox119 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox120 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox121 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox122 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox123 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox124 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox9 = (gcnew System::Windows::Forms::GroupBox());
			this->label99 = (gcnew System::Windows::Forms::Label());
			this->label98 = (gcnew System::Windows::Forms::Label());
			this->groupBox_PDF = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->File3_bar = (gcnew System::Windows::Forms::Label());
			this->File2_bar = (gcnew System::Windows::Forms::Label());
			this->File1_bar = (gcnew System::Windows::Forms::Label());
			this->progressBar4 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar3 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar2 = (gcnew System::Windows::Forms::ProgressBar());
			this->groupBox_Results_graphics = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox_DropPkts = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox6 = (gcnew System::Windows::Forms::RichTextBox());
			this->label108 = (gcnew System::Windows::Forms::Label());
			this->label109 = (gcnew System::Windows::Forms::Label());
			this->label110 = (gcnew System::Windows::Forms::Label());
			this->progressBar17 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar18 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar19 = (gcnew System::Windows::Forms::ProgressBar());
			this->groupBox_Throughput = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox5 = (gcnew System::Windows::Forms::RichTextBox());
			this->label105 = (gcnew System::Windows::Forms::Label());
			this->label106 = (gcnew System::Windows::Forms::Label());
			this->label107 = (gcnew System::Windows::Forms::Label());
			this->progressBar14 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar15 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar16 = (gcnew System::Windows::Forms::ProgressBar());
			this->groupBox_OH = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox4 = (gcnew System::Windows::Forms::RichTextBox());
			this->label102 = (gcnew System::Windows::Forms::Label());
			this->label103 = (gcnew System::Windows::Forms::Label());
			this->label104 = (gcnew System::Windows::Forms::Label());
			this->progressBar11 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar12 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar13 = (gcnew System::Windows::Forms::ProgressBar());
			this->groupBox_EED = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox3 = (gcnew System::Windows::Forms::RichTextBox());
			this->label97 = (gcnew System::Windows::Forms::Label());
			this->label100 = (gcnew System::Windows::Forms::Label());
			this->label101 = (gcnew System::Windows::Forms::Label());
			this->progressBar8 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar9 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar10 = (gcnew System::Windows::Forms::ProgressBar());
			this->groupBox_NRL = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label85 = (gcnew System::Windows::Forms::Label());
			this->label96 = (gcnew System::Windows::Forms::Label());
			this->progressBar5 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar6 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar7 = (gcnew System::Windows::Forms::ProgressBar());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->OpentoolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->printToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->savetoolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->resultsTabPagesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->textBoardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->performanceProgressToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->systemTimeToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->groupBox7 = (gcnew System::Windows::Forms::GroupBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->tabPage11 = (gcnew System::Windows::Forms::TabPage());
			this->label123 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Throughput_3 = (gcnew System::Windows::Forms::CheckBox());
			this->label118 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Overh_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox130 = (gcnew System::Windows::Forms::CheckBox());
			this->label_Filename_3 = (gcnew System::Windows::Forms::Label());
			this->checkBox129 = (gcnew System::Windows::Forms::CheckBox());
			this->label_Unknown_3 = (gcnew System::Windows::Forms::Label());
			this->checkBox138 = (gcnew System::Windows::Forms::CheckBox());
			this->label_analysis_time_3 = (gcnew System::Windows::Forms::Label());
			this->label113 = (gcnew System::Windows::Forms::Label());
			this->label114 = (gcnew System::Windows::Forms::Label());
			this->label115 = (gcnew System::Windows::Forms::Label());
			this->label116 = (gcnew System::Windows::Forms::Label());
			this->label117 = (gcnew System::Windows::Forms::Label());
			this->label119 = (gcnew System::Windows::Forms::Label());
			this->label120 = (gcnew System::Windows::Forms::Label());
			this->label121 = (gcnew System::Windows::Forms::Label());
			this->label122 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Simtime_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Lostpkt_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_DrpByts_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Drppks_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Receive_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Sent_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_EED_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_NRL_3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_PDF_3 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage6 = (gcnew System::Windows::Forms::TabPage());
			this->label112 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Throughput_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Simtime_2 = (gcnew System::Windows::Forms::CheckBox());
			this->label_Unknown_2 = (gcnew System::Windows::Forms::Label());
			this->checkBox125 = (gcnew System::Windows::Forms::CheckBox());
			this->label_analysis_time_2 = (gcnew System::Windows::Forms::Label());
			this->checkBox126 = (gcnew System::Windows::Forms::CheckBox());
			this->label86 = (gcnew System::Windows::Forms::Label());
			this->label87 = (gcnew System::Windows::Forms::Label());
			this->label88 = (gcnew System::Windows::Forms::Label());
			this->label89 = (gcnew System::Windows::Forms::Label());
			this->label90 = (gcnew System::Windows::Forms::Label());
			this->label91 = (gcnew System::Windows::Forms::Label());
			this->label92 = (gcnew System::Windows::Forms::Label());
			this->label93 = (gcnew System::Windows::Forms::Label());
			this->label94 = (gcnew System::Windows::Forms::Label());
			this->label95 = (gcnew System::Windows::Forms::Label());
			this->label_Filename_2 = (gcnew System::Windows::Forms::Label());
			this->checkBox127 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Overh_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Lostpkt_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_DrpByts_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Drppks_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Receive_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Sent_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_EED_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_NRL_2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_PDF_2 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->label111 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Throughput_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Analysis_time_1 = (gcnew System::Windows::Forms::CheckBox());
			this->label_analysis_time_1 = (gcnew System::Windows::Forms::Label());
			this->label_Unknown_1 = (gcnew System::Windows::Forms::Label());
			this->checkBox116 = (gcnew System::Windows::Forms::CheckBox());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label_Filename_1 = (gcnew System::Windows::Forms::Label());
			this->checkBox_Filename_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Simtime_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Overh_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Lostpkt_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_DrpByts_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Drppks_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Receive_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_Sent_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_EED_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_NRL_1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox_PDF_1 = (gcnew System::Windows::Forms::CheckBox());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->label125 = (gcnew System::Windows::Forms::Label());
			this->label126 = (gcnew System::Windows::Forms::Label());
			this->label124 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox6->SuspendLayout();
			this->groupBox_SystemTime->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->Process_Notes->SuspendLayout();
			this->groupBox8->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->tabPage7->SuspendLayout();
			this->tabPage8->SuspendLayout();
			this->tabPage9->SuspendLayout();
			this->tabPage10->SuspendLayout();
			this->tabPage4->SuspendLayout();
			this->tabPage5->SuspendLayout();
			this->groupBox9->SuspendLayout();
			this->groupBox_PDF->SuspendLayout();
			this->groupBox_Results_graphics->SuspendLayout();
			this->groupBox_DropPkts->SuspendLayout();
			this->groupBox_Throughput->SuspendLayout();
			this->groupBox_OH->SuspendLayout();
			this->groupBox_EED->SuspendLayout();
			this->groupBox_NRL->SuspendLayout();
			this->menuStrip1->SuspendLayout();
			this->groupBox7->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->tabPage11->SuspendLayout();
			this->tabPage6->SuspendLayout();
			this->tabPage3->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->SuspendLayout();
			// 
			// Select_Trace_File_button
			// 
			this->Select_Trace_File_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Select_Trace_File_button->Location = System::Drawing::Point(6, 21);
			this->Select_Trace_File_button->Name = L"Select_Trace_File_button";
			this->Select_Trace_File_button->Size = System::Drawing::Size(237, 42);
			this->Select_Trace_File_button->TabIndex = 1;
			this->Select_Trace_File_button->Text = L"Select Trace File";
			this->Select_Trace_File_button->UseVisualStyleBackColor = true;
			this->Select_Trace_File_button->Click += gcnew System::EventHandler(this, &Form1::Select_Trace_File_button_Click);
			// 
			// listBox1
			// 
			this->listBox1->FormattingEnabled = true;
			this->listBox1->HorizontalScrollbar = true;
			this->listBox1->Location = System::Drawing::Point(271, 385);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(319, 316);
			this->listBox1->TabIndex = 6;
			// 
			// progressBar1
			// 
			this->progressBar1->Location = System::Drawing::Point(269, 730);
			this->progressBar1->MarqueeAnimationSpeed = 0;
			this->progressBar1->Name = L"progressBar1";
			this->progressBar1->Size = System::Drawing::Size(319, 30);
			this->progressBar1->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar1->TabIndex = 7;
			// 
			// label_Record
			// 
			this->label_Record->AutoSize = true;
			this->label_Record->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label_Record->Location = System::Drawing::Point(451, 707);
			this->label_Record->Name = L"label_Record";
			this->label_Record->Size = System::Drawing::Size(19, 15);
			this->label_Record->TabIndex = 8;
			this->label_Record->Text = L"0 ";
			// 
			// Start_Analysis_button
			// 
			this->Start_Analysis_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Start_Analysis_button->Location = System::Drawing::Point(6, 67);
			this->Start_Analysis_button->Name = L"Start_Analysis_button";
			this->Start_Analysis_button->Size = System::Drawing::Size(237, 42);
			this->Start_Analysis_button->TabIndex = 9;
			this->Start_Analysis_button->Text = L"START Analysis";
			this->Start_Analysis_button->UseVisualStyleBackColor = true;
			this->Start_Analysis_button->Click += gcnew System::EventHandler(this, &Form1::Start_Analysis_button_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->checkBox_Throughput);
			this->groupBox1->Controls->Add(this->checkBox_Fileinformation);
			this->groupBox1->Controls->Add(this->checkBox_EED);
			this->groupBox1->Controls->Add(this->checkBox_RoutingPkt);
			this->groupBox1->Controls->Add(this->checkBox_NRL);
			this->groupBox1->Controls->Add(this->checkBox_PDF);
			this->groupBox1->Controls->Add(this->checkBox_SimTime);
			this->groupBox1->Controls->Add(this->checkBox_LostPkt);
			this->groupBox1->Controls->Add(this->checkBox_DropPkt);
			this->groupBox1->Controls->Add(this->checkBox_DropBytes);
			this->groupBox1->Controls->Add(this->checkBox_RecvPkt);
			this->groupBox1->Controls->Add(this->checkBox_SentPkt);
			this->groupBox1->Location = System::Drawing::Point(11, 442);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(155, 272);
			this->groupBox1->TabIndex = 10;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Performance Metrics";
			// 
			// checkBox_Throughput
			// 
			this->checkBox_Throughput->AutoSize = true;
			this->checkBox_Throughput->Checked = true;
			this->checkBox_Throughput->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_Throughput->Location = System::Drawing::Point(9, 82);
			this->checkBox_Throughput->Name = L"checkBox_Throughput";
			this->checkBox_Throughput->Size = System::Drawing::Size(84, 17);
			this->checkBox_Throughput->TabIndex = 11;
			this->checkBox_Throughput->Text = L"Throughput ";
			this->checkBox_Throughput->UseVisualStyleBackColor = true;
			// 
			// checkBox_Fileinformation
			// 
			this->checkBox_Fileinformation->AutoSize = true;
			this->checkBox_Fileinformation->Location = System::Drawing::Point(9, 250);
			this->checkBox_Fileinformation->Name = L"checkBox_Fileinformation";
			this->checkBox_Fileinformation->Size = System::Drawing::Size(100, 17);
			this->checkBox_Fileinformation->TabIndex = 10;
			this->checkBox_Fileinformation->Text = L"File Information ";
			this->checkBox_Fileinformation->UseVisualStyleBackColor = true;
			// 
			// checkBox_EED
			// 
			this->checkBox_EED->AutoSize = true;
			this->checkBox_EED->Checked = true;
			this->checkBox_EED->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_EED->Location = System::Drawing::Point(9, 61);
			this->checkBox_EED->Name = L"checkBox_EED";
			this->checkBox_EED->Size = System::Drawing::Size(109, 17);
			this->checkBox_EED->TabIndex = 9;
			this->checkBox_EED->Text = L"End to End Delay";
			this->checkBox_EED->UseVisualStyleBackColor = true;
			// 
			// checkBox_RoutingPkt
			// 
			this->checkBox_RoutingPkt->AutoSize = true;
			this->checkBox_RoutingPkt->Checked = true;
			this->checkBox_RoutingPkt->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_RoutingPkt->Location = System::Drawing::Point(9, 207);
			this->checkBox_RoutingPkt->Name = L"checkBox_RoutingPkt";
			this->checkBox_RoutingPkt->Size = System::Drawing::Size(73, 17);
			this->checkBox_RoutingPkt->TabIndex = 8;
			this->checkBox_RoutingPkt->Text = L"Overhead";
			this->checkBox_RoutingPkt->UseVisualStyleBackColor = true;
			// 
			// checkBox_NRL
			// 
			this->checkBox_NRL->AutoSize = true;
			this->checkBox_NRL->Checked = true;
			this->checkBox_NRL->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_NRL->Location = System::Drawing::Point(9, 39);
			this->checkBox_NRL->Name = L"checkBox_NRL";
			this->checkBox_NRL->Size = System::Drawing::Size(78, 17);
			this->checkBox_NRL->TabIndex = 7;
			this->checkBox_NRL->Text = L"Normalized";
			this->checkBox_NRL->UseVisualStyleBackColor = true;
			// 
			// checkBox_PDF
			// 
			this->checkBox_PDF->AutoSize = true;
			this->checkBox_PDF->Checked = true;
			this->checkBox_PDF->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_PDF->Location = System::Drawing::Point(9, 19);
			this->checkBox_PDF->Name = L"checkBox_PDF";
			this->checkBox_PDF->Size = System::Drawing::Size(129, 17);
			this->checkBox_PDF->TabIndex = 6;
			this->checkBox_PDF->Text = L"Packet Delivery Ratio";
			this->checkBox_PDF->UseVisualStyleBackColor = true;
			// 
			// checkBox_SimTime
			// 
			this->checkBox_SimTime->AutoSize = true;
			this->checkBox_SimTime->Location = System::Drawing::Point(9, 229);
			this->checkBox_SimTime->Name = L"checkBox_SimTime";
			this->checkBox_SimTime->Size = System::Drawing::Size(143, 17);
			this->checkBox_SimTime->TabIndex = 5;
			this->checkBox_SimTime->Text = L"Total Simulation Packets";
			this->checkBox_SimTime->UseVisualStyleBackColor = true;
			// 
			// checkBox_LostPkt
			// 
			this->checkBox_LostPkt->AutoSize = true;
			this->checkBox_LostPkt->Location = System::Drawing::Point(9, 187);
			this->checkBox_LostPkt->Name = L"checkBox_LostPkt";
			this->checkBox_LostPkt->Size = System::Drawing::Size(88, 17);
			this->checkBox_LostPkt->TabIndex = 4;
			this->checkBox_LostPkt->Text = L"Lost Packets";
			this->checkBox_LostPkt->UseVisualStyleBackColor = true;
			// 
			// checkBox_DropPkt
			// 
			this->checkBox_DropPkt->AutoSize = true;
			this->checkBox_DropPkt->Checked = true;
			this->checkBox_DropPkt->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_DropPkt->Location = System::Drawing::Point(9, 143);
			this->checkBox_DropPkt->Name = L"checkBox_DropPkt";
			this->checkBox_DropPkt->Size = System::Drawing::Size(136, 17);
			this->checkBox_DropPkt->TabIndex = 3;
			this->checkBox_DropPkt->Text = L"Total Dropped Packets";
			this->checkBox_DropPkt->UseVisualStyleBackColor = true;
			// 
			// checkBox_DropBytes
			// 
			this->checkBox_DropBytes->AutoSize = true;
			this->checkBox_DropBytes->Checked = true;
			this->checkBox_DropBytes->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_DropBytes->Location = System::Drawing::Point(9, 165);
			this->checkBox_DropBytes->Name = L"checkBox_DropBytes";
			this->checkBox_DropBytes->Size = System::Drawing::Size(123, 17);
			this->checkBox_DropBytes->TabIndex = 2;
			this->checkBox_DropBytes->Text = L"Total Dropped Bytes";
			this->checkBox_DropBytes->UseVisualStyleBackColor = true;
			// 
			// checkBox_RecvPkt
			// 
			this->checkBox_RecvPkt->AutoSize = true;
			this->checkBox_RecvPkt->Location = System::Drawing::Point(9, 122);
			this->checkBox_RecvPkt->Name = L"checkBox_RecvPkt";
			this->checkBox_RecvPkt->Size = System::Drawing::Size(140, 17);
			this->checkBox_RecvPkt->TabIndex = 1;
			this->checkBox_RecvPkt->Text = L"Total Received packets";
			this->checkBox_RecvPkt->UseVisualStyleBackColor = true;
			// 
			// checkBox_SentPkt
			// 
			this->checkBox_SentPkt->AutoSize = true;
			this->checkBox_SentPkt->Location = System::Drawing::Point(9, 102);
			this->checkBox_SentPkt->Name = L"checkBox_SentPkt";
			this->checkBox_SentPkt->Size = System::Drawing::Size(117, 17);
			this->checkBox_SentPkt->TabIndex = 0;
			this->checkBox_SentPkt->Text = L"Total Sent Packets";
			this->checkBox_SentPkt->UseVisualStyleBackColor = true;
			// 
			// checkBox_Records
			// 
			this->checkBox_Records->AutoSize = true;
			this->checkBox_Records->Checked = true;
			this->checkBox_Records->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_Records->Location = System::Drawing::Point(273, 707);
			this->checkBox_Records->Name = L"checkBox_Records";
			this->checkBox_Records->Size = System::Drawing::Size(156, 17);
			this->checkBox_Records->TabIndex = 11;
			this->checkBox_Records->Text = L"File\'s Total Lines (Records):";
			this->checkBox_Records->UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->groupBox5);
			this->groupBox2->Controls->Add(this->Perormance_Comparison_button);
			this->groupBox2->Controls->Add(this->groupBox6);
			this->groupBox2->Controls->Add(this->Select_Trace_File_button);
			this->groupBox2->Controls->Add(this->Start_Analysis_button);
			this->groupBox2->Location = System::Drawing::Point(12, 145);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(253, 293);
			this->groupBox2->TabIndex = 12;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Main Menu";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->Tab_Pages_clear_button);
			this->groupBox5->Controls->Add(this->Text_Board_clear_button);
			this->groupBox5->Location = System::Drawing::Point(8, 159);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(232, 61);
			this->groupBox5->TabIndex = 18;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"Boards Clear";
			// 
			// Tab_Pages_clear_button
			// 
			this->Tab_Pages_clear_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Tab_Pages_clear_button->ForeColor = System::Drawing::Color::BurlyWood;
			this->Tab_Pages_clear_button->Location = System::Drawing::Point(4, 13);
			this->Tab_Pages_clear_button->Name = L"Tab_Pages_clear_button";
			this->Tab_Pages_clear_button->Size = System::Drawing::Size(108, 42);
			this->Tab_Pages_clear_button->TabIndex = 19;
			this->Tab_Pages_clear_button->Text = L"Tab Pages ";
			this->Tab_Pages_clear_button->UseVisualStyleBackColor = true;
			this->Tab_Pages_clear_button->Click += gcnew System::EventHandler(this, &Form1::Tab_Pages_clear_button_Click);
			// 
			// Text_Board_clear_button
			// 
			this->Text_Board_clear_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Text_Board_clear_button->ForeColor = System::Drawing::Color::BurlyWood;
			this->Text_Board_clear_button->Location = System::Drawing::Point(115, 13);
			this->Text_Board_clear_button->Name = L"Text_Board_clear_button";
			this->Text_Board_clear_button->Size = System::Drawing::Size(113, 42);
			this->Text_Board_clear_button->TabIndex = 10;
			this->Text_Board_clear_button->Text = L"Text Board";
			this->Text_Board_clear_button->UseVisualStyleBackColor = true;
			this->Text_Board_clear_button->Click += gcnew System::EventHandler(this, &Form1::Text_Board_clear_button_Click);
			// 
			// Perormance_Comparison_button
			// 
			this->Perormance_Comparison_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Perormance_Comparison_button->Location = System::Drawing::Point(6, 113);
			this->Perormance_Comparison_button->Name = L"Perormance_Comparison_button";
			this->Perormance_Comparison_button->Size = System::Drawing::Size(237, 42);
			this->Perormance_Comparison_button->TabIndex = 13;
			this->Perormance_Comparison_button->Text = L"Performance Comparison  ";
			this->Perormance_Comparison_button->UseVisualStyleBackColor = true;
			this->Perormance_Comparison_button->Click += gcnew System::EventHandler(this, &Form1::Perormance_Comparison_button_Click);
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->Set_all_Metrics_button);
			this->groupBox6->Controls->Add(this->Most_used_Metrics_button);
			this->groupBox6->Controls->Add(this->Clearall_button);
			this->groupBox6->Location = System::Drawing::Point(8, 223);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(232, 64);
			this->groupBox6->TabIndex = 17;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = L"Metrics";
			// 
			// Set_all_Metrics_button
			// 
			this->Set_all_Metrics_button->Location = System::Drawing::Point(5, 16);
			this->Set_all_Metrics_button->Name = L"Set_all_Metrics_button";
			this->Set_all_Metrics_button->Size = System::Drawing::Size(69, 42);
			this->Set_all_Metrics_button->TabIndex = 13;
			this->Set_all_Metrics_button->Text = L"Set All  ";
			this->Set_all_Metrics_button->UseVisualStyleBackColor = true;
			this->Set_all_Metrics_button->Click += gcnew System::EventHandler(this, &Form1::Set_all_Metrics_button_Click);
			// 
			// Most_used_Metrics_button
			// 
			this->Most_used_Metrics_button->Location = System::Drawing::Point(81, 16);
			this->Most_used_Metrics_button->Name = L"Most_used_Metrics_button";
			this->Most_used_Metrics_button->Size = System::Drawing::Size(69, 42);
			this->Most_used_Metrics_button->TabIndex = 14;
			this->Most_used_Metrics_button->Text = L"Most Used";
			this->Most_used_Metrics_button->UseVisualStyleBackColor = true;
			this->Most_used_Metrics_button->Click += gcnew System::EventHandler(this, &Form1::Most_used_Metrics_button_Click);
			// 
			// Clearall_button
			// 
			this->Clearall_button->Location = System::Drawing::Point(157, 16);
			this->Clearall_button->Name = L"Clearall_button";
			this->Clearall_button->Size = System::Drawing::Size(69, 42);
			this->Clearall_button->TabIndex = 15;
			this->Clearall_button->Text = L"Clear All";
			this->Clearall_button->UseVisualStyleBackColor = true;
			this->Clearall_button->Click += gcnew System::EventHandler(this, &Form1::Clearall_button_Click);
			// 
			// groupBox_SystemTime
			// 
			this->groupBox_SystemTime->Controls->Add(this->label_Sys_Date);
			this->groupBox_SystemTime->Controls->Add(this->checkBox_Sys_Date);
			this->groupBox_SystemTime->ForeColor = System::Drawing::SystemColors::ActiveCaption;
			this->groupBox_SystemTime->Location = System::Drawing::Point(271, 24);
			this->groupBox_SystemTime->Name = L"groupBox_SystemTime";
			this->groupBox_SystemTime->Size = System::Drawing::Size(320, 46);
			this->groupBox_SystemTime->TabIndex = 13;
			this->groupBox_SystemTime->TabStop = false;
			this->groupBox_SystemTime->Text = L"System Time";
			// 
			// label_Sys_Date
			// 
			this->label_Sys_Date->AutoSize = true;
			this->label_Sys_Date->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label_Sys_Date->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label_Sys_Date->Location = System::Drawing::Point(89, 18);
			this->label_Sys_Date->Name = L"label_Sys_Date";
			this->label_Sys_Date->Size = System::Drawing::Size(11, 15);
			this->label_Sys_Date->TabIndex = 14;
			this->label_Sys_Date->Text = L" ";
			// 
			// checkBox_Sys_Date
			// 
			this->checkBox_Sys_Date->AutoSize = true;
			this->checkBox_Sys_Date->Checked = true;
			this->checkBox_Sys_Date->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_Sys_Date->ForeColor = System::Drawing::Color::Black;
			this->checkBox_Sys_Date->Location = System::Drawing::Point(6, 18);
			this->checkBox_Sys_Date->Name = L"checkBox_Sys_Date";
			this->checkBox_Sys_Date->Size = System::Drawing::Size(87, 17);
			this->checkBox_Sys_Date->TabIndex = 12;
			this->checkBox_Sys_Date->Text = L"Date  - Time:";
			this->checkBox_Sys_Date->UseVisualStyleBackColor = true;
			// 
			// timer2
			// 
			this->timer2->Enabled = true;
			this->timer2->Tick += gcnew System::EventHandler(this, &Form1::timer2_Tick);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->label1);
			this->groupBox4->Location = System::Drawing::Point(12, 25);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(253, 46);
			this->groupBox4->TabIndex = 14;
			this->groupBox4->TabStop = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Old English Text MT", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(-7, 8);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(220, 28);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Trace File Analyzer";
			// 
			// Process_Notes
			// 
			this->Process_Notes->Controls->Add(this->radioButton_write_error);
			this->Process_Notes->Controls->Add(this->radioButton_Read_error);
			this->Process_Notes->ForeColor = System::Drawing::Color::Red;
			this->Process_Notes->Location = System::Drawing::Point(171, 567);
			this->Process_Notes->Name = L"Process_Notes";
			this->Process_Notes->Size = System::Drawing::Size(94, 147);
			this->Process_Notes->TabIndex = 15;
			this->Process_Notes->TabStop = false;
			this->Process_Notes->Text = L"Error Notes";
			// 
			// radioButton_write_error
			// 
			this->radioButton_write_error->AutoSize = true;
			this->radioButton_write_error->Enabled = false;
			this->radioButton_write_error->Location = System::Drawing::Point(4, 55);
			this->radioButton_write_error->Name = L"radioButton_write_error";
			this->radioButton_write_error->Size = System::Drawing::Size(69, 17);
			this->radioButton_write_error->TabIndex = 1;
			this->radioButton_write_error->Text = L"File Write";
			this->radioButton_write_error->UseVisualStyleBackColor = true;
			// 
			// radioButton_Read_error
			// 
			this->radioButton_Read_error->AutoSize = true;
			this->radioButton_Read_error->Enabled = false;
			this->radioButton_Read_error->Location = System::Drawing::Point(4, 21);
			this->radioButton_Read_error->Name = L"radioButton_Read_error";
			this->radioButton_Read_error->Size = System::Drawing::Size(70, 17);
			this->radioButton_Read_error->TabIndex = 0;
			this->radioButton_Read_error->Text = L"File Read";
			this->radioButton_Read_error->UseVisualStyleBackColor = true;
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->radioButton_Fileselect);
			this->groupBox8->Controls->Add(this->radioButton_Perfoprmance);
			this->groupBox8->Controls->Add(this->radioButton_Results_save);
			this->groupBox8->Controls->Add(this->radioButton_Startanalysis);
			this->groupBox8->ForeColor = System::Drawing::Color::DarkGreen;
			this->groupBox8->Location = System::Drawing::Point(171, 443);
			this->groupBox8->Name = L"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(94, 115);
			this->groupBox8->TabIndex = 17;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = L"Last Process";
			// 
			// radioButton_Fileselect
			// 
			this->radioButton_Fileselect->AutoSize = true;
			this->radioButton_Fileselect->Enabled = false;
			this->radioButton_Fileselect->Location = System::Drawing::Point(4, 20);
			this->radioButton_Fileselect->Name = L"radioButton_Fileselect";
			this->radioButton_Fileselect->Size = System::Drawing::Size(74, 17);
			this->radioButton_Fileselect->TabIndex = 4;
			this->radioButton_Fileselect->Text = L"File Select";
			this->radioButton_Fileselect->UseVisualStyleBackColor = true;
			// 
			// radioButton_Perfoprmance
			// 
			this->radioButton_Perfoprmance->AutoSize = true;
			this->radioButton_Perfoprmance->Cursor = System::Windows::Forms::Cursors::No;
			this->radioButton_Perfoprmance->Enabled = false;
			this->radioButton_Perfoprmance->Location = System::Drawing::Point(4, 69);
			this->radioButton_Perfoprmance->Name = L"radioButton_Perfoprmance";
			this->radioButton_Perfoprmance->Size = System::Drawing::Size(85, 17);
			this->radioButton_Perfoprmance->TabIndex = 3;
			this->radioButton_Perfoprmance->Text = L"Performance";
			this->radioButton_Perfoprmance->UseVisualStyleBackColor = true;
			// 
			// radioButton_Results_save
			// 
			this->radioButton_Results_save->AutoSize = true;
			this->radioButton_Results_save->Cursor = System::Windows::Forms::Cursors::No;
			this->radioButton_Results_save->Enabled = false;
			this->radioButton_Results_save->Location = System::Drawing::Point(4, 93);
			this->radioButton_Results_save->Name = L"radioButton_Results_save";
			this->radioButton_Results_save->Size = System::Drawing::Size(88, 17);
			this->radioButton_Results_save->TabIndex = 1;
			this->radioButton_Results_save->Text = L"Results Save";
			this->radioButton_Results_save->UseVisualStyleBackColor = true;
			// 
			// radioButton_Startanalysis
			// 
			this->radioButton_Startanalysis->AutoSize = true;
			this->radioButton_Startanalysis->Cursor = System::Windows::Forms::Cursors::No;
			this->radioButton_Startanalysis->Enabled = false;
			this->radioButton_Startanalysis->Location = System::Drawing::Point(4, 44);
			this->radioButton_Startanalysis->Name = L"radioButton_Startanalysis";
			this->radioButton_Startanalysis->Size = System::Drawing::Size(88, 17);
			this->radioButton_Startanalysis->TabIndex = 0;
			this->radioButton_Startanalysis->Text = L"Start Analysis";
			this->radioButton_Startanalysis->UseVisualStyleBackColor = true;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->label5);
			this->tabPage1->Controls->Add(this->label6);
			this->tabPage1->Controls->Add(this->label7);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(314, 251);
			this->tabPage1->TabIndex = 1;
			this->tabPage1->Text = L"Results";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label5->Location = System::Drawing::Point(117, 161);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(191, 57);
			this->label5->TabIndex = 3;
			this->label5->Text = L"Tab Pages";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label6->Location = System::Drawing::Point(3, 8);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(211, 76);
			this->label6->TabIndex = 2;
			this->label6->Text = L"Analysis";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label7->Location = System::Drawing::Point(62, 93);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(137, 57);
			this->label7->TabIndex = 1;
			this->label7->Text = L"Results";
			// 
			// tabPage7
			// 
			this->tabPage7->Controls->Add(this->checkBox41);
			this->tabPage7->Controls->Add(this->checkBox42);
			this->tabPage7->Controls->Add(this->checkBox43);
			this->tabPage7->Controls->Add(this->checkBox44);
			this->tabPage7->Controls->Add(this->checkBox45);
			this->tabPage7->Controls->Add(this->checkBox46);
			this->tabPage7->Controls->Add(this->checkBox47);
			this->tabPage7->Controls->Add(this->checkBox48);
			this->tabPage7->Controls->Add(this->checkBox49);
			this->tabPage7->Controls->Add(this->checkBox50);
			this->tabPage7->Location = System::Drawing::Point(4, 22);
			this->tabPage7->Name = L"tabPage7";
			this->tabPage7->Size = System::Drawing::Size(314, 251);
			this->tabPage7->TabIndex = 2;
			this->tabPage7->Text = L"File 1";
			this->tabPage7->UseVisualStyleBackColor = true;
			// 
			// checkBox41
			// 
			this->checkBox41->AutoSize = true;
			this->checkBox41->Checked = true;
			this->checkBox41->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox41->Enabled = false;
			this->checkBox41->Location = System::Drawing::Point(156, 207);
			this->checkBox41->Name = L"checkBox41";
			this->checkBox41->Size = System::Drawing::Size(143, 17);
			this->checkBox41->TabIndex = 28;
			this->checkBox41->Text = L"Total Simulation Packets";
			this->checkBox41->UseVisualStyleBackColor = true;
			// 
			// checkBox42
			// 
			this->checkBox42->AutoSize = true;
			this->checkBox42->Checked = true;
			this->checkBox42->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox42->Enabled = false;
			this->checkBox42->Location = System::Drawing::Point(15, 207);
			this->checkBox42->Name = L"checkBox42";
			this->checkBox42->Size = System::Drawing::Size(73, 17);
			this->checkBox42->TabIndex = 27;
			this->checkBox42->Text = L"Overhead";
			this->checkBox42->UseVisualStyleBackColor = true;
			// 
			// checkBox43
			// 
			this->checkBox43->AutoSize = true;
			this->checkBox43->Checked = true;
			this->checkBox43->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox43->Enabled = false;
			this->checkBox43->Location = System::Drawing::Point(156, 168);
			this->checkBox43->Name = L"checkBox43";
			this->checkBox43->Size = System::Drawing::Size(88, 17);
			this->checkBox43->TabIndex = 26;
			this->checkBox43->Text = L"Lost Packets";
			this->checkBox43->UseVisualStyleBackColor = true;
			// 
			// checkBox44
			// 
			this->checkBox44->AutoSize = true;
			this->checkBox44->Checked = true;
			this->checkBox44->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox44->Enabled = false;
			this->checkBox44->Location = System::Drawing::Point(15, 161);
			this->checkBox44->Name = L"checkBox44";
			this->checkBox44->Size = System::Drawing::Size(123, 17);
			this->checkBox44->TabIndex = 25;
			this->checkBox44->Text = L"Total Dropped Bytes";
			this->checkBox44->UseVisualStyleBackColor = true;
			// 
			// checkBox45
			// 
			this->checkBox45->AutoSize = true;
			this->checkBox45->Checked = true;
			this->checkBox45->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox45->Enabled = false;
			this->checkBox45->Location = System::Drawing::Point(156, 117);
			this->checkBox45->Name = L"checkBox45";
			this->checkBox45->Size = System::Drawing::Size(136, 17);
			this->checkBox45->TabIndex = 24;
			this->checkBox45->Text = L"Total Dropped Packets";
			this->checkBox45->UseVisualStyleBackColor = true;
			// 
			// checkBox46
			// 
			this->checkBox46->AutoSize = true;
			this->checkBox46->Checked = true;
			this->checkBox46->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox46->Enabled = false;
			this->checkBox46->Location = System::Drawing::Point(15, 115);
			this->checkBox46->Name = L"checkBox46";
			this->checkBox46->Size = System::Drawing::Size(140, 17);
			this->checkBox46->TabIndex = 23;
			this->checkBox46->Text = L"Total Received packets";
			this->checkBox46->UseVisualStyleBackColor = true;
			// 
			// checkBox47
			// 
			this->checkBox47->AutoSize = true;
			this->checkBox47->Checked = true;
			this->checkBox47->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox47->Enabled = false;
			this->checkBox47->Location = System::Drawing::Point(156, 70);
			this->checkBox47->Name = L"checkBox47";
			this->checkBox47->Size = System::Drawing::Size(117, 17);
			this->checkBox47->TabIndex = 22;
			this->checkBox47->Text = L"Total Sent Packets";
			this->checkBox47->UseVisualStyleBackColor = true;
			// 
			// checkBox48
			// 
			this->checkBox48->AutoSize = true;
			this->checkBox48->Checked = true;
			this->checkBox48->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox48->Enabled = false;
			this->checkBox48->Location = System::Drawing::Point(15, 70);
			this->checkBox48->Name = L"checkBox48";
			this->checkBox48->Size = System::Drawing::Size(109, 17);
			this->checkBox48->TabIndex = 21;
			this->checkBox48->Text = L"End to End Delay";
			this->checkBox48->UseVisualStyleBackColor = true;
			// 
			// checkBox49
			// 
			this->checkBox49->AutoSize = true;
			this->checkBox49->Checked = true;
			this->checkBox49->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox49->Enabled = false;
			this->checkBox49->Location = System::Drawing::Point(156, 27);
			this->checkBox49->Name = L"checkBox49";
			this->checkBox49->Size = System::Drawing::Size(78, 17);
			this->checkBox49->TabIndex = 20;
			this->checkBox49->Text = L"Normalized";
			this->checkBox49->UseVisualStyleBackColor = true;
			// 
			// checkBox50
			// 
			this->checkBox50->AutoSize = true;
			this->checkBox50->Checked = true;
			this->checkBox50->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox50->Enabled = false;
			this->checkBox50->Location = System::Drawing::Point(16, 27);
			this->checkBox50->Name = L"checkBox50";
			this->checkBox50->Size = System::Drawing::Size(129, 17);
			this->checkBox50->TabIndex = 19;
			this->checkBox50->Text = L"Packet Delivery Ratio";
			this->checkBox50->UseVisualStyleBackColor = true;
			// 
			// tabPage8
			// 
			this->tabPage8->Controls->Add(this->checkBox51);
			this->tabPage8->Controls->Add(this->checkBox52);
			this->tabPage8->Controls->Add(this->checkBox53);
			this->tabPage8->Controls->Add(this->checkBox54);
			this->tabPage8->Controls->Add(this->checkBox55);
			this->tabPage8->Controls->Add(this->checkBox56);
			this->tabPage8->Controls->Add(this->checkBox57);
			this->tabPage8->Controls->Add(this->checkBox58);
			this->tabPage8->Controls->Add(this->checkBox59);
			this->tabPage8->Controls->Add(this->checkBox60);
			this->tabPage8->Location = System::Drawing::Point(4, 22);
			this->tabPage8->Name = L"tabPage8";
			this->tabPage8->Size = System::Drawing::Size(314, 251);
			this->tabPage8->TabIndex = 3;
			this->tabPage8->Text = L"File 2";
			this->tabPage8->UseVisualStyleBackColor = true;
			// 
			// checkBox51
			// 
			this->checkBox51->AutoSize = true;
			this->checkBox51->Checked = true;
			this->checkBox51->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox51->Enabled = false;
			this->checkBox51->Location = System::Drawing::Point(156, 207);
			this->checkBox51->Name = L"checkBox51";
			this->checkBox51->Size = System::Drawing::Size(143, 17);
			this->checkBox51->TabIndex = 28;
			this->checkBox51->Text = L"Total Simulation Packets";
			this->checkBox51->UseVisualStyleBackColor = true;
			// 
			// checkBox52
			// 
			this->checkBox52->AutoSize = true;
			this->checkBox52->Checked = true;
			this->checkBox52->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox52->Enabled = false;
			this->checkBox52->Location = System::Drawing::Point(15, 207);
			this->checkBox52->Name = L"checkBox52";
			this->checkBox52->Size = System::Drawing::Size(73, 17);
			this->checkBox52->TabIndex = 27;
			this->checkBox52->Text = L"Overhead";
			this->checkBox52->UseVisualStyleBackColor = true;
			// 
			// checkBox53
			// 
			this->checkBox53->AutoSize = true;
			this->checkBox53->Checked = true;
			this->checkBox53->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox53->Enabled = false;
			this->checkBox53->Location = System::Drawing::Point(156, 168);
			this->checkBox53->Name = L"checkBox53";
			this->checkBox53->Size = System::Drawing::Size(88, 17);
			this->checkBox53->TabIndex = 26;
			this->checkBox53->Text = L"Lost Packets";
			this->checkBox53->UseVisualStyleBackColor = true;
			// 
			// checkBox54
			// 
			this->checkBox54->AutoSize = true;
			this->checkBox54->Checked = true;
			this->checkBox54->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox54->Enabled = false;
			this->checkBox54->Location = System::Drawing::Point(15, 161);
			this->checkBox54->Name = L"checkBox54";
			this->checkBox54->Size = System::Drawing::Size(123, 17);
			this->checkBox54->TabIndex = 25;
			this->checkBox54->Text = L"Total Dropped Bytes";
			this->checkBox54->UseVisualStyleBackColor = true;
			// 
			// checkBox55
			// 
			this->checkBox55->AutoSize = true;
			this->checkBox55->Checked = true;
			this->checkBox55->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox55->Enabled = false;
			this->checkBox55->Location = System::Drawing::Point(156, 117);
			this->checkBox55->Name = L"checkBox55";
			this->checkBox55->Size = System::Drawing::Size(136, 17);
			this->checkBox55->TabIndex = 24;
			this->checkBox55->Text = L"Total Dropped Packets";
			this->checkBox55->UseVisualStyleBackColor = true;
			// 
			// checkBox56
			// 
			this->checkBox56->AutoSize = true;
			this->checkBox56->Checked = true;
			this->checkBox56->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox56->Enabled = false;
			this->checkBox56->Location = System::Drawing::Point(15, 115);
			this->checkBox56->Name = L"checkBox56";
			this->checkBox56->Size = System::Drawing::Size(140, 17);
			this->checkBox56->TabIndex = 23;
			this->checkBox56->Text = L"Total Received packets";
			this->checkBox56->UseVisualStyleBackColor = true;
			// 
			// checkBox57
			// 
			this->checkBox57->AutoSize = true;
			this->checkBox57->Checked = true;
			this->checkBox57->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox57->Enabled = false;
			this->checkBox57->Location = System::Drawing::Point(156, 70);
			this->checkBox57->Name = L"checkBox57";
			this->checkBox57->Size = System::Drawing::Size(117, 17);
			this->checkBox57->TabIndex = 22;
			this->checkBox57->Text = L"Total Sent Packets";
			this->checkBox57->UseVisualStyleBackColor = true;
			// 
			// checkBox58
			// 
			this->checkBox58->AutoSize = true;
			this->checkBox58->Checked = true;
			this->checkBox58->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox58->Enabled = false;
			this->checkBox58->Location = System::Drawing::Point(15, 70);
			this->checkBox58->Name = L"checkBox58";
			this->checkBox58->Size = System::Drawing::Size(109, 17);
			this->checkBox58->TabIndex = 21;
			this->checkBox58->Text = L"End to End Delay";
			this->checkBox58->UseVisualStyleBackColor = true;
			// 
			// checkBox59
			// 
			this->checkBox59->AutoSize = true;
			this->checkBox59->Checked = true;
			this->checkBox59->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox59->Enabled = false;
			this->checkBox59->Location = System::Drawing::Point(156, 27);
			this->checkBox59->Name = L"checkBox59";
			this->checkBox59->Size = System::Drawing::Size(78, 17);
			this->checkBox59->TabIndex = 20;
			this->checkBox59->Text = L"Normalized";
			this->checkBox59->UseVisualStyleBackColor = true;
			// 
			// checkBox60
			// 
			this->checkBox60->AutoSize = true;
			this->checkBox60->Checked = true;
			this->checkBox60->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox60->Enabled = false;
			this->checkBox60->Location = System::Drawing::Point(16, 27);
			this->checkBox60->Name = L"checkBox60";
			this->checkBox60->Size = System::Drawing::Size(129, 17);
			this->checkBox60->TabIndex = 19;
			this->checkBox60->Text = L"Packet Delivery Ratio";
			this->checkBox60->UseVisualStyleBackColor = true;
			// 
			// tabPage9
			// 
			this->tabPage9->Controls->Add(this->checkBox61);
			this->tabPage9->Controls->Add(this->checkBox62);
			this->tabPage9->Controls->Add(this->checkBox63);
			this->tabPage9->Controls->Add(this->checkBox64);
			this->tabPage9->Controls->Add(this->checkBox65);
			this->tabPage9->Controls->Add(this->checkBox66);
			this->tabPage9->Controls->Add(this->checkBox67);
			this->tabPage9->Controls->Add(this->checkBox68);
			this->tabPage9->Controls->Add(this->checkBox69);
			this->tabPage9->Controls->Add(this->checkBox70);
			this->tabPage9->Location = System::Drawing::Point(4, 22);
			this->tabPage9->Name = L"tabPage9";
			this->tabPage9->Size = System::Drawing::Size(314, 251);
			this->tabPage9->TabIndex = 4;
			this->tabPage9->Text = L"File 3";
			this->tabPage9->UseVisualStyleBackColor = true;
			// 
			// checkBox61
			// 
			this->checkBox61->AutoSize = true;
			this->checkBox61->Checked = true;
			this->checkBox61->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox61->Enabled = false;
			this->checkBox61->Location = System::Drawing::Point(156, 207);
			this->checkBox61->Name = L"checkBox61";
			this->checkBox61->Size = System::Drawing::Size(143, 17);
			this->checkBox61->TabIndex = 28;
			this->checkBox61->Text = L"Total Simulation Packets";
			this->checkBox61->UseVisualStyleBackColor = true;
			// 
			// checkBox62
			// 
			this->checkBox62->AutoSize = true;
			this->checkBox62->Checked = true;
			this->checkBox62->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox62->Enabled = false;
			this->checkBox62->Location = System::Drawing::Point(15, 207);
			this->checkBox62->Name = L"checkBox62";
			this->checkBox62->Size = System::Drawing::Size(73, 17);
			this->checkBox62->TabIndex = 27;
			this->checkBox62->Text = L"Overhead";
			this->checkBox62->UseVisualStyleBackColor = true;
			// 
			// checkBox63
			// 
			this->checkBox63->AutoSize = true;
			this->checkBox63->Checked = true;
			this->checkBox63->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox63->Enabled = false;
			this->checkBox63->Location = System::Drawing::Point(156, 168);
			this->checkBox63->Name = L"checkBox63";
			this->checkBox63->Size = System::Drawing::Size(88, 17);
			this->checkBox63->TabIndex = 26;
			this->checkBox63->Text = L"Lost Packets";
			this->checkBox63->UseVisualStyleBackColor = true;
			// 
			// checkBox64
			// 
			this->checkBox64->AutoSize = true;
			this->checkBox64->Checked = true;
			this->checkBox64->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox64->Enabled = false;
			this->checkBox64->Location = System::Drawing::Point(15, 161);
			this->checkBox64->Name = L"checkBox64";
			this->checkBox64->Size = System::Drawing::Size(123, 17);
			this->checkBox64->TabIndex = 25;
			this->checkBox64->Text = L"Total Dropped Bytes";
			this->checkBox64->UseVisualStyleBackColor = true;
			// 
			// checkBox65
			// 
			this->checkBox65->AutoSize = true;
			this->checkBox65->Checked = true;
			this->checkBox65->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox65->Enabled = false;
			this->checkBox65->Location = System::Drawing::Point(156, 117);
			this->checkBox65->Name = L"checkBox65";
			this->checkBox65->Size = System::Drawing::Size(136, 17);
			this->checkBox65->TabIndex = 24;
			this->checkBox65->Text = L"Total Dropped Packets";
			this->checkBox65->UseVisualStyleBackColor = true;
			// 
			// checkBox66
			// 
			this->checkBox66->AutoSize = true;
			this->checkBox66->Checked = true;
			this->checkBox66->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox66->Enabled = false;
			this->checkBox66->Location = System::Drawing::Point(15, 115);
			this->checkBox66->Name = L"checkBox66";
			this->checkBox66->Size = System::Drawing::Size(140, 17);
			this->checkBox66->TabIndex = 23;
			this->checkBox66->Text = L"Total Received packets";
			this->checkBox66->UseVisualStyleBackColor = true;
			// 
			// checkBox67
			// 
			this->checkBox67->AutoSize = true;
			this->checkBox67->Checked = true;
			this->checkBox67->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox67->Enabled = false;
			this->checkBox67->Location = System::Drawing::Point(156, 70);
			this->checkBox67->Name = L"checkBox67";
			this->checkBox67->Size = System::Drawing::Size(117, 17);
			this->checkBox67->TabIndex = 22;
			this->checkBox67->Text = L"Total Sent Packets";
			this->checkBox67->UseVisualStyleBackColor = true;
			// 
			// checkBox68
			// 
			this->checkBox68->AutoSize = true;
			this->checkBox68->Checked = true;
			this->checkBox68->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox68->Enabled = false;
			this->checkBox68->Location = System::Drawing::Point(15, 70);
			this->checkBox68->Name = L"checkBox68";
			this->checkBox68->Size = System::Drawing::Size(109, 17);
			this->checkBox68->TabIndex = 21;
			this->checkBox68->Text = L"End to End Delay";
			this->checkBox68->UseVisualStyleBackColor = true;
			// 
			// checkBox69
			// 
			this->checkBox69->AutoSize = true;
			this->checkBox69->Checked = true;
			this->checkBox69->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox69->Enabled = false;
			this->checkBox69->Location = System::Drawing::Point(156, 27);
			this->checkBox69->Name = L"checkBox69";
			this->checkBox69->Size = System::Drawing::Size(78, 17);
			this->checkBox69->TabIndex = 20;
			this->checkBox69->Text = L"Normalized";
			this->checkBox69->UseVisualStyleBackColor = true;
			// 
			// checkBox70
			// 
			this->checkBox70->AutoSize = true;
			this->checkBox70->Checked = true;
			this->checkBox70->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox70->Enabled = false;
			this->checkBox70->Location = System::Drawing::Point(16, 27);
			this->checkBox70->Name = L"checkBox70";
			this->checkBox70->Size = System::Drawing::Size(129, 17);
			this->checkBox70->TabIndex = 19;
			this->checkBox70->Text = L"Packet Delivery Ratio";
			this->checkBox70->UseVisualStyleBackColor = true;
			// 
			// tabPage10
			// 
			this->tabPage10->Controls->Add(this->checkBox71);
			this->tabPage10->Controls->Add(this->checkBox72);
			this->tabPage10->Controls->Add(this->checkBox73);
			this->tabPage10->Controls->Add(this->checkBox74);
			this->tabPage10->Controls->Add(this->checkBox75);
			this->tabPage10->Controls->Add(this->checkBox76);
			this->tabPage10->Controls->Add(this->checkBox77);
			this->tabPage10->Controls->Add(this->checkBox78);
			this->tabPage10->Controls->Add(this->checkBox79);
			this->tabPage10->Controls->Add(this->checkBox80);
			this->tabPage10->Location = System::Drawing::Point(4, 22);
			this->tabPage10->Name = L"tabPage10";
			this->tabPage10->Size = System::Drawing::Size(314, 251);
			this->tabPage10->TabIndex = 5;
			this->tabPage10->Text = L"File 4";
			this->tabPage10->UseVisualStyleBackColor = true;
			// 
			// checkBox71
			// 
			this->checkBox71->AutoSize = true;
			this->checkBox71->Checked = true;
			this->checkBox71->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox71->Enabled = false;
			this->checkBox71->Location = System::Drawing::Point(156, 207);
			this->checkBox71->Name = L"checkBox71";
			this->checkBox71->Size = System::Drawing::Size(143, 17);
			this->checkBox71->TabIndex = 28;
			this->checkBox71->Text = L"Total Simulation Packets";
			this->checkBox71->UseVisualStyleBackColor = true;
			// 
			// checkBox72
			// 
			this->checkBox72->AutoSize = true;
			this->checkBox72->Checked = true;
			this->checkBox72->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox72->Enabled = false;
			this->checkBox72->Location = System::Drawing::Point(15, 207);
			this->checkBox72->Name = L"checkBox72";
			this->checkBox72->Size = System::Drawing::Size(73, 17);
			this->checkBox72->TabIndex = 27;
			this->checkBox72->Text = L"Overhead";
			this->checkBox72->UseVisualStyleBackColor = true;
			// 
			// checkBox73
			// 
			this->checkBox73->AutoSize = true;
			this->checkBox73->Checked = true;
			this->checkBox73->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox73->Enabled = false;
			this->checkBox73->Location = System::Drawing::Point(156, 168);
			this->checkBox73->Name = L"checkBox73";
			this->checkBox73->Size = System::Drawing::Size(88, 17);
			this->checkBox73->TabIndex = 26;
			this->checkBox73->Text = L"Lost Packets";
			this->checkBox73->UseVisualStyleBackColor = true;
			// 
			// checkBox74
			// 
			this->checkBox74->AutoSize = true;
			this->checkBox74->Checked = true;
			this->checkBox74->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox74->Enabled = false;
			this->checkBox74->Location = System::Drawing::Point(15, 161);
			this->checkBox74->Name = L"checkBox74";
			this->checkBox74->Size = System::Drawing::Size(123, 17);
			this->checkBox74->TabIndex = 25;
			this->checkBox74->Text = L"Total Dropped Bytes";
			this->checkBox74->UseVisualStyleBackColor = true;
			// 
			// checkBox75
			// 
			this->checkBox75->AutoSize = true;
			this->checkBox75->Checked = true;
			this->checkBox75->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox75->Enabled = false;
			this->checkBox75->Location = System::Drawing::Point(156, 117);
			this->checkBox75->Name = L"checkBox75";
			this->checkBox75->Size = System::Drawing::Size(136, 17);
			this->checkBox75->TabIndex = 24;
			this->checkBox75->Text = L"Total Dropped Packets";
			this->checkBox75->UseVisualStyleBackColor = true;
			// 
			// checkBox76
			// 
			this->checkBox76->AutoSize = true;
			this->checkBox76->Checked = true;
			this->checkBox76->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox76->Enabled = false;
			this->checkBox76->Location = System::Drawing::Point(15, 115);
			this->checkBox76->Name = L"checkBox76";
			this->checkBox76->Size = System::Drawing::Size(140, 17);
			this->checkBox76->TabIndex = 23;
			this->checkBox76->Text = L"Total Received packets";
			this->checkBox76->UseVisualStyleBackColor = true;
			// 
			// checkBox77
			// 
			this->checkBox77->AutoSize = true;
			this->checkBox77->Checked = true;
			this->checkBox77->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox77->Enabled = false;
			this->checkBox77->Location = System::Drawing::Point(156, 70);
			this->checkBox77->Name = L"checkBox77";
			this->checkBox77->Size = System::Drawing::Size(117, 17);
			this->checkBox77->TabIndex = 22;
			this->checkBox77->Text = L"Total Sent Packets";
			this->checkBox77->UseVisualStyleBackColor = true;
			// 
			// checkBox78
			// 
			this->checkBox78->AutoSize = true;
			this->checkBox78->Checked = true;
			this->checkBox78->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox78->Enabled = false;
			this->checkBox78->Location = System::Drawing::Point(15, 70);
			this->checkBox78->Name = L"checkBox78";
			this->checkBox78->Size = System::Drawing::Size(109, 17);
			this->checkBox78->TabIndex = 21;
			this->checkBox78->Text = L"End to End Delay";
			this->checkBox78->UseVisualStyleBackColor = true;
			// 
			// checkBox79
			// 
			this->checkBox79->AutoSize = true;
			this->checkBox79->Checked = true;
			this->checkBox79->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox79->Enabled = false;
			this->checkBox79->Location = System::Drawing::Point(156, 27);
			this->checkBox79->Name = L"checkBox79";
			this->checkBox79->Size = System::Drawing::Size(78, 17);
			this->checkBox79->TabIndex = 20;
			this->checkBox79->Text = L"Normalized";
			this->checkBox79->UseVisualStyleBackColor = true;
			// 
			// checkBox80
			// 
			this->checkBox80->AutoSize = true;
			this->checkBox80->Checked = true;
			this->checkBox80->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox80->Enabled = false;
			this->checkBox80->Location = System::Drawing::Point(16, 27);
			this->checkBox80->Name = L"checkBox80";
			this->checkBox80->Size = System::Drawing::Size(129, 17);
			this->checkBox80->TabIndex = 19;
			this->checkBox80->Text = L"Packet Delivery Ratio";
			this->checkBox80->UseVisualStyleBackColor = true;
			// 
			// checkBox81
			// 
			this->checkBox81->AutoSize = true;
			this->checkBox81->Checked = true;
			this->checkBox81->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox81->Enabled = false;
			this->checkBox81->Location = System::Drawing::Point(156, 207);
			this->checkBox81->Name = L"checkBox81";
			this->checkBox81->Size = System::Drawing::Size(143, 17);
			this->checkBox81->TabIndex = 28;
			this->checkBox81->Text = L"Total Simulation Packets";
			this->checkBox81->UseVisualStyleBackColor = true;
			// 
			// checkBox82
			// 
			this->checkBox82->AutoSize = true;
			this->checkBox82->Checked = true;
			this->checkBox82->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox82->Enabled = false;
			this->checkBox82->Location = System::Drawing::Point(15, 207);
			this->checkBox82->Name = L"checkBox82";
			this->checkBox82->Size = System::Drawing::Size(73, 17);
			this->checkBox82->TabIndex = 27;
			this->checkBox82->Text = L"Overhead";
			this->checkBox82->UseVisualStyleBackColor = true;
			// 
			// checkBox83
			// 
			this->checkBox83->AutoSize = true;
			this->checkBox83->Checked = true;
			this->checkBox83->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox83->Enabled = false;
			this->checkBox83->Location = System::Drawing::Point(156, 168);
			this->checkBox83->Name = L"checkBox83";
			this->checkBox83->Size = System::Drawing::Size(88, 17);
			this->checkBox83->TabIndex = 26;
			this->checkBox83->Text = L"Lost Packets";
			this->checkBox83->UseVisualStyleBackColor = true;
			// 
			// checkBox84
			// 
			this->checkBox84->AutoSize = true;
			this->checkBox84->Checked = true;
			this->checkBox84->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox84->Enabled = false;
			this->checkBox84->Location = System::Drawing::Point(15, 161);
			this->checkBox84->Name = L"checkBox84";
			this->checkBox84->Size = System::Drawing::Size(123, 17);
			this->checkBox84->TabIndex = 25;
			this->checkBox84->Text = L"Total Dropped Bytes";
			this->checkBox84->UseVisualStyleBackColor = true;
			// 
			// checkBox85
			// 
			this->checkBox85->AutoSize = true;
			this->checkBox85->Checked = true;
			this->checkBox85->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox85->Enabled = false;
			this->checkBox85->Location = System::Drawing::Point(156, 117);
			this->checkBox85->Name = L"checkBox85";
			this->checkBox85->Size = System::Drawing::Size(136, 17);
			this->checkBox85->TabIndex = 24;
			this->checkBox85->Text = L"Total Dropped Packets";
			this->checkBox85->UseVisualStyleBackColor = true;
			// 
			// checkBox86
			// 
			this->checkBox86->AutoSize = true;
			this->checkBox86->Checked = true;
			this->checkBox86->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox86->Enabled = false;
			this->checkBox86->Location = System::Drawing::Point(15, 115);
			this->checkBox86->Name = L"checkBox86";
			this->checkBox86->Size = System::Drawing::Size(140, 17);
			this->checkBox86->TabIndex = 23;
			this->checkBox86->Text = L"Total Received packets";
			this->checkBox86->UseVisualStyleBackColor = true;
			// 
			// checkBox87
			// 
			this->checkBox87->AutoSize = true;
			this->checkBox87->Checked = true;
			this->checkBox87->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox87->Enabled = false;
			this->checkBox87->Location = System::Drawing::Point(156, 70);
			this->checkBox87->Name = L"checkBox87";
			this->checkBox87->Size = System::Drawing::Size(117, 17);
			this->checkBox87->TabIndex = 22;
			this->checkBox87->Text = L"Total Sent Packets";
			this->checkBox87->UseVisualStyleBackColor = true;
			// 
			// checkBox88
			// 
			this->checkBox88->AutoSize = true;
			this->checkBox88->Checked = true;
			this->checkBox88->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox88->Enabled = false;
			this->checkBox88->Location = System::Drawing::Point(15, 70);
			this->checkBox88->Name = L"checkBox88";
			this->checkBox88->Size = System::Drawing::Size(109, 17);
			this->checkBox88->TabIndex = 21;
			this->checkBox88->Text = L"End to End Delay";
			this->checkBox88->UseVisualStyleBackColor = true;
			// 
			// checkBox89
			// 
			this->checkBox89->AutoSize = true;
			this->checkBox89->Checked = true;
			this->checkBox89->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox89->Enabled = false;
			this->checkBox89->Location = System::Drawing::Point(156, 27);
			this->checkBox89->Name = L"checkBox89";
			this->checkBox89->Size = System::Drawing::Size(78, 17);
			this->checkBox89->TabIndex = 20;
			this->checkBox89->Text = L"Normalized";
			this->checkBox89->UseVisualStyleBackColor = true;
			// 
			// checkBox90
			// 
			this->checkBox90->AutoSize = true;
			this->checkBox90->Checked = true;
			this->checkBox90->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox90->Enabled = false;
			this->checkBox90->Location = System::Drawing::Point(16, 27);
			this->checkBox90->Name = L"checkBox90";
			this->checkBox90->Size = System::Drawing::Size(129, 17);
			this->checkBox90->TabIndex = 19;
			this->checkBox90->Text = L"Packet Delivery Ratio";
			this->checkBox90->UseVisualStyleBackColor = true;
			// 
			// checkBox91
			// 
			this->checkBox91->AutoSize = true;
			this->checkBox91->Checked = true;
			this->checkBox91->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox91->Enabled = false;
			this->checkBox91->Location = System::Drawing::Point(156, 207);
			this->checkBox91->Name = L"checkBox91";
			this->checkBox91->Size = System::Drawing::Size(143, 17);
			this->checkBox91->TabIndex = 28;
			this->checkBox91->Text = L"Total Simulation Packets";
			this->checkBox91->UseVisualStyleBackColor = true;
			// 
			// checkBox92
			// 
			this->checkBox92->AutoSize = true;
			this->checkBox92->Checked = true;
			this->checkBox92->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox92->Enabled = false;
			this->checkBox92->Location = System::Drawing::Point(15, 207);
			this->checkBox92->Name = L"checkBox92";
			this->checkBox92->Size = System::Drawing::Size(73, 17);
			this->checkBox92->TabIndex = 27;
			this->checkBox92->Text = L"Overhead";
			this->checkBox92->UseVisualStyleBackColor = true;
			// 
			// checkBox93
			// 
			this->checkBox93->AutoSize = true;
			this->checkBox93->Checked = true;
			this->checkBox93->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox93->Enabled = false;
			this->checkBox93->Location = System::Drawing::Point(156, 168);
			this->checkBox93->Name = L"checkBox93";
			this->checkBox93->Size = System::Drawing::Size(88, 17);
			this->checkBox93->TabIndex = 26;
			this->checkBox93->Text = L"Lost Packets";
			this->checkBox93->UseVisualStyleBackColor = true;
			// 
			// checkBox94
			// 
			this->checkBox94->AutoSize = true;
			this->checkBox94->Checked = true;
			this->checkBox94->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox94->Enabled = false;
			this->checkBox94->Location = System::Drawing::Point(15, 161);
			this->checkBox94->Name = L"checkBox94";
			this->checkBox94->Size = System::Drawing::Size(123, 17);
			this->checkBox94->TabIndex = 25;
			this->checkBox94->Text = L"Total Dropped Bytes";
			this->checkBox94->UseVisualStyleBackColor = true;
			// 
			// checkBox95
			// 
			this->checkBox95->AutoSize = true;
			this->checkBox95->Checked = true;
			this->checkBox95->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox95->Enabled = false;
			this->checkBox95->Location = System::Drawing::Point(156, 117);
			this->checkBox95->Name = L"checkBox95";
			this->checkBox95->Size = System::Drawing::Size(136, 17);
			this->checkBox95->TabIndex = 24;
			this->checkBox95->Text = L"Total Dropped Packets";
			this->checkBox95->UseVisualStyleBackColor = true;
			// 
			// checkBox96
			// 
			this->checkBox96->AutoSize = true;
			this->checkBox96->Checked = true;
			this->checkBox96->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox96->Enabled = false;
			this->checkBox96->Location = System::Drawing::Point(15, 115);
			this->checkBox96->Name = L"checkBox96";
			this->checkBox96->Size = System::Drawing::Size(140, 17);
			this->checkBox96->TabIndex = 23;
			this->checkBox96->Text = L"Total Received packets";
			this->checkBox96->UseVisualStyleBackColor = true;
			// 
			// checkBox97
			// 
			this->checkBox97->AutoSize = true;
			this->checkBox97->Checked = true;
			this->checkBox97->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox97->Enabled = false;
			this->checkBox97->Location = System::Drawing::Point(156, 70);
			this->checkBox97->Name = L"checkBox97";
			this->checkBox97->Size = System::Drawing::Size(117, 17);
			this->checkBox97->TabIndex = 22;
			this->checkBox97->Text = L"Total Sent Packets";
			this->checkBox97->UseVisualStyleBackColor = true;
			// 
			// checkBox98
			// 
			this->checkBox98->AutoSize = true;
			this->checkBox98->Checked = true;
			this->checkBox98->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox98->Enabled = false;
			this->checkBox98->Location = System::Drawing::Point(15, 70);
			this->checkBox98->Name = L"checkBox98";
			this->checkBox98->Size = System::Drawing::Size(109, 17);
			this->checkBox98->TabIndex = 21;
			this->checkBox98->Text = L"End to End Delay";
			this->checkBox98->UseVisualStyleBackColor = true;
			// 
			// checkBox99
			// 
			this->checkBox99->AutoSize = true;
			this->checkBox99->Checked = true;
			this->checkBox99->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox99->Enabled = false;
			this->checkBox99->Location = System::Drawing::Point(156, 27);
			this->checkBox99->Name = L"checkBox99";
			this->checkBox99->Size = System::Drawing::Size(78, 17);
			this->checkBox99->TabIndex = 20;
			this->checkBox99->Text = L"Normalized";
			this->checkBox99->UseVisualStyleBackColor = true;
			// 
			// checkBox100
			// 
			this->checkBox100->AutoSize = true;
			this->checkBox100->Checked = true;
			this->checkBox100->CheckState = System::Windows::Forms::CheckState::Indeterminate;
			this->checkBox100->Enabled = false;
			this->checkBox100->Location = System::Drawing::Point(16, 27);
			this->checkBox100->Name = L"checkBox100";
			this->checkBox100->Size = System::Drawing::Size(129, 17);
			this->checkBox100->TabIndex = 19;
			this->checkBox100->Text = L"Packet Delivery Ratio";
			this->checkBox100->UseVisualStyleBackColor = true;
			// 
			// tabPage4
			// 
			this->tabPage4->BackColor = System::Drawing::Color::White;
			this->tabPage4->Controls->Add(this->label19);
			this->tabPage4->Controls->Add(this->label20);
			this->tabPage4->Controls->Add(this->label21);
			this->tabPage4->ForeColor = System::Drawing::SystemColors::ActiveBorder;
			this->tabPage4->Location = System::Drawing::Point(4, 22);
			this->tabPage4->Name = L"tabPage4";
			this->tabPage4->Padding = System::Windows::Forms::Padding(3);
			this->tabPage4->Size = System::Drawing::Size(314, 251);
			this->tabPage4->TabIndex = 1;
			this->tabPage4->Text = L"Results";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label19->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label19->Location = System::Drawing::Point(117, 161);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(191, 57);
			this->label19->TabIndex = 3;
			this->label19->Text = L"Tab Pages";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label20->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label20->Location = System::Drawing::Point(3, 8);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(211, 76);
			this->label20->TabIndex = 2;
			this->label20->Text = L"Analysis";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label21->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label21->Location = System::Drawing::Point(62, 93);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(137, 57);
			this->label21->TabIndex = 1;
			this->label21->Text = L"Results";
			// 
			// tabPage5
			// 
			this->tabPage5->Controls->Add(this->label22);
			this->tabPage5->Controls->Add(this->label23);
			this->tabPage5->Controls->Add(this->label24);
			this->tabPage5->Controls->Add(this->label25);
			this->tabPage5->Controls->Add(this->label26);
			this->tabPage5->Controls->Add(this->label27);
			this->tabPage5->Controls->Add(this->label28);
			this->tabPage5->Controls->Add(this->label29);
			this->tabPage5->Controls->Add(this->label30);
			this->tabPage5->Controls->Add(this->label31);
			this->tabPage5->Controls->Add(this->label32);
			this->tabPage5->Controls->Add(this->checkBox1);
			this->tabPage5->Controls->Add(this->checkBox2);
			this->tabPage5->Controls->Add(this->checkBox3);
			this->tabPage5->Controls->Add(this->checkBox4);
			this->tabPage5->Controls->Add(this->checkBox5);
			this->tabPage5->Controls->Add(this->checkBox6);
			this->tabPage5->Controls->Add(this->checkBox7);
			this->tabPage5->Controls->Add(this->checkBox8);
			this->tabPage5->Controls->Add(this->checkBox9);
			this->tabPage5->Controls->Add(this->checkBox10);
			this->tabPage5->Controls->Add(this->checkBox11);
			this->tabPage5->Location = System::Drawing::Point(4, 22);
			this->tabPage5->Name = L"tabPage5";
			this->tabPage5->Size = System::Drawing::Size(314, 251);
			this->tabPage5->TabIndex = 2;
			this->tabPage5->Text = L"File 1";
			this->tabPage5->UseVisualStyleBackColor = true;
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(152, 231);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(13, 13);
			this->label22->TabIndex = 40;
			this->label22->Text = L"0";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(152, 207);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(13, 13);
			this->label23->TabIndex = 39;
			this->label23->Text = L"0";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(152, 187);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(13, 13);
			this->label24->TabIndex = 38;
			this->label24->Text = L"0";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(152, 163);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(13, 13);
			this->label25->TabIndex = 37;
			this->label25->Text = L"0";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(152, 144);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 13);
			this->label26->TabIndex = 36;
			this->label26->Text = L"0";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(152, 118);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(13, 13);
			this->label27->TabIndex = 35;
			this->label27->Text = L"0";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(152, 95);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(13, 13);
			this->label28->TabIndex = 34;
			this->label28->Text = L"0";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(152, 72);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(13, 13);
			this->label29->TabIndex = 33;
			this->label29->Text = L"0";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(152, 49);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(13, 13);
			this->label30->TabIndex = 32;
			this->label30->Text = L"0";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(152, 28);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(13, 13);
			this->label31->TabIndex = 31;
			this->label31->Text = L"0";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(89, 4);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(10, 13);
			this->label32->TabIndex = 30;
			this->label32->Text = L":";
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Enabled = false;
			this->checkBox1->Location = System::Drawing::Point(6, 4);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(82, 17);
			this->checkBox1->TabIndex = 29;
			this->checkBox1->Text = L" File Name: ";
			this->checkBox1->UseVisualStyleBackColor = true;
			// 
			// checkBox2
			// 
			this->checkBox2->AutoSize = true;
			this->checkBox2->Enabled = false;
			this->checkBox2->Location = System::Drawing::Point(6, 231);
			this->checkBox2->Name = L"checkBox2";
			this->checkBox2->Size = System::Drawing::Size(143, 17);
			this->checkBox2->TabIndex = 28;
			this->checkBox2->Text = L"Total Simulation Packets";
			this->checkBox2->UseVisualStyleBackColor = true;
			// 
			// checkBox3
			// 
			this->checkBox3->AutoSize = true;
			this->checkBox3->Enabled = false;
			this->checkBox3->Location = System::Drawing::Point(6, 208);
			this->checkBox3->Name = L"checkBox3";
			this->checkBox3->Size = System::Drawing::Size(73, 17);
			this->checkBox3->TabIndex = 27;
			this->checkBox3->Text = L"Overhead";
			this->checkBox3->UseVisualStyleBackColor = true;
			// 
			// checkBox4
			// 
			this->checkBox4->AutoSize = true;
			this->checkBox4->Enabled = false;
			this->checkBox4->Location = System::Drawing::Point(6, 187);
			this->checkBox4->Name = L"checkBox4";
			this->checkBox4->Size = System::Drawing::Size(88, 17);
			this->checkBox4->TabIndex = 26;
			this->checkBox4->Text = L"Lost Packets";
			this->checkBox4->UseVisualStyleBackColor = true;
			// 
			// checkBox5
			// 
			this->checkBox5->AutoSize = true;
			this->checkBox5->Enabled = false;
			this->checkBox5->Location = System::Drawing::Point(6, 163);
			this->checkBox5->Name = L"checkBox5";
			this->checkBox5->Size = System::Drawing::Size(123, 17);
			this->checkBox5->TabIndex = 25;
			this->checkBox5->Text = L"Total Dropped Bytes";
			this->checkBox5->UseVisualStyleBackColor = true;
			// 
			// checkBox6
			// 
			this->checkBox6->AutoSize = true;
			this->checkBox6->Enabled = false;
			this->checkBox6->Location = System::Drawing::Point(6, 140);
			this->checkBox6->Name = L"checkBox6";
			this->checkBox6->Size = System::Drawing::Size(136, 17);
			this->checkBox6->TabIndex = 24;
			this->checkBox6->Text = L"Total Dropped Packets";
			this->checkBox6->UseVisualStyleBackColor = true;
			// 
			// checkBox7
			// 
			this->checkBox7->AutoSize = true;
			this->checkBox7->Enabled = false;
			this->checkBox7->Location = System::Drawing::Point(6, 117);
			this->checkBox7->Name = L"checkBox7";
			this->checkBox7->Size = System::Drawing::Size(140, 17);
			this->checkBox7->TabIndex = 23;
			this->checkBox7->Text = L"Total Received packets";
			this->checkBox7->UseVisualStyleBackColor = true;
			// 
			// checkBox8
			// 
			this->checkBox8->AutoSize = true;
			this->checkBox8->Enabled = false;
			this->checkBox8->Location = System::Drawing::Point(6, 94);
			this->checkBox8->Name = L"checkBox8";
			this->checkBox8->Size = System::Drawing::Size(117, 17);
			this->checkBox8->TabIndex = 22;
			this->checkBox8->Text = L"Total Sent Packets";
			this->checkBox8->UseVisualStyleBackColor = true;
			// 
			// checkBox9
			// 
			this->checkBox9->AutoSize = true;
			this->checkBox9->Enabled = false;
			this->checkBox9->Location = System::Drawing::Point(6, 71);
			this->checkBox9->Name = L"checkBox9";
			this->checkBox9->Size = System::Drawing::Size(109, 17);
			this->checkBox9->TabIndex = 21;
			this->checkBox9->Text = L"End to End Delay";
			this->checkBox9->UseVisualStyleBackColor = true;
			// 
			// checkBox10
			// 
			this->checkBox10->AutoSize = true;
			this->checkBox10->Enabled = false;
			this->checkBox10->Location = System::Drawing::Point(6, 48);
			this->checkBox10->Name = L"checkBox10";
			this->checkBox10->Size = System::Drawing::Size(78, 17);
			this->checkBox10->TabIndex = 20;
			this->checkBox10->Text = L"Normalized";
			this->checkBox10->UseVisualStyleBackColor = true;
			// 
			// checkBox11
			// 
			this->checkBox11->AutoSize = true;
			this->checkBox11->Enabled = false;
			this->checkBox11->Location = System::Drawing::Point(6, 27);
			this->checkBox11->Name = L"checkBox11";
			this->checkBox11->Size = System::Drawing::Size(129, 17);
			this->checkBox11->TabIndex = 19;
			this->checkBox11->Text = L"Packet Delivery Ratio";
			this->checkBox11->UseVisualStyleBackColor = true;
			// 
			// checkBox12
			// 
			this->checkBox12->AutoSize = true;
			this->checkBox12->Checked = true;
			this->checkBox12->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox12->Enabled = false;
			this->checkBox12->Location = System::Drawing::Point(146, 29);
			this->checkBox12->Name = L"checkBox12";
			this->checkBox12->Size = System::Drawing::Size(55, 17);
			this->checkBox12->TabIndex = 44;
			this->checkBox12->Text = L"Time: ";
			this->checkBox12->UseVisualStyleBackColor = true;
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(197, 31);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(49, 13);
			this->label33->TabIndex = 43;
			this->label33->Text = L"00:00:00";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(89, 30);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(53, 13);
			this->label34->TabIndex = 42;
			this->label34->Text = L"Unknown";
			// 
			// checkBox13
			// 
			this->checkBox13->AutoSize = true;
			this->checkBox13->Checked = true;
			this->checkBox13->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox13->Enabled = false;
			this->checkBox13->Location = System::Drawing::Point(6, 28);
			this->checkBox13->Name = L"checkBox13";
			this->checkBox13->Size = System::Drawing::Size(86, 17);
			this->checkBox13->TabIndex = 41;
			this->checkBox13->Text = L" File Format: ";
			this->checkBox13->UseVisualStyleBackColor = true;
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(143, 251);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(13, 13);
			this->label35->TabIndex = 40;
			this->label35->Text = L"0";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(143, 231);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(13, 13);
			this->label36->TabIndex = 39;
			this->label36->Text = L"0";
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(143, 211);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(13, 13);
			this->label37->TabIndex = 38;
			this->label37->Text = L"0";
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(143, 188);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(13, 13);
			this->label38->TabIndex = 37;
			this->label38->Text = L"0";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(143, 163);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(13, 13);
			this->label39->TabIndex = 36;
			this->label39->Text = L"0";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(143, 141);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(13, 13);
			this->label40->TabIndex = 35;
			this->label40->Text = L"0";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(143, 115);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(13, 13);
			this->label41->TabIndex = 34;
			this->label41->Text = L"0";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(143, 92);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(13, 13);
			this->label42->TabIndex = 33;
			this->label42->Text = L"0";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Location = System::Drawing::Point(143, 70);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(13, 13);
			this->label43->TabIndex = 32;
			this->label43->Text = L"0";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(143, 51);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(13, 13);
			this->label44->TabIndex = 31;
			this->label44->Text = L"0";
			// 
			// checkBox14
			// 
			this->checkBox14->AutoSize = true;
			this->checkBox14->Checked = true;
			this->checkBox14->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox14->Enabled = false;
			this->checkBox14->Location = System::Drawing::Point(6, 4);
			this->checkBox14->Name = L"checkBox14";
			this->checkBox14->Size = System::Drawing::Size(82, 17);
			this->checkBox14->TabIndex = 29;
			this->checkBox14->Text = L" File Name: ";
			this->checkBox14->UseVisualStyleBackColor = true;
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(78, 5);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(10, 13);
			this->label45->TabIndex = 30;
			this->label45->Text = L":";
			// 
			// checkBox15
			// 
			this->checkBox15->AutoSize = true;
			this->checkBox15->Enabled = false;
			this->checkBox15->Location = System::Drawing::Point(6, 250);
			this->checkBox15->Name = L"checkBox15";
			this->checkBox15->Size = System::Drawing::Size(143, 17);
			this->checkBox15->TabIndex = 28;
			this->checkBox15->Text = L"Total Simulation Packets";
			this->checkBox15->UseVisualStyleBackColor = true;
			// 
			// checkBox16
			// 
			this->checkBox16->AutoSize = true;
			this->checkBox16->Enabled = false;
			this->checkBox16->Location = System::Drawing::Point(6, 227);
			this->checkBox16->Name = L"checkBox16";
			this->checkBox16->Size = System::Drawing::Size(73, 17);
			this->checkBox16->TabIndex = 27;
			this->checkBox16->Text = L"Overhead";
			this->checkBox16->UseVisualStyleBackColor = true;
			// 
			// checkBox17
			// 
			this->checkBox17->AutoSize = true;
			this->checkBox17->Enabled = false;
			this->checkBox17->Location = System::Drawing::Point(6, 207);
			this->checkBox17->Name = L"checkBox17";
			this->checkBox17->Size = System::Drawing::Size(88, 17);
			this->checkBox17->TabIndex = 26;
			this->checkBox17->Text = L"Lost Packets";
			this->checkBox17->UseVisualStyleBackColor = true;
			// 
			// checkBox18
			// 
			this->checkBox18->AutoSize = true;
			this->checkBox18->Enabled = false;
			this->checkBox18->Location = System::Drawing::Point(6, 184);
			this->checkBox18->Name = L"checkBox18";
			this->checkBox18->Size = System::Drawing::Size(123, 17);
			this->checkBox18->TabIndex = 25;
			this->checkBox18->Text = L"Total Dropped Bytes";
			this->checkBox18->UseVisualStyleBackColor = true;
			// 
			// checkBox19
			// 
			this->checkBox19->AutoSize = true;
			this->checkBox19->Enabled = false;
			this->checkBox19->Location = System::Drawing::Point(6, 161);
			this->checkBox19->Name = L"checkBox19";
			this->checkBox19->Size = System::Drawing::Size(136, 17);
			this->checkBox19->TabIndex = 24;
			this->checkBox19->Text = L"Total Dropped Packets";
			this->checkBox19->UseVisualStyleBackColor = true;
			// 
			// checkBox20
			// 
			this->checkBox20->AutoSize = true;
			this->checkBox20->Enabled = false;
			this->checkBox20->Location = System::Drawing::Point(6, 138);
			this->checkBox20->Name = L"checkBox20";
			this->checkBox20->Size = System::Drawing::Size(140, 17);
			this->checkBox20->TabIndex = 23;
			this->checkBox20->Text = L"Total Received packets";
			this->checkBox20->UseVisualStyleBackColor = true;
			// 
			// checkBox21
			// 
			this->checkBox21->AutoSize = true;
			this->checkBox21->Enabled = false;
			this->checkBox21->Location = System::Drawing::Point(6, 113);
			this->checkBox21->Name = L"checkBox21";
			this->checkBox21->Size = System::Drawing::Size(117, 17);
			this->checkBox21->TabIndex = 22;
			this->checkBox21->Text = L"Total Sent Packets";
			this->checkBox21->UseVisualStyleBackColor = true;
			// 
			// checkBox22
			// 
			this->checkBox22->AutoSize = true;
			this->checkBox22->Enabled = false;
			this->checkBox22->Location = System::Drawing::Point(6, 90);
			this->checkBox22->Name = L"checkBox22";
			this->checkBox22->Size = System::Drawing::Size(109, 17);
			this->checkBox22->TabIndex = 21;
			this->checkBox22->Text = L"End to End Delay";
			this->checkBox22->UseVisualStyleBackColor = true;
			// 
			// checkBox23
			// 
			this->checkBox23->AutoSize = true;
			this->checkBox23->Enabled = false;
			this->checkBox23->Location = System::Drawing::Point(6, 68);
			this->checkBox23->Name = L"checkBox23";
			this->checkBox23->Size = System::Drawing::Size(78, 17);
			this->checkBox23->TabIndex = 20;
			this->checkBox23->Text = L"Normalized";
			this->checkBox23->UseVisualStyleBackColor = true;
			// 
			// checkBox24
			// 
			this->checkBox24->AutoSize = true;
			this->checkBox24->Enabled = false;
			this->checkBox24->Location = System::Drawing::Point(6, 48);
			this->checkBox24->Name = L"checkBox24";
			this->checkBox24->Size = System::Drawing::Size(129, 17);
			this->checkBox24->TabIndex = 19;
			this->checkBox24->Text = L"Packet Delivery Ratio";
			this->checkBox24->UseVisualStyleBackColor = true;
			// 
			// checkBox25
			// 
			this->checkBox25->AutoSize = true;
			this->checkBox25->Checked = true;
			this->checkBox25->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox25->Enabled = false;
			this->checkBox25->Location = System::Drawing::Point(146, 29);
			this->checkBox25->Name = L"checkBox25";
			this->checkBox25->Size = System::Drawing::Size(55, 17);
			this->checkBox25->TabIndex = 44;
			this->checkBox25->Text = L"Time: ";
			this->checkBox25->UseVisualStyleBackColor = true;
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(197, 31);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(49, 13);
			this->label46->TabIndex = 43;
			this->label46->Text = L"00:00:00";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(89, 30);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(53, 13);
			this->label47->TabIndex = 42;
			this->label47->Text = L"Unknown";
			// 
			// checkBox26
			// 
			this->checkBox26->AutoSize = true;
			this->checkBox26->Checked = true;
			this->checkBox26->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox26->Enabled = false;
			this->checkBox26->Location = System::Drawing::Point(6, 28);
			this->checkBox26->Name = L"checkBox26";
			this->checkBox26->Size = System::Drawing::Size(86, 17);
			this->checkBox26->TabIndex = 41;
			this->checkBox26->Text = L" File Format: ";
			this->checkBox26->UseVisualStyleBackColor = true;
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Location = System::Drawing::Point(143, 251);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(13, 13);
			this->label48->TabIndex = 40;
			this->label48->Text = L"0";
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Location = System::Drawing::Point(143, 231);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(13, 13);
			this->label49->TabIndex = 39;
			this->label49->Text = L"0";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Location = System::Drawing::Point(143, 211);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(13, 13);
			this->label50->TabIndex = 38;
			this->label50->Text = L"0";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Location = System::Drawing::Point(143, 188);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(13, 13);
			this->label51->TabIndex = 37;
			this->label51->Text = L"0";
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Location = System::Drawing::Point(143, 163);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(13, 13);
			this->label52->TabIndex = 36;
			this->label52->Text = L"0";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Location = System::Drawing::Point(143, 141);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(13, 13);
			this->label53->TabIndex = 35;
			this->label53->Text = L"0";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Location = System::Drawing::Point(143, 115);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(13, 13);
			this->label54->TabIndex = 34;
			this->label54->Text = L"0";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Location = System::Drawing::Point(143, 92);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(13, 13);
			this->label55->TabIndex = 33;
			this->label55->Text = L"0";
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Location = System::Drawing::Point(143, 70);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(13, 13);
			this->label56->TabIndex = 32;
			this->label56->Text = L"0";
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Location = System::Drawing::Point(143, 51);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(13, 13);
			this->label57->TabIndex = 31;
			this->label57->Text = L"0";
			// 
			// checkBox27
			// 
			this->checkBox27->AutoSize = true;
			this->checkBox27->Checked = true;
			this->checkBox27->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox27->Enabled = false;
			this->checkBox27->Location = System::Drawing::Point(6, 4);
			this->checkBox27->Name = L"checkBox27";
			this->checkBox27->Size = System::Drawing::Size(82, 17);
			this->checkBox27->TabIndex = 29;
			this->checkBox27->Text = L" File Name: ";
			this->checkBox27->UseVisualStyleBackColor = true;
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Location = System::Drawing::Point(78, 5);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(10, 13);
			this->label58->TabIndex = 30;
			this->label58->Text = L":";
			// 
			// checkBox28
			// 
			this->checkBox28->AutoSize = true;
			this->checkBox28->Enabled = false;
			this->checkBox28->Location = System::Drawing::Point(6, 250);
			this->checkBox28->Name = L"checkBox28";
			this->checkBox28->Size = System::Drawing::Size(143, 17);
			this->checkBox28->TabIndex = 28;
			this->checkBox28->Text = L"Total Simulation Packets";
			this->checkBox28->UseVisualStyleBackColor = true;
			// 
			// checkBox29
			// 
			this->checkBox29->AutoSize = true;
			this->checkBox29->Enabled = false;
			this->checkBox29->Location = System::Drawing::Point(6, 227);
			this->checkBox29->Name = L"checkBox29";
			this->checkBox29->Size = System::Drawing::Size(73, 17);
			this->checkBox29->TabIndex = 27;
			this->checkBox29->Text = L"Overhead";
			this->checkBox29->UseVisualStyleBackColor = true;
			// 
			// checkBox30
			// 
			this->checkBox30->AutoSize = true;
			this->checkBox30->Enabled = false;
			this->checkBox30->Location = System::Drawing::Point(6, 207);
			this->checkBox30->Name = L"checkBox30";
			this->checkBox30->Size = System::Drawing::Size(88, 17);
			this->checkBox30->TabIndex = 26;
			this->checkBox30->Text = L"Lost Packets";
			this->checkBox30->UseVisualStyleBackColor = true;
			// 
			// checkBox31
			// 
			this->checkBox31->AutoSize = true;
			this->checkBox31->Enabled = false;
			this->checkBox31->Location = System::Drawing::Point(6, 184);
			this->checkBox31->Name = L"checkBox31";
			this->checkBox31->Size = System::Drawing::Size(123, 17);
			this->checkBox31->TabIndex = 25;
			this->checkBox31->Text = L"Total Dropped Bytes";
			this->checkBox31->UseVisualStyleBackColor = true;
			// 
			// checkBox32
			// 
			this->checkBox32->AutoSize = true;
			this->checkBox32->Enabled = false;
			this->checkBox32->Location = System::Drawing::Point(6, 161);
			this->checkBox32->Name = L"checkBox32";
			this->checkBox32->Size = System::Drawing::Size(136, 17);
			this->checkBox32->TabIndex = 24;
			this->checkBox32->Text = L"Total Dropped Packets";
			this->checkBox32->UseVisualStyleBackColor = true;
			// 
			// checkBox33
			// 
			this->checkBox33->AutoSize = true;
			this->checkBox33->Enabled = false;
			this->checkBox33->Location = System::Drawing::Point(6, 138);
			this->checkBox33->Name = L"checkBox33";
			this->checkBox33->Size = System::Drawing::Size(140, 17);
			this->checkBox33->TabIndex = 23;
			this->checkBox33->Text = L"Total Received packets";
			this->checkBox33->UseVisualStyleBackColor = true;
			// 
			// checkBox34
			// 
			this->checkBox34->AutoSize = true;
			this->checkBox34->Enabled = false;
			this->checkBox34->Location = System::Drawing::Point(6, 113);
			this->checkBox34->Name = L"checkBox34";
			this->checkBox34->Size = System::Drawing::Size(117, 17);
			this->checkBox34->TabIndex = 22;
			this->checkBox34->Text = L"Total Sent Packets";
			this->checkBox34->UseVisualStyleBackColor = true;
			// 
			// checkBox35
			// 
			this->checkBox35->AutoSize = true;
			this->checkBox35->Enabled = false;
			this->checkBox35->Location = System::Drawing::Point(6, 90);
			this->checkBox35->Name = L"checkBox35";
			this->checkBox35->Size = System::Drawing::Size(109, 17);
			this->checkBox35->TabIndex = 21;
			this->checkBox35->Text = L"End to End Delay";
			this->checkBox35->UseVisualStyleBackColor = true;
			// 
			// checkBox36
			// 
			this->checkBox36->AutoSize = true;
			this->checkBox36->Enabled = false;
			this->checkBox36->Location = System::Drawing::Point(6, 68);
			this->checkBox36->Name = L"checkBox36";
			this->checkBox36->Size = System::Drawing::Size(78, 17);
			this->checkBox36->TabIndex = 20;
			this->checkBox36->Text = L"Normalized";
			this->checkBox36->UseVisualStyleBackColor = true;
			// 
			// checkBox37
			// 
			this->checkBox37->AutoSize = true;
			this->checkBox37->Enabled = false;
			this->checkBox37->Location = System::Drawing::Point(6, 48);
			this->checkBox37->Name = L"checkBox37";
			this->checkBox37->Size = System::Drawing::Size(129, 17);
			this->checkBox37->TabIndex = 19;
			this->checkBox37->Text = L"Packet Delivery Ratio";
			this->checkBox37->UseVisualStyleBackColor = true;
			// 
			// checkBox38
			// 
			this->checkBox38->AutoSize = true;
			this->checkBox38->Checked = true;
			this->checkBox38->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox38->Enabled = false;
			this->checkBox38->Location = System::Drawing::Point(146, 29);
			this->checkBox38->Name = L"checkBox38";
			this->checkBox38->Size = System::Drawing::Size(55, 17);
			this->checkBox38->TabIndex = 44;
			this->checkBox38->Text = L"Time: ";
			this->checkBox38->UseVisualStyleBackColor = true;
			// 
			// label59
			// 
			this->label59->AutoSize = true;
			this->label59->Location = System::Drawing::Point(197, 31);
			this->label59->Name = L"label59";
			this->label59->Size = System::Drawing::Size(49, 13);
			this->label59->TabIndex = 43;
			this->label59->Text = L"00:00:00";
			// 
			// checkBox39
			// 
			this->checkBox39->AutoSize = true;
			this->checkBox39->Checked = true;
			this->checkBox39->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox39->Enabled = false;
			this->checkBox39->Location = System::Drawing::Point(6, 28);
			this->checkBox39->Name = L"checkBox39";
			this->checkBox39->Size = System::Drawing::Size(86, 17);
			this->checkBox39->TabIndex = 41;
			this->checkBox39->Text = L" File Format: ";
			this->checkBox39->UseVisualStyleBackColor = true;
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Location = System::Drawing::Point(143, 251);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(13, 13);
			this->label60->TabIndex = 40;
			this->label60->Text = L"0";
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Location = System::Drawing::Point(143, 231);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(13, 13);
			this->label61->TabIndex = 39;
			this->label61->Text = L"0";
			// 
			// label62
			// 
			this->label62->AutoSize = true;
			this->label62->Location = System::Drawing::Point(143, 211);
			this->label62->Name = L"label62";
			this->label62->Size = System::Drawing::Size(13, 13);
			this->label62->TabIndex = 38;
			this->label62->Text = L"0";
			// 
			// label63
			// 
			this->label63->AutoSize = true;
			this->label63->Location = System::Drawing::Point(143, 188);
			this->label63->Name = L"label63";
			this->label63->Size = System::Drawing::Size(13, 13);
			this->label63->TabIndex = 37;
			this->label63->Text = L"0";
			// 
			// label64
			// 
			this->label64->AutoSize = true;
			this->label64->Location = System::Drawing::Point(143, 163);
			this->label64->Name = L"label64";
			this->label64->Size = System::Drawing::Size(13, 13);
			this->label64->TabIndex = 36;
			this->label64->Text = L"0";
			// 
			// label65
			// 
			this->label65->AutoSize = true;
			this->label65->Location = System::Drawing::Point(143, 141);
			this->label65->Name = L"label65";
			this->label65->Size = System::Drawing::Size(13, 13);
			this->label65->TabIndex = 35;
			this->label65->Text = L"0";
			// 
			// label66
			// 
			this->label66->AutoSize = true;
			this->label66->Location = System::Drawing::Point(143, 115);
			this->label66->Name = L"label66";
			this->label66->Size = System::Drawing::Size(13, 13);
			this->label66->TabIndex = 34;
			this->label66->Text = L"0";
			// 
			// label67
			// 
			this->label67->AutoSize = true;
			this->label67->Location = System::Drawing::Point(143, 92);
			this->label67->Name = L"label67";
			this->label67->Size = System::Drawing::Size(13, 13);
			this->label67->TabIndex = 33;
			this->label67->Text = L"0";
			// 
			// label68
			// 
			this->label68->AutoSize = true;
			this->label68->Location = System::Drawing::Point(89, 30);
			this->label68->Name = L"label68";
			this->label68->Size = System::Drawing::Size(53, 13);
			this->label68->TabIndex = 42;
			this->label68->Text = L"Unknown";
			// 
			// label69
			// 
			this->label69->AutoSize = true;
			this->label69->Location = System::Drawing::Point(143, 70);
			this->label69->Name = L"label69";
			this->label69->Size = System::Drawing::Size(13, 13);
			this->label69->TabIndex = 32;
			this->label69->Text = L"0";
			// 
			// label70
			// 
			this->label70->AutoSize = true;
			this->label70->Location = System::Drawing::Point(143, 51);
			this->label70->Name = L"label70";
			this->label70->Size = System::Drawing::Size(13, 13);
			this->label70->TabIndex = 31;
			this->label70->Text = L"0";
			// 
			// label71
			// 
			this->label71->AutoSize = true;
			this->label71->Location = System::Drawing::Point(78, 5);
			this->label71->Name = L"label71";
			this->label71->Size = System::Drawing::Size(10, 13);
			this->label71->TabIndex = 30;
			this->label71->Text = L":";
			// 
			// checkBox40
			// 
			this->checkBox40->AutoSize = true;
			this->checkBox40->Checked = true;
			this->checkBox40->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox40->Enabled = false;
			this->checkBox40->Location = System::Drawing::Point(6, 4);
			this->checkBox40->Name = L"checkBox40";
			this->checkBox40->Size = System::Drawing::Size(82, 17);
			this->checkBox40->TabIndex = 29;
			this->checkBox40->Text = L" File Name: ";
			this->checkBox40->UseVisualStyleBackColor = true;
			// 
			// checkBox101
			// 
			this->checkBox101->AutoSize = true;
			this->checkBox101->Enabled = false;
			this->checkBox101->Location = System::Drawing::Point(6, 250);
			this->checkBox101->Name = L"checkBox101";
			this->checkBox101->Size = System::Drawing::Size(143, 17);
			this->checkBox101->TabIndex = 28;
			this->checkBox101->Text = L"Total Simulation Packets";
			this->checkBox101->UseVisualStyleBackColor = true;
			// 
			// checkBox102
			// 
			this->checkBox102->AutoSize = true;
			this->checkBox102->Enabled = false;
			this->checkBox102->Location = System::Drawing::Point(6, 227);
			this->checkBox102->Name = L"checkBox102";
			this->checkBox102->Size = System::Drawing::Size(73, 17);
			this->checkBox102->TabIndex = 27;
			this->checkBox102->Text = L"Overhead";
			this->checkBox102->UseVisualStyleBackColor = true;
			// 
			// checkBox103
			// 
			this->checkBox103->AutoSize = true;
			this->checkBox103->Enabled = false;
			this->checkBox103->Location = System::Drawing::Point(6, 207);
			this->checkBox103->Name = L"checkBox103";
			this->checkBox103->Size = System::Drawing::Size(88, 17);
			this->checkBox103->TabIndex = 26;
			this->checkBox103->Text = L"Lost Packets";
			this->checkBox103->UseVisualStyleBackColor = true;
			// 
			// checkBox104
			// 
			this->checkBox104->AutoSize = true;
			this->checkBox104->Enabled = false;
			this->checkBox104->Location = System::Drawing::Point(6, 184);
			this->checkBox104->Name = L"checkBox104";
			this->checkBox104->Size = System::Drawing::Size(123, 17);
			this->checkBox104->TabIndex = 25;
			this->checkBox104->Text = L"Total Dropped Bytes";
			this->checkBox104->UseVisualStyleBackColor = true;
			// 
			// checkBox105
			// 
			this->checkBox105->AutoSize = true;
			this->checkBox105->Enabled = false;
			this->checkBox105->Location = System::Drawing::Point(6, 161);
			this->checkBox105->Name = L"checkBox105";
			this->checkBox105->Size = System::Drawing::Size(136, 17);
			this->checkBox105->TabIndex = 24;
			this->checkBox105->Text = L"Total Dropped Packets";
			this->checkBox105->UseVisualStyleBackColor = true;
			// 
			// checkBox106
			// 
			this->checkBox106->AutoSize = true;
			this->checkBox106->Enabled = false;
			this->checkBox106->Location = System::Drawing::Point(6, 138);
			this->checkBox106->Name = L"checkBox106";
			this->checkBox106->Size = System::Drawing::Size(140, 17);
			this->checkBox106->TabIndex = 23;
			this->checkBox106->Text = L"Total Received packets";
			this->checkBox106->UseVisualStyleBackColor = true;
			// 
			// checkBox107
			// 
			this->checkBox107->AutoSize = true;
			this->checkBox107->Enabled = false;
			this->checkBox107->Location = System::Drawing::Point(6, 113);
			this->checkBox107->Name = L"checkBox107";
			this->checkBox107->Size = System::Drawing::Size(117, 17);
			this->checkBox107->TabIndex = 22;
			this->checkBox107->Text = L"Total Sent Packets";
			this->checkBox107->UseVisualStyleBackColor = true;
			// 
			// checkBox108
			// 
			this->checkBox108->AutoSize = true;
			this->checkBox108->Enabled = false;
			this->checkBox108->Location = System::Drawing::Point(6, 90);
			this->checkBox108->Name = L"checkBox108";
			this->checkBox108->Size = System::Drawing::Size(109, 17);
			this->checkBox108->TabIndex = 21;
			this->checkBox108->Text = L"End to End Delay";
			this->checkBox108->UseVisualStyleBackColor = true;
			// 
			// checkBox109
			// 
			this->checkBox109->AutoSize = true;
			this->checkBox109->Enabled = false;
			this->checkBox109->Location = System::Drawing::Point(6, 68);
			this->checkBox109->Name = L"checkBox109";
			this->checkBox109->Size = System::Drawing::Size(78, 17);
			this->checkBox109->TabIndex = 20;
			this->checkBox109->Text = L"Normalized";
			this->checkBox109->UseVisualStyleBackColor = true;
			// 
			// checkBox110
			// 
			this->checkBox110->AutoSize = true;
			this->checkBox110->Enabled = false;
			this->checkBox110->Location = System::Drawing::Point(6, 48);
			this->checkBox110->Name = L"checkBox110";
			this->checkBox110->Size = System::Drawing::Size(129, 17);
			this->checkBox110->TabIndex = 19;
			this->checkBox110->Text = L"Packet Delivery Ratio";
			this->checkBox110->UseVisualStyleBackColor = true;
			// 
			// checkBox111
			// 
			this->checkBox111->AutoSize = true;
			this->checkBox111->Checked = true;
			this->checkBox111->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox111->Enabled = false;
			this->checkBox111->Location = System::Drawing::Point(146, 29);
			this->checkBox111->Name = L"checkBox111";
			this->checkBox111->Size = System::Drawing::Size(55, 17);
			this->checkBox111->TabIndex = 44;
			this->checkBox111->Text = L"Time: ";
			this->checkBox111->UseVisualStyleBackColor = true;
			// 
			// label72
			// 
			this->label72->AutoSize = true;
			this->label72->Location = System::Drawing::Point(197, 31);
			this->label72->Name = L"label72";
			this->label72->Size = System::Drawing::Size(49, 13);
			this->label72->TabIndex = 43;
			this->label72->Text = L"00:00:00";
			// 
			// checkBox112
			// 
			this->checkBox112->AutoSize = true;
			this->checkBox112->Checked = true;
			this->checkBox112->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox112->Enabled = false;
			this->checkBox112->Location = System::Drawing::Point(6, 28);
			this->checkBox112->Name = L"checkBox112";
			this->checkBox112->Size = System::Drawing::Size(86, 17);
			this->checkBox112->TabIndex = 41;
			this->checkBox112->Text = L" File Format: ";
			this->checkBox112->UseVisualStyleBackColor = true;
			// 
			// label73
			// 
			this->label73->AutoSize = true;
			this->label73->Location = System::Drawing::Point(143, 251);
			this->label73->Name = L"label73";
			this->label73->Size = System::Drawing::Size(13, 13);
			this->label73->TabIndex = 40;
			this->label73->Text = L"0";
			// 
			// label74
			// 
			this->label74->AutoSize = true;
			this->label74->Location = System::Drawing::Point(143, 231);
			this->label74->Name = L"label74";
			this->label74->Size = System::Drawing::Size(13, 13);
			this->label74->TabIndex = 39;
			this->label74->Text = L"0";
			// 
			// label75
			// 
			this->label75->AutoSize = true;
			this->label75->Location = System::Drawing::Point(143, 211);
			this->label75->Name = L"label75";
			this->label75->Size = System::Drawing::Size(13, 13);
			this->label75->TabIndex = 38;
			this->label75->Text = L"0";
			// 
			// label76
			// 
			this->label76->AutoSize = true;
			this->label76->Location = System::Drawing::Point(143, 188);
			this->label76->Name = L"label76";
			this->label76->Size = System::Drawing::Size(13, 13);
			this->label76->TabIndex = 37;
			this->label76->Text = L"0";
			// 
			// label77
			// 
			this->label77->AutoSize = true;
			this->label77->Location = System::Drawing::Point(143, 163);
			this->label77->Name = L"label77";
			this->label77->Size = System::Drawing::Size(13, 13);
			this->label77->TabIndex = 36;
			this->label77->Text = L"0";
			// 
			// label78
			// 
			this->label78->AutoSize = true;
			this->label78->Location = System::Drawing::Point(143, 141);
			this->label78->Name = L"label78";
			this->label78->Size = System::Drawing::Size(13, 13);
			this->label78->TabIndex = 35;
			this->label78->Text = L"0";
			// 
			// label79
			// 
			this->label79->AutoSize = true;
			this->label79->Location = System::Drawing::Point(143, 115);
			this->label79->Name = L"label79";
			this->label79->Size = System::Drawing::Size(13, 13);
			this->label79->TabIndex = 34;
			this->label79->Text = L"0";
			// 
			// label80
			// 
			this->label80->AutoSize = true;
			this->label80->Location = System::Drawing::Point(143, 92);
			this->label80->Name = L"label80";
			this->label80->Size = System::Drawing::Size(13, 13);
			this->label80->TabIndex = 33;
			this->label80->Text = L"0";
			// 
			// label81
			// 
			this->label81->AutoSize = true;
			this->label81->Location = System::Drawing::Point(89, 30);
			this->label81->Name = L"label81";
			this->label81->Size = System::Drawing::Size(53, 13);
			this->label81->TabIndex = 42;
			this->label81->Text = L"Unknown";
			// 
			// label82
			// 
			this->label82->AutoSize = true;
			this->label82->Location = System::Drawing::Point(143, 70);
			this->label82->Name = L"label82";
			this->label82->Size = System::Drawing::Size(13, 13);
			this->label82->TabIndex = 32;
			this->label82->Text = L"0";
			// 
			// label83
			// 
			this->label83->AutoSize = true;
			this->label83->Location = System::Drawing::Point(143, 51);
			this->label83->Name = L"label83";
			this->label83->Size = System::Drawing::Size(13, 13);
			this->label83->TabIndex = 31;
			this->label83->Text = L"0";
			// 
			// label84
			// 
			this->label84->AutoSize = true;
			this->label84->Location = System::Drawing::Point(78, 5);
			this->label84->Name = L"label84";
			this->label84->Size = System::Drawing::Size(10, 13);
			this->label84->TabIndex = 30;
			this->label84->Text = L":";
			// 
			// checkBox113
			// 
			this->checkBox113->AutoSize = true;
			this->checkBox113->Checked = true;
			this->checkBox113->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox113->Enabled = false;
			this->checkBox113->Location = System::Drawing::Point(6, 4);
			this->checkBox113->Name = L"checkBox113";
			this->checkBox113->Size = System::Drawing::Size(82, 17);
			this->checkBox113->TabIndex = 29;
			this->checkBox113->Text = L" File Name: ";
			this->checkBox113->UseVisualStyleBackColor = true;
			// 
			// checkBox114
			// 
			this->checkBox114->AutoSize = true;
			this->checkBox114->Enabled = false;
			this->checkBox114->Location = System::Drawing::Point(6, 250);
			this->checkBox114->Name = L"checkBox114";
			this->checkBox114->Size = System::Drawing::Size(143, 17);
			this->checkBox114->TabIndex = 28;
			this->checkBox114->Text = L"Total Simulation Packets";
			this->checkBox114->UseVisualStyleBackColor = true;
			// 
			// checkBox115
			// 
			this->checkBox115->AutoSize = true;
			this->checkBox115->Enabled = false;
			this->checkBox115->Location = System::Drawing::Point(6, 227);
			this->checkBox115->Name = L"checkBox115";
			this->checkBox115->Size = System::Drawing::Size(73, 17);
			this->checkBox115->TabIndex = 27;
			this->checkBox115->Text = L"Overhead";
			this->checkBox115->UseVisualStyleBackColor = true;
			// 
			// checkBox117
			// 
			this->checkBox117->AutoSize = true;
			this->checkBox117->Enabled = false;
			this->checkBox117->Location = System::Drawing::Point(6, 207);
			this->checkBox117->Name = L"checkBox117";
			this->checkBox117->Size = System::Drawing::Size(88, 17);
			this->checkBox117->TabIndex = 26;
			this->checkBox117->Text = L"Lost Packets";
			this->checkBox117->UseVisualStyleBackColor = true;
			// 
			// checkBox118
			// 
			this->checkBox118->AutoSize = true;
			this->checkBox118->Enabled = false;
			this->checkBox118->Location = System::Drawing::Point(6, 184);
			this->checkBox118->Name = L"checkBox118";
			this->checkBox118->Size = System::Drawing::Size(123, 17);
			this->checkBox118->TabIndex = 25;
			this->checkBox118->Text = L"Total Dropped Bytes";
			this->checkBox118->UseVisualStyleBackColor = true;
			// 
			// checkBox119
			// 
			this->checkBox119->AutoSize = true;
			this->checkBox119->Enabled = false;
			this->checkBox119->Location = System::Drawing::Point(6, 161);
			this->checkBox119->Name = L"checkBox119";
			this->checkBox119->Size = System::Drawing::Size(136, 17);
			this->checkBox119->TabIndex = 24;
			this->checkBox119->Text = L"Total Dropped Packets";
			this->checkBox119->UseVisualStyleBackColor = true;
			// 
			// checkBox120
			// 
			this->checkBox120->AutoSize = true;
			this->checkBox120->Enabled = false;
			this->checkBox120->Location = System::Drawing::Point(6, 138);
			this->checkBox120->Name = L"checkBox120";
			this->checkBox120->Size = System::Drawing::Size(140, 17);
			this->checkBox120->TabIndex = 23;
			this->checkBox120->Text = L"Total Received packets";
			this->checkBox120->UseVisualStyleBackColor = true;
			// 
			// checkBox121
			// 
			this->checkBox121->AutoSize = true;
			this->checkBox121->Enabled = false;
			this->checkBox121->Location = System::Drawing::Point(6, 113);
			this->checkBox121->Name = L"checkBox121";
			this->checkBox121->Size = System::Drawing::Size(117, 17);
			this->checkBox121->TabIndex = 22;
			this->checkBox121->Text = L"Total Sent Packets";
			this->checkBox121->UseVisualStyleBackColor = true;
			// 
			// checkBox122
			// 
			this->checkBox122->AutoSize = true;
			this->checkBox122->Enabled = false;
			this->checkBox122->Location = System::Drawing::Point(6, 90);
			this->checkBox122->Name = L"checkBox122";
			this->checkBox122->Size = System::Drawing::Size(109, 17);
			this->checkBox122->TabIndex = 21;
			this->checkBox122->Text = L"End to End Delay";
			this->checkBox122->UseVisualStyleBackColor = true;
			// 
			// checkBox123
			// 
			this->checkBox123->AutoSize = true;
			this->checkBox123->Enabled = false;
			this->checkBox123->Location = System::Drawing::Point(6, 68);
			this->checkBox123->Name = L"checkBox123";
			this->checkBox123->Size = System::Drawing::Size(78, 17);
			this->checkBox123->TabIndex = 20;
			this->checkBox123->Text = L"Normalized";
			this->checkBox123->UseVisualStyleBackColor = true;
			// 
			// checkBox124
			// 
			this->checkBox124->AutoSize = true;
			this->checkBox124->Enabled = false;
			this->checkBox124->Location = System::Drawing::Point(6, 48);
			this->checkBox124->Name = L"checkBox124";
			this->checkBox124->Size = System::Drawing::Size(129, 17);
			this->checkBox124->TabIndex = 19;
			this->checkBox124->Text = L"Packet Delivery Ratio";
			this->checkBox124->UseVisualStyleBackColor = true;
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->label99);
			this->groupBox9->Controls->Add(this->label98);
			this->groupBox9->Location = System::Drawing::Point(11, 714);
			this->groupBox9->Name = L"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(253, 46);
			this->groupBox9->TabIndex = 20;
			this->groupBox9->TabStop = false;
			// 
			// label99
			// 
			this->label99->AutoSize = true;
			this->label99->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label99->Location = System::Drawing::Point(4, 27);
			this->label99->Name = L"label99";
			this->label99->Size = System::Drawing::Size(162, 15);
			this->label99->TabIndex = 1;
			this->label99->Text = L"               March - 2014  ver 2.0\r\n";
			this->label99->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label98
			// 
			this->label98->AutoSize = true;
			this->label98->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label98->Location = System::Drawing::Point(6, 12);
			this->label98->Name = L"label98";
			this->label98->Size = System::Drawing::Size(224, 15);
			this->label98->TabIndex = 0;
			this->label98->Text = L"By:    Idris Al-skloul Ibrahim -  Peter King";
			// 
			// groupBox_PDF
			// 
			this->groupBox_PDF->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_PDF->Controls->Add(this->richTextBox1);
			this->groupBox_PDF->Controls->Add(this->File3_bar);
			this->groupBox_PDF->Controls->Add(this->File2_bar);
			this->groupBox_PDF->Controls->Add(this->File1_bar);
			this->groupBox_PDF->Controls->Add(this->progressBar4);
			this->groupBox_PDF->Controls->Add(this->progressBar3);
			this->groupBox_PDF->Controls->Add(this->progressBar2);
			this->groupBox_PDF->Location = System::Drawing::Point(6, 79);
			this->groupBox_PDF->Name = L"groupBox_PDF";
			this->groupBox_PDF->Size = System::Drawing::Size(245, 186);
			this->groupBox_PDF->TabIndex = 21;
			this->groupBox_PDF->TabStop = false;
			this->groupBox_PDF->Text = L"PDF 100 %";
			// 
			// richTextBox1
			// 
			this->richTextBox1->Enabled = false;
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox1->Location = System::Drawing::Point(26, 19);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox1->Size = System::Drawing::Size(213, 27);
			this->richTextBox1->TabIndex = 6;
			this->richTextBox1->Text = L"0                25           50           75          100";
			// 
			// File3_bar
			// 
			this->File3_bar->AutoSize = true;
			this->File3_bar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->File3_bar->Location = System::Drawing::Point(2, 159);
			this->File3_bar->Name = L"File3_bar";
			this->File3_bar->Size = System::Drawing::Size(32, 13);
			this->File3_bar->TabIndex = 5;
			this->File3_bar->Text = L"File 3";
			// 
			// File2_bar
			// 
			this->File2_bar->AutoSize = true;
			this->File2_bar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->File2_bar->Location = System::Drawing::Point(2, 114);
			this->File2_bar->Name = L"File2_bar";
			this->File2_bar->Size = System::Drawing::Size(32, 13);
			this->File2_bar->TabIndex = 4;
			this->File2_bar->Text = L"File 2";
			// 
			// File1_bar
			// 
			this->File1_bar->AutoSize = true;
			this->File1_bar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->File1_bar->Location = System::Drawing::Point(2, 72);
			this->File1_bar->Name = L"File1_bar";
			this->File1_bar->Size = System::Drawing::Size(32, 13);
			this->File1_bar->TabIndex = 3;
			this->File1_bar->Text = L"File 1";
			// 
			// progressBar4
			// 
			this->progressBar4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar4->Location = System::Drawing::Point(34, 152);
			this->progressBar4->Maximum = 106;
			this->progressBar4->Name = L"progressBar4";
			this->progressBar4->Size = System::Drawing::Size(205, 28);
			this->progressBar4->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar4->TabIndex = 2;
			// 
			// progressBar3
			// 
			this->progressBar3->Location = System::Drawing::Point(34, 108);
			this->progressBar3->Maximum = 106;
			this->progressBar3->Name = L"progressBar3";
			this->progressBar3->Size = System::Drawing::Size(205, 29);
			this->progressBar3->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar3->TabIndex = 1;
			// 
			// progressBar2
			// 
			this->progressBar2->ForeColor = System::Drawing::Color::Red;
			this->progressBar2->Location = System::Drawing::Point(34, 60);
			this->progressBar2->Maximum = 106;
			this->progressBar2->Name = L"progressBar2";
			this->progressBar2->Size = System::Drawing::Size(205, 29);
			this->progressBar2->Step = 1;
			this->progressBar2->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar2->TabIndex = 0;
			// 
			// groupBox_Results_graphics
			// 
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_DropPkts);
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_Throughput);
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_OH);
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_EED);
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_NRL);
			this->groupBox_Results_graphics->Controls->Add(this->groupBox_PDF);
			this->groupBox_Results_graphics->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->groupBox_Results_graphics->ForeColor = System::Drawing::Color::DarkRed;
			this->groupBox_Results_graphics->Location = System::Drawing::Point(597, 24);
			this->groupBox_Results_graphics->Name = L"groupBox_Results_graphics";
			this->groupBox_Results_graphics->Size = System::Drawing::Size(512, 736);
			this->groupBox_Results_graphics->TabIndex = 22;
			this->groupBox_Results_graphics->TabStop = false;
			this->groupBox_Results_graphics->Text = L"Performance Progress";
			this->groupBox_Results_graphics->Visible = false;
			// 
			// groupBox_DropPkts
			// 
			this->groupBox_DropPkts->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_DropPkts->Controls->Add(this->richTextBox6);
			this->groupBox_DropPkts->Controls->Add(this->label108);
			this->groupBox_DropPkts->Controls->Add(this->label109);
			this->groupBox_DropPkts->Controls->Add(this->label110);
			this->groupBox_DropPkts->Controls->Add(this->progressBar17);
			this->groupBox_DropPkts->Controls->Add(this->progressBar18);
			this->groupBox_DropPkts->Controls->Add(this->progressBar19);
			this->groupBox_DropPkts->Location = System::Drawing::Point(259, 505);
			this->groupBox_DropPkts->Name = L"groupBox_DropPkts";
			this->groupBox_DropPkts->Size = System::Drawing::Size(245, 186);
			this->groupBox_DropPkts->TabIndex = 23;
			this->groupBox_DropPkts->TabStop = false;
			this->groupBox_DropPkts->Text = L"Total Dropped Packets ";
			// 
			// richTextBox6
			// 
			this->richTextBox6->Enabled = false;
			this->richTextBox6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox6->Location = System::Drawing::Point(28, 19);
			this->richTextBox6->Name = L"richTextBox6";
			this->richTextBox6->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox6->Size = System::Drawing::Size(211, 27);
			this->richTextBox6->TabIndex = 7;
			this->richTextBox6->Text = L"0             500         1000      1500       2000";
			// 
			// label108
			// 
			this->label108->AutoSize = true;
			this->label108->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label108->Location = System::Drawing::Point(2, 159);
			this->label108->Name = L"label108";
			this->label108->Size = System::Drawing::Size(32, 13);
			this->label108->TabIndex = 5;
			this->label108->Text = L"File 3";
			// 
			// label109
			// 
			this->label109->AutoSize = true;
			this->label109->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label109->Location = System::Drawing::Point(2, 114);
			this->label109->Name = L"label109";
			this->label109->Size = System::Drawing::Size(32, 13);
			this->label109->TabIndex = 4;
			this->label109->Text = L"File 2";
			// 
			// label110
			// 
			this->label110->AutoSize = true;
			this->label110->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label110->Location = System::Drawing::Point(2, 72);
			this->label110->Name = L"label110";
			this->label110->Size = System::Drawing::Size(32, 13);
			this->label110->TabIndex = 3;
			this->label110->Text = L"File 1";
			// 
			// progressBar17
			// 
			this->progressBar17->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar17->Location = System::Drawing::Point(34, 152);
			this->progressBar17->Maximum = 2000;
			this->progressBar17->Name = L"progressBar17";
			this->progressBar17->Size = System::Drawing::Size(205, 28);
			this->progressBar17->Step = 100;
			this->progressBar17->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar17->TabIndex = 2;
			// 
			// progressBar18
			// 
			this->progressBar18->Location = System::Drawing::Point(34, 108);
			this->progressBar18->Maximum = 2000;
			this->progressBar18->Name = L"progressBar18";
			this->progressBar18->Size = System::Drawing::Size(205, 29);
			this->progressBar18->Step = 100;
			this->progressBar18->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar18->TabIndex = 1;
			// 
			// progressBar19
			// 
			this->progressBar19->ForeColor = System::Drawing::Color::Red;
			this->progressBar19->Location = System::Drawing::Point(34, 60);
			this->progressBar19->Maximum = 2000;
			this->progressBar19->Name = L"progressBar19";
			this->progressBar19->Size = System::Drawing::Size(205, 29);
			this->progressBar19->Step = 100;
			this->progressBar19->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar19->TabIndex = 0;
			this->progressBar19->Click += gcnew System::EventHandler(this, &Form1::progressBar19_Click);
			// 
			// groupBox_Throughput
			// 
			this->groupBox_Throughput->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_Throughput->Controls->Add(this->richTextBox5);
			this->groupBox_Throughput->Controls->Add(this->label105);
			this->groupBox_Throughput->Controls->Add(this->label106);
			this->groupBox_Throughput->Controls->Add(this->label107);
			this->groupBox_Throughput->Controls->Add(this->progressBar14);
			this->groupBox_Throughput->Controls->Add(this->progressBar15);
			this->groupBox_Throughput->Controls->Add(this->progressBar16);
			this->groupBox_Throughput->Location = System::Drawing::Point(8, 505);
			this->groupBox_Throughput->Name = L"groupBox_Throughput";
			this->groupBox_Throughput->Size = System::Drawing::Size(245, 186);
			this->groupBox_Throughput->TabIndex = 23;
			this->groupBox_Throughput->TabStop = false;
			this->groupBox_Throughput->Text = L"Throughput Kbps ";
			// 
			// richTextBox5
			// 
			this->richTextBox5->Enabled = false;
			this->richTextBox5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox5->Location = System::Drawing::Point(25, 19);
			this->richTextBox5->Name = L"richTextBox5";
			this->richTextBox5->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox5->Size = System::Drawing::Size(214, 27);
			this->richTextBox5->TabIndex = 6;
			this->richTextBox5->Text = L"0              250           500          750      1000";
			// 
			// label105
			// 
			this->label105->AutoSize = true;
			this->label105->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label105->Location = System::Drawing::Point(2, 159);
			this->label105->Name = L"label105";
			this->label105->Size = System::Drawing::Size(32, 13);
			this->label105->TabIndex = 5;
			this->label105->Text = L"File 3";
			// 
			// label106
			// 
			this->label106->AutoSize = true;
			this->label106->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label106->Location = System::Drawing::Point(2, 114);
			this->label106->Name = L"label106";
			this->label106->Size = System::Drawing::Size(32, 13);
			this->label106->TabIndex = 4;
			this->label106->Text = L"File 2";
			// 
			// label107
			// 
			this->label107->AutoSize = true;
			this->label107->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label107->Location = System::Drawing::Point(2, 72);
			this->label107->Name = L"label107";
			this->label107->Size = System::Drawing::Size(32, 13);
			this->label107->TabIndex = 3;
			this->label107->Text = L"File 1";
			// 
			// progressBar14
			// 
			this->progressBar14->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar14->Location = System::Drawing::Point(34, 152);
			this->progressBar14->Maximum = 1000;
			this->progressBar14->Name = L"progressBar14";
			this->progressBar14->Size = System::Drawing::Size(205, 28);
			this->progressBar14->Step = 50;
			this->progressBar14->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar14->TabIndex = 2;
			// 
			// progressBar15
			// 
			this->progressBar15->Location = System::Drawing::Point(34, 108);
			this->progressBar15->Maximum = 1000;
			this->progressBar15->Name = L"progressBar15";
			this->progressBar15->Size = System::Drawing::Size(205, 29);
			this->progressBar15->Step = 50;
			this->progressBar15->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar15->TabIndex = 1;
			// 
			// progressBar16
			// 
			this->progressBar16->ForeColor = System::Drawing::Color::Red;
			this->progressBar16->Location = System::Drawing::Point(34, 60);
			this->progressBar16->Maximum = 1000;
			this->progressBar16->Name = L"progressBar16";
			this->progressBar16->Size = System::Drawing::Size(205, 29);
			this->progressBar16->Step = 50;
			this->progressBar16->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar16->TabIndex = 0;
			// 
			// groupBox_OH
			// 
			this->groupBox_OH->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_OH->Controls->Add(this->richTextBox4);
			this->groupBox_OH->Controls->Add(this->label102);
			this->groupBox_OH->Controls->Add(this->label103);
			this->groupBox_OH->Controls->Add(this->label104);
			this->groupBox_OH->Controls->Add(this->progressBar11);
			this->groupBox_OH->Controls->Add(this->progressBar12);
			this->groupBox_OH->Controls->Add(this->progressBar13);
			this->groupBox_OH->Location = System::Drawing::Point(259, 294);
			this->groupBox_OH->Name = L"groupBox_OH";
			this->groupBox_OH->Size = System::Drawing::Size(245, 186);
			this->groupBox_OH->TabIndex = 23;
			this->groupBox_OH->TabStop = false;
			this->groupBox_OH->Text = L"OverHead / Packets";
			// 
			// richTextBox4
			// 
			this->richTextBox4->Enabled = false;
			this->richTextBox4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox4->Location = System::Drawing::Point(28, 19);
			this->richTextBox4->Name = L"richTextBox4";
			this->richTextBox4->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox4->Size = System::Drawing::Size(211, 27);
			this->richTextBox4->TabIndex = 6;
			this->richTextBox4->Text = L"0             500         1000      1500       2000";
			this->richTextBox4->TextChanged += gcnew System::EventHandler(this, &Form1::richTextBox4_TextChanged);
			// 
			// label102
			// 
			this->label102->AutoSize = true;
			this->label102->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label102->Location = System::Drawing::Point(2, 159);
			this->label102->Name = L"label102";
			this->label102->Size = System::Drawing::Size(32, 13);
			this->label102->TabIndex = 5;
			this->label102->Text = L"File 3";
			// 
			// label103
			// 
			this->label103->AutoSize = true;
			this->label103->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label103->Location = System::Drawing::Point(2, 114);
			this->label103->Name = L"label103";
			this->label103->Size = System::Drawing::Size(32, 13);
			this->label103->TabIndex = 4;
			this->label103->Text = L"File 2";
			// 
			// label104
			// 
			this->label104->AutoSize = true;
			this->label104->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label104->Location = System::Drawing::Point(2, 72);
			this->label104->Name = L"label104";
			this->label104->Size = System::Drawing::Size(32, 13);
			this->label104->TabIndex = 3;
			this->label104->Text = L"File 1";
			// 
			// progressBar11
			// 
			this->progressBar11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar11->Location = System::Drawing::Point(34, 152);
			this->progressBar11->Maximum = 2000;
			this->progressBar11->Name = L"progressBar11";
			this->progressBar11->Size = System::Drawing::Size(205, 28);
			this->progressBar11->Step = 100;
			this->progressBar11->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar11->TabIndex = 2;
			// 
			// progressBar12
			// 
			this->progressBar12->Location = System::Drawing::Point(34, 108);
			this->progressBar12->Maximum = 2000;
			this->progressBar12->Name = L"progressBar12";
			this->progressBar12->Size = System::Drawing::Size(205, 29);
			this->progressBar12->Step = 100;
			this->progressBar12->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar12->TabIndex = 1;
			// 
			// progressBar13
			// 
			this->progressBar13->ForeColor = System::Drawing::Color::Red;
			this->progressBar13->Location = System::Drawing::Point(34, 60);
			this->progressBar13->Maximum = 2000;
			this->progressBar13->Name = L"progressBar13";
			this->progressBar13->Size = System::Drawing::Size(205, 29);
			this->progressBar13->Step = 100;
			this->progressBar13->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar13->TabIndex = 0;
			this->progressBar13->Click += gcnew System::EventHandler(this, &Form1::progressBar13_Click);
			// 
			// groupBox_EED
			// 
			this->groupBox_EED->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_EED->Controls->Add(this->richTextBox3);
			this->groupBox_EED->Controls->Add(this->label97);
			this->groupBox_EED->Controls->Add(this->label100);
			this->groupBox_EED->Controls->Add(this->label101);
			this->groupBox_EED->Controls->Add(this->progressBar8);
			this->groupBox_EED->Controls->Add(this->progressBar9);
			this->groupBox_EED->Controls->Add(this->progressBar10);
			this->groupBox_EED->Location = System::Drawing::Point(6, 292);
			this->groupBox_EED->Name = L"groupBox_EED";
			this->groupBox_EED->Size = System::Drawing::Size(245, 186);
			this->groupBox_EED->TabIndex = 22;
			this->groupBox_EED->TabStop = false;
			this->groupBox_EED->Text = L"EED Micro Seconds";
			// 
			// richTextBox3
			// 
			this->richTextBox3->Enabled = false;
			this->richTextBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox3->Location = System::Drawing::Point(25, 19);
			this->richTextBox3->Name = L"richTextBox3";
			this->richTextBox3->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox3->Size = System::Drawing::Size(214, 27);
			this->richTextBox3->TabIndex = 6;
			this->richTextBox3->Text = L"0                 5            10            15            20";
			// 
			// label97
			// 
			this->label97->AutoSize = true;
			this->label97->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label97->Location = System::Drawing::Point(2, 159);
			this->label97->Name = L"label97";
			this->label97->Size = System::Drawing::Size(32, 13);
			this->label97->TabIndex = 5;
			this->label97->Text = L"File 3";
			// 
			// label100
			// 
			this->label100->AutoSize = true;
			this->label100->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label100->Location = System::Drawing::Point(2, 114);
			this->label100->Name = L"label100";
			this->label100->Size = System::Drawing::Size(32, 13);
			this->label100->TabIndex = 4;
			this->label100->Text = L"File 2";
			// 
			// label101
			// 
			this->label101->AutoSize = true;
			this->label101->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label101->Location = System::Drawing::Point(2, 72);
			this->label101->Name = L"label101";
			this->label101->Size = System::Drawing::Size(32, 13);
			this->label101->TabIndex = 3;
			this->label101->Text = L"File 1";
			// 
			// progressBar8
			// 
			this->progressBar8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar8->Location = System::Drawing::Point(34, 152);
			this->progressBar8->Maximum = 20;
			this->progressBar8->Name = L"progressBar8";
			this->progressBar8->Size = System::Drawing::Size(205, 28);
			this->progressBar8->Step = 1;
			this->progressBar8->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar8->TabIndex = 2;
			// 
			// progressBar9
			// 
			this->progressBar9->Location = System::Drawing::Point(34, 108);
			this->progressBar9->Maximum = 20;
			this->progressBar9->Name = L"progressBar9";
			this->progressBar9->Size = System::Drawing::Size(205, 29);
			this->progressBar9->Step = 1;
			this->progressBar9->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar9->TabIndex = 1;
			// 
			// progressBar10
			// 
			this->progressBar10->ForeColor = System::Drawing::Color::Red;
			this->progressBar10->Location = System::Drawing::Point(34, 60);
			this->progressBar10->Maximum = 20;
			this->progressBar10->Name = L"progressBar10";
			this->progressBar10->Size = System::Drawing::Size(205, 29);
			this->progressBar10->Step = 1;
			this->progressBar10->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar10->TabIndex = 0;
			// 
			// groupBox_NRL
			// 
			this->groupBox_NRL->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->groupBox_NRL->Controls->Add(this->richTextBox2);
			this->groupBox_NRL->Controls->Add(this->label8);
			this->groupBox_NRL->Controls->Add(this->label85);
			this->groupBox_NRL->Controls->Add(this->label96);
			this->groupBox_NRL->Controls->Add(this->progressBar5);
			this->groupBox_NRL->Controls->Add(this->progressBar6);
			this->groupBox_NRL->Controls->Add(this->progressBar7);
			this->groupBox_NRL->Location = System::Drawing::Point(257, 79);
			this->groupBox_NRL->Name = L"groupBox_NRL";
			this->groupBox_NRL->Size = System::Drawing::Size(245, 186);
			this->groupBox_NRL->TabIndex = 22;
			this->groupBox_NRL->TabStop = false;
			this->groupBox_NRL->Text = L"NRL 100 %";
			// 
			// richTextBox2
			// 
			this->richTextBox2->Enabled = false;
			this->richTextBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox2->Location = System::Drawing::Point(28, 19);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox2->Size = System::Drawing::Size(211, 27);
			this->richTextBox2->TabIndex = 6;
			this->richTextBox2->Text = L".0     .1   .2   .3   .4   0. 5   .6   .7   .8   .9   1.";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(2, 159);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(32, 13);
			this->label8->TabIndex = 5;
			this->label8->Text = L"File 3";
			// 
			// label85
			// 
			this->label85->AutoSize = true;
			this->label85->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label85->Location = System::Drawing::Point(2, 114);
			this->label85->Name = L"label85";
			this->label85->Size = System::Drawing::Size(32, 13);
			this->label85->TabIndex = 4;
			this->label85->Text = L"File 2";
			// 
			// label96
			// 
			this->label96->AutoSize = true;
			this->label96->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label96->Location = System::Drawing::Point(2, 72);
			this->label96->Name = L"label96";
			this->label96->Size = System::Drawing::Size(32, 13);
			this->label96->TabIndex = 3;
			this->label96->Text = L"File 1";
			// 
			// progressBar5
			// 
			this->progressBar5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->progressBar5->Location = System::Drawing::Point(34, 152);
			this->progressBar5->Maximum = 30;
			this->progressBar5->Name = L"progressBar5";
			this->progressBar5->Size = System::Drawing::Size(205, 28);
			this->progressBar5->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar5->TabIndex = 2;
			// 
			// progressBar6
			// 
			this->progressBar6->Location = System::Drawing::Point(34, 108);
			this->progressBar6->Maximum = 30;
			this->progressBar6->Name = L"progressBar6";
			this->progressBar6->Size = System::Drawing::Size(205, 29);
			this->progressBar6->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar6->TabIndex = 1;
			// 
			// progressBar7
			// 
			this->progressBar7->ForeColor = System::Drawing::Color::Red;
			this->progressBar7->Location = System::Drawing::Point(34, 60);
			this->progressBar7->Maximum = 30;
			this->progressBar7->Name = L"progressBar7";
			this->progressBar7->Size = System::Drawing::Size(205, 29);
			this->progressBar7->Style = System::Windows::Forms::ProgressBarStyle::Continuous;
			this->progressBar7->TabIndex = 0;
			this->progressBar7->Click += gcnew System::EventHandler(this, &Form1::progressBar7_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->fileToolStripMenuItem, 
				this->viewToolStripMenuItem, this->helpToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1117, 24);
			this->menuStrip1->TabIndex = 23;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->OpentoolStripMenuItem, 
				this->saveAsToolStripMenuItem, this->printToolStripMenuItem, this->savetoolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(37, 20);
			this->fileToolStripMenuItem->Text = L"&File";
			// 
			// OpentoolStripMenuItem
			// 
			this->OpentoolStripMenuItem->Name = L"OpentoolStripMenuItem";
			this->OpentoolStripMenuItem->Size = System::Drawing::Size(151, 22);
			this->OpentoolStripMenuItem->Text = L"&Open";
			this->OpentoolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::OpentoolStripMenuItem_Click);
			// 
			// saveAsToolStripMenuItem
			// 
			this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
			this->saveAsToolStripMenuItem->Size = System::Drawing::Size(151, 22);
			this->saveAsToolStripMenuItem->Text = L"Save &As ";
			this->saveAsToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveAsToolStripMenuItem_Click);
			// 
			// printToolStripMenuItem
			// 
			this->printToolStripMenuItem->Name = L"printToolStripMenuItem";
			this->printToolStripMenuItem->Size = System::Drawing::Size(151, 22);
			this->printToolStripMenuItem->Text = L"&Print";
			// 
			// savetoolStripMenuItem
			// 
			this->savetoolStripMenuItem->Name = L"savetoolStripMenuItem";
			this->savetoolStripMenuItem->Size = System::Drawing::Size(151, 22);
			this->savetoolStripMenuItem->Text = L"&Save / Append";
			this->savetoolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::savetoolStripMenuItem_Click_1);
			// 
			// viewToolStripMenuItem
			// 
			this->viewToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->resultsTabPagesToolStripMenuItem, 
				this->textBoardToolStripMenuItem, this->performanceProgressToolStripMenuItem, this->systemTimeToolStripMenuItem});
			this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
			this->viewToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->viewToolStripMenuItem->Text = L"&View";
			// 
			// resultsTabPagesToolStripMenuItem
			// 
			this->resultsTabPagesToolStripMenuItem->Checked = true;
			this->resultsTabPagesToolStripMenuItem->CheckOnClick = true;
			this->resultsTabPagesToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
			this->resultsTabPagesToolStripMenuItem->Name = L"resultsTabPagesToolStripMenuItem";
			this->resultsTabPagesToolStripMenuItem->Size = System::Drawing::Size(190, 22);
			this->resultsTabPagesToolStripMenuItem->Text = L"&Results Tab pages";
			this->resultsTabPagesToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::resultsTabPagesToolStripMenuItem_CheckedChanged);
			this->resultsTabPagesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::resultsTabPagesToolStripMenuItem_Click);
			// 
			// textBoardToolStripMenuItem
			// 
			this->textBoardToolStripMenuItem->Checked = true;
			this->textBoardToolStripMenuItem->CheckOnClick = true;
			this->textBoardToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
			this->textBoardToolStripMenuItem->Name = L"textBoardToolStripMenuItem";
			this->textBoardToolStripMenuItem->Size = System::Drawing::Size(190, 22);
			this->textBoardToolStripMenuItem->Text = L"&Text Board";
			this->textBoardToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::textBoardToolStripMenuItem_CheckedChanged);
			// 
			// performanceProgressToolStripMenuItem
			// 
			this->performanceProgressToolStripMenuItem->CheckOnClick = true;
			this->performanceProgressToolStripMenuItem->Name = L"performanceProgressToolStripMenuItem";
			this->performanceProgressToolStripMenuItem->Size = System::Drawing::Size(190, 22);
			this->performanceProgressToolStripMenuItem->Text = L"Per&formance Progress";
			this->performanceProgressToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::performanceProgressToolStripMenuItem_CheckedChanged);
			this->performanceProgressToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::performanceProgressToolStripMenuItem_Click);
			// 
			// systemTimeToolStripMenuItem
			// 
			this->systemTimeToolStripMenuItem->Checked = true;
			this->systemTimeToolStripMenuItem->CheckOnClick = true;
			this->systemTimeToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
			this->systemTimeToolStripMenuItem->Name = L"systemTimeToolStripMenuItem";
			this->systemTimeToolStripMenuItem->Size = System::Drawing::Size(190, 22);
			this->systemTimeToolStripMenuItem->Text = L"&System Time";
			this->systemTimeToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::systemTimeToolStripMenuItem_Click);
			// 
			// helpToolStripMenuItem
			// 
			this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
			this->helpToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->helpToolStripMenuItem->Text = L"&Help";
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->pictureBox1);
			this->groupBox7->Location = System::Drawing::Point(13, 72);
			this->groupBox7->Name = L"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(253, 70);
			this->groupBox7->TabIndex = 24;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = L"Dependable Systems Group ";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(3, 13);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(247, 54);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			// 
			// tabPage11
			// 
			this->tabPage11->Controls->Add(this->label123);
			this->tabPage11->Controls->Add(this->checkBox_Throughput_3);
			this->tabPage11->Controls->Add(this->label118);
			this->tabPage11->Controls->Add(this->checkBox_Overh_3);
			this->tabPage11->Controls->Add(this->checkBox130);
			this->tabPage11->Controls->Add(this->label_Filename_3);
			this->tabPage11->Controls->Add(this->checkBox129);
			this->tabPage11->Controls->Add(this->label_Unknown_3);
			this->tabPage11->Controls->Add(this->checkBox138);
			this->tabPage11->Controls->Add(this->label_analysis_time_3);
			this->tabPage11->Controls->Add(this->label113);
			this->tabPage11->Controls->Add(this->label114);
			this->tabPage11->Controls->Add(this->label115);
			this->tabPage11->Controls->Add(this->label116);
			this->tabPage11->Controls->Add(this->label117);
			this->tabPage11->Controls->Add(this->label119);
			this->tabPage11->Controls->Add(this->label120);
			this->tabPage11->Controls->Add(this->label121);
			this->tabPage11->Controls->Add(this->label122);
			this->tabPage11->Controls->Add(this->checkBox_Simtime_3);
			this->tabPage11->Controls->Add(this->checkBox_Lostpkt_3);
			this->tabPage11->Controls->Add(this->checkBox_DrpByts_3);
			this->tabPage11->Controls->Add(this->checkBox_Drppks_3);
			this->tabPage11->Controls->Add(this->checkBox_Receive_3);
			this->tabPage11->Controls->Add(this->checkBox_Sent_3);
			this->tabPage11->Controls->Add(this->checkBox_EED_3);
			this->tabPage11->Controls->Add(this->checkBox_NRL_3);
			this->tabPage11->Controls->Add(this->checkBox_PDF_3);
			this->tabPage11->Location = System::Drawing::Point(4, 22);
			this->tabPage11->Name = L"tabPage11";
			this->tabPage11->Padding = System::Windows::Forms::Padding(3);
			this->tabPage11->Size = System::Drawing::Size(314, 273);
			this->tabPage11->TabIndex = 4;
			this->tabPage11->Text = L"File 3";
			this->tabPage11->UseVisualStyleBackColor = true;
			this->tabPage11->Click += gcnew System::EventHandler(this, &Form1::tabPage11_Click);
			// 
			// label123
			// 
			this->label123->AutoSize = true;
			this->label123->Location = System::Drawing::Point(144, 112);
			this->label123->Name = L"label123";
			this->label123->Size = System::Drawing::Size(13, 13);
			this->label123->TabIndex = 103;
			this->label123->Text = L"0";
			// 
			// checkBox_Throughput_3
			// 
			this->checkBox_Throughput_3->AutoSize = true;
			this->checkBox_Throughput_3->Enabled = false;
			this->checkBox_Throughput_3->Location = System::Drawing::Point(6, 108);
			this->checkBox_Throughput_3->Name = L"checkBox_Throughput_3";
			this->checkBox_Throughput_3->Size = System::Drawing::Size(81, 17);
			this->checkBox_Throughput_3->TabIndex = 102;
			this->checkBox_Throughput_3->Text = L"Throughput";
			this->checkBox_Throughput_3->UseVisualStyleBackColor = true;
			// 
			// label118
			// 
			this->label118->AutoSize = true;
			this->label118->Location = System::Drawing::Point(144, 151);
			this->label118->Name = L"label118";
			this->label118->Size = System::Drawing::Size(13, 13);
			this->label118->TabIndex = 101;
			this->label118->Text = L"0";
			// 
			// checkBox_Overh_3
			// 
			this->checkBox_Overh_3->AutoSize = true;
			this->checkBox_Overh_3->Enabled = false;
			this->checkBox_Overh_3->Location = System::Drawing::Point(6, 236);
			this->checkBox_Overh_3->Name = L"checkBox_Overh_3";
			this->checkBox_Overh_3->Size = System::Drawing::Size(73, 17);
			this->checkBox_Overh_3->TabIndex = 100;
			this->checkBox_Overh_3->Text = L"Overhead";
			this->checkBox_Overh_3->UseVisualStyleBackColor = true;
			// 
			// checkBox130
			// 
			this->checkBox130->AutoSize = true;
			this->checkBox130->Checked = true;
			this->checkBox130->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox130->Enabled = false;
			this->checkBox130->Location = System::Drawing::Point(6, 24);
			this->checkBox130->Name = L"checkBox130";
			this->checkBox130->Size = System::Drawing::Size(86, 17);
			this->checkBox130->TabIndex = 99;
			this->checkBox130->Text = L" File Format: ";
			this->checkBox130->UseVisualStyleBackColor = true;
			// 
			// label_Filename_3
			// 
			this->label_Filename_3->AutoSize = true;
			this->label_Filename_3->Location = System::Drawing::Point(78, 5);
			this->label_Filename_3->Name = L"label_Filename_3";
			this->label_Filename_3->Size = System::Drawing::Size(10, 13);
			this->label_Filename_3->TabIndex = 98;
			this->label_Filename_3->Text = L":";
			// 
			// checkBox129
			// 
			this->checkBox129->AutoSize = true;
			this->checkBox129->Checked = true;
			this->checkBox129->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox129->Enabled = false;
			this->checkBox129->Location = System::Drawing::Point(6, 4);
			this->checkBox129->Name = L"checkBox129";
			this->checkBox129->Size = System::Drawing::Size(82, 17);
			this->checkBox129->TabIndex = 97;
			this->checkBox129->Text = L" File Name: ";
			this->checkBox129->UseVisualStyleBackColor = true;
			// 
			// label_Unknown_3
			// 
			this->label_Unknown_3->AutoSize = true;
			this->label_Unknown_3->Location = System::Drawing::Point(88, 25);
			this->label_Unknown_3->Name = L"label_Unknown_3";
			this->label_Unknown_3->Size = System::Drawing::Size(53, 13);
			this->label_Unknown_3->TabIndex = 96;
			this->label_Unknown_3->Text = L"Unknown";
			// 
			// checkBox138
			// 
			this->checkBox138->AutoSize = true;
			this->checkBox138->Checked = true;
			this->checkBox138->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox138->Enabled = false;
			this->checkBox138->Location = System::Drawing::Point(147, 25);
			this->checkBox138->Name = L"checkBox138";
			this->checkBox138->Size = System::Drawing::Size(55, 17);
			this->checkBox138->TabIndex = 95;
			this->checkBox138->Text = L"Time: ";
			this->checkBox138->UseVisualStyleBackColor = true;
			// 
			// label_analysis_time_3
			// 
			this->label_analysis_time_3->AutoSize = true;
			this->label_analysis_time_3->Location = System::Drawing::Point(199, 27);
			this->label_analysis_time_3->Name = L"label_analysis_time_3";
			this->label_analysis_time_3->Size = System::Drawing::Size(49, 13);
			this->label_analysis_time_3->TabIndex = 94;
			this->label_analysis_time_3->Text = L"00:00:00";
			// 
			// label113
			// 
			this->label113->AutoSize = true;
			this->label113->Location = System::Drawing::Point(144, 257);
			this->label113->Name = L"label113";
			this->label113->Size = System::Drawing::Size(13, 13);
			this->label113->TabIndex = 92;
			this->label113->Text = L"0";
			// 
			// label114
			// 
			this->label114->AutoSize = true;
			this->label114->Location = System::Drawing::Point(144, 238);
			this->label114->Name = L"label114";
			this->label114->Size = System::Drawing::Size(13, 13);
			this->label114->TabIndex = 91;
			this->label114->Text = L"0";
			// 
			// label115
			// 
			this->label115->AutoSize = true;
			this->label115->Location = System::Drawing::Point(144, 219);
			this->label115->Name = L"label115";
			this->label115->Size = System::Drawing::Size(13, 13);
			this->label115->TabIndex = 90;
			this->label115->Text = L"0";
			// 
			// label116
			// 
			this->label116->AutoSize = true;
			this->label116->Location = System::Drawing::Point(144, 196);
			this->label116->Name = L"label116";
			this->label116->Size = System::Drawing::Size(13, 13);
			this->label116->TabIndex = 89;
			this->label116->Text = L"0";
			// 
			// label117
			// 
			this->label117->AutoSize = true;
			this->label117->Location = System::Drawing::Point(144, 173);
			this->label117->Name = L"label117";
			this->label117->Size = System::Drawing::Size(13, 13);
			this->label117->TabIndex = 88;
			this->label117->Text = L"0";
			// 
			// label119
			// 
			this->label119->AutoSize = true;
			this->label119->Location = System::Drawing::Point(144, 131);
			this->label119->Name = L"label119";
			this->label119->Size = System::Drawing::Size(13, 13);
			this->label119->TabIndex = 86;
			this->label119->Text = L"0";
			// 
			// label120
			// 
			this->label120->AutoSize = true;
			this->label120->Location = System::Drawing::Point(144, 89);
			this->label120->Name = L"label120";
			this->label120->Size = System::Drawing::Size(13, 13);
			this->label120->TabIndex = 85;
			this->label120->Text = L"0";
			// 
			// label121
			// 
			this->label121->AutoSize = true;
			this->label121->Location = System::Drawing::Point(144, 67);
			this->label121->Name = L"label121";
			this->label121->Size = System::Drawing::Size(13, 13);
			this->label121->TabIndex = 84;
			this->label121->Text = L"0";
			// 
			// label122
			// 
			this->label122->AutoSize = true;
			this->label122->Location = System::Drawing::Point(144, 46);
			this->label122->Name = L"label122";
			this->label122->Size = System::Drawing::Size(13, 13);
			this->label122->TabIndex = 83;
			this->label122->Text = L"0";
			// 
			// checkBox_Simtime_3
			// 
			this->checkBox_Simtime_3->AutoSize = true;
			this->checkBox_Simtime_3->Enabled = false;
			this->checkBox_Simtime_3->Location = System::Drawing::Point(6, 256);
			this->checkBox_Simtime_3->Name = L"checkBox_Simtime_3";
			this->checkBox_Simtime_3->Size = System::Drawing::Size(143, 17);
			this->checkBox_Simtime_3->TabIndex = 80;
			this->checkBox_Simtime_3->Text = L"Total Simulation Packets";
			this->checkBox_Simtime_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_Lostpkt_3
			// 
			this->checkBox_Lostpkt_3->AutoSize = true;
			this->checkBox_Lostpkt_3->Enabled = false;
			this->checkBox_Lostpkt_3->Location = System::Drawing::Point(6, 215);
			this->checkBox_Lostpkt_3->Name = L"checkBox_Lostpkt_3";
			this->checkBox_Lostpkt_3->Size = System::Drawing::Size(88, 17);
			this->checkBox_Lostpkt_3->TabIndex = 78;
			this->checkBox_Lostpkt_3->Text = L"Lost Packets";
			this->checkBox_Lostpkt_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_DrpByts_3
			// 
			this->checkBox_DrpByts_3->AutoSize = true;
			this->checkBox_DrpByts_3->Enabled = false;
			this->checkBox_DrpByts_3->Location = System::Drawing::Point(6, 195);
			this->checkBox_DrpByts_3->Name = L"checkBox_DrpByts_3";
			this->checkBox_DrpByts_3->Size = System::Drawing::Size(123, 17);
			this->checkBox_DrpByts_3->TabIndex = 77;
			this->checkBox_DrpByts_3->Text = L"Total Dropped Bytes";
			this->checkBox_DrpByts_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_Drppks_3
			// 
			this->checkBox_Drppks_3->AutoSize = true;
			this->checkBox_Drppks_3->Enabled = false;
			this->checkBox_Drppks_3->Location = System::Drawing::Point(6, 172);
			this->checkBox_Drppks_3->Name = L"checkBox_Drppks_3";
			this->checkBox_Drppks_3->Size = System::Drawing::Size(136, 17);
			this->checkBox_Drppks_3->TabIndex = 76;
			this->checkBox_Drppks_3->Text = L"Total Dropped Packets";
			this->checkBox_Drppks_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_Receive_3
			// 
			this->checkBox_Receive_3->AutoSize = true;
			this->checkBox_Receive_3->Enabled = false;
			this->checkBox_Receive_3->Location = System::Drawing::Point(6, 150);
			this->checkBox_Receive_3->Name = L"checkBox_Receive_3";
			this->checkBox_Receive_3->Size = System::Drawing::Size(140, 17);
			this->checkBox_Receive_3->TabIndex = 75;
			this->checkBox_Receive_3->Text = L"Total Received packets";
			this->checkBox_Receive_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_Sent_3
			// 
			this->checkBox_Sent_3->AutoSize = true;
			this->checkBox_Sent_3->Enabled = false;
			this->checkBox_Sent_3->Location = System::Drawing::Point(6, 127);
			this->checkBox_Sent_3->Name = L"checkBox_Sent_3";
			this->checkBox_Sent_3->Size = System::Drawing::Size(117, 17);
			this->checkBox_Sent_3->TabIndex = 74;
			this->checkBox_Sent_3->Text = L"Total Sent Packets";
			this->checkBox_Sent_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_EED_3
			// 
			this->checkBox_EED_3->AutoSize = true;
			this->checkBox_EED_3->Enabled = false;
			this->checkBox_EED_3->Location = System::Drawing::Point(6, 88);
			this->checkBox_EED_3->Name = L"checkBox_EED_3";
			this->checkBox_EED_3->Size = System::Drawing::Size(109, 17);
			this->checkBox_EED_3->TabIndex = 73;
			this->checkBox_EED_3->Text = L"End to End Delay";
			this->checkBox_EED_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_NRL_3
			// 
			this->checkBox_NRL_3->AutoSize = true;
			this->checkBox_NRL_3->Enabled = false;
			this->checkBox_NRL_3->Location = System::Drawing::Point(6, 66);
			this->checkBox_NRL_3->Name = L"checkBox_NRL_3";
			this->checkBox_NRL_3->Size = System::Drawing::Size(78, 17);
			this->checkBox_NRL_3->TabIndex = 72;
			this->checkBox_NRL_3->Text = L"Normalized";
			this->checkBox_NRL_3->UseVisualStyleBackColor = true;
			// 
			// checkBox_PDF_3
			// 
			this->checkBox_PDF_3->AutoSize = true;
			this->checkBox_PDF_3->Enabled = false;
			this->checkBox_PDF_3->Location = System::Drawing::Point(6, 46);
			this->checkBox_PDF_3->Name = L"checkBox_PDF_3";
			this->checkBox_PDF_3->Size = System::Drawing::Size(129, 17);
			this->checkBox_PDF_3->TabIndex = 71;
			this->checkBox_PDF_3->Text = L"Packet Delivery Ratio";
			this->checkBox_PDF_3->UseVisualStyleBackColor = true;
			// 
			// tabPage6
			// 
			this->tabPage6->Controls->Add(this->label112);
			this->tabPage6->Controls->Add(this->checkBox_Throughput_2);
			this->tabPage6->Controls->Add(this->checkBox_Simtime_2);
			this->tabPage6->Controls->Add(this->label_Unknown_2);
			this->tabPage6->Controls->Add(this->checkBox125);
			this->tabPage6->Controls->Add(this->label_analysis_time_2);
			this->tabPage6->Controls->Add(this->checkBox126);
			this->tabPage6->Controls->Add(this->label86);
			this->tabPage6->Controls->Add(this->label87);
			this->tabPage6->Controls->Add(this->label88);
			this->tabPage6->Controls->Add(this->label89);
			this->tabPage6->Controls->Add(this->label90);
			this->tabPage6->Controls->Add(this->label91);
			this->tabPage6->Controls->Add(this->label92);
			this->tabPage6->Controls->Add(this->label93);
			this->tabPage6->Controls->Add(this->label94);
			this->tabPage6->Controls->Add(this->label95);
			this->tabPage6->Controls->Add(this->label_Filename_2);
			this->tabPage6->Controls->Add(this->checkBox127);
			this->tabPage6->Controls->Add(this->checkBox_Overh_2);
			this->tabPage6->Controls->Add(this->checkBox_Lostpkt_2);
			this->tabPage6->Controls->Add(this->checkBox_DrpByts_2);
			this->tabPage6->Controls->Add(this->checkBox_Drppks_2);
			this->tabPage6->Controls->Add(this->checkBox_Receive_2);
			this->tabPage6->Controls->Add(this->checkBox_Sent_2);
			this->tabPage6->Controls->Add(this->checkBox_EED_2);
			this->tabPage6->Controls->Add(this->checkBox_NRL_2);
			this->tabPage6->Controls->Add(this->checkBox_PDF_2);
			this->tabPage6->Location = System::Drawing::Point(4, 22);
			this->tabPage6->Name = L"tabPage6";
			this->tabPage6->Padding = System::Windows::Forms::Padding(3);
			this->tabPage6->Size = System::Drawing::Size(314, 273);
			this->tabPage6->TabIndex = 3;
			this->tabPage6->Text = L"File 2";
			this->tabPage6->UseVisualStyleBackColor = true;
			// 
			// label112
			// 
			this->label112->AutoSize = true;
			this->label112->Location = System::Drawing::Point(148, 107);
			this->label112->Name = L"label112";
			this->label112->Size = System::Drawing::Size(13, 13);
			this->label112->TabIndex = 73;
			this->label112->Text = L"0";
			// 
			// checkBox_Throughput_2
			// 
			this->checkBox_Throughput_2->AutoSize = true;
			this->checkBox_Throughput_2->Enabled = false;
			this->checkBox_Throughput_2->Location = System::Drawing::Point(7, 103);
			this->checkBox_Throughput_2->Name = L"checkBox_Throughput_2";
			this->checkBox_Throughput_2->Size = System::Drawing::Size(81, 17);
			this->checkBox_Throughput_2->TabIndex = 72;
			this->checkBox_Throughput_2->Text = L"Throughput";
			this->checkBox_Throughput_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_Simtime_2
			// 
			this->checkBox_Simtime_2->AutoSize = true;
			this->checkBox_Simtime_2->Enabled = false;
			this->checkBox_Simtime_2->Location = System::Drawing::Point(8, 255);
			this->checkBox_Simtime_2->Name = L"checkBox_Simtime_2";
			this->checkBox_Simtime_2->Size = System::Drawing::Size(143, 17);
			this->checkBox_Simtime_2->TabIndex = 71;
			this->checkBox_Simtime_2->Text = L"Total Simulation Packets";
			this->checkBox_Simtime_2->UseVisualStyleBackColor = true;
			// 
			// label_Unknown_2
			// 
			this->label_Unknown_2->AutoSize = true;
			this->label_Unknown_2->Location = System::Drawing::Point(90, 25);
			this->label_Unknown_2->Name = L"label_Unknown_2";
			this->label_Unknown_2->Size = System::Drawing::Size(53, 13);
			this->label_Unknown_2->TabIndex = 70;
			this->label_Unknown_2->Text = L"Unknown";
			// 
			// checkBox125
			// 
			this->checkBox125->AutoSize = true;
			this->checkBox125->Checked = true;
			this->checkBox125->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox125->Enabled = false;
			this->checkBox125->Location = System::Drawing::Point(149, 25);
			this->checkBox125->Name = L"checkBox125";
			this->checkBox125->Size = System::Drawing::Size(55, 17);
			this->checkBox125->TabIndex = 69;
			this->checkBox125->Text = L"Time: ";
			this->checkBox125->UseVisualStyleBackColor = true;
			// 
			// label_analysis_time_2
			// 
			this->label_analysis_time_2->AutoSize = true;
			this->label_analysis_time_2->Location = System::Drawing::Point(200, 28);
			this->label_analysis_time_2->Name = L"label_analysis_time_2";
			this->label_analysis_time_2->Size = System::Drawing::Size(49, 13);
			this->label_analysis_time_2->TabIndex = 68;
			this->label_analysis_time_2->Text = L"00:00:00";
			// 
			// checkBox126
			// 
			this->checkBox126->AutoSize = true;
			this->checkBox126->Checked = true;
			this->checkBox126->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox126->Enabled = false;
			this->checkBox126->Location = System::Drawing::Point(6, 24);
			this->checkBox126->Name = L"checkBox126";
			this->checkBox126->Size = System::Drawing::Size(86, 17);
			this->checkBox126->TabIndex = 67;
			this->checkBox126->Text = L" File Format: ";
			this->checkBox126->UseVisualStyleBackColor = true;
			// 
			// label86
			// 
			this->label86->AutoSize = true;
			this->label86->Location = System::Drawing::Point(148, 256);
			this->label86->Name = L"label86";
			this->label86->Size = System::Drawing::Size(13, 13);
			this->label86->TabIndex = 66;
			this->label86->Text = L"0";
			// 
			// label87
			// 
			this->label87->AutoSize = true;
			this->label87->Location = System::Drawing::Point(148, 238);
			this->label87->Name = L"label87";
			this->label87->Size = System::Drawing::Size(13, 13);
			this->label87->TabIndex = 65;
			this->label87->Text = L"0";
			// 
			// label88
			// 
			this->label88->AutoSize = true;
			this->label88->Location = System::Drawing::Point(148, 217);
			this->label88->Name = L"label88";
			this->label88->Size = System::Drawing::Size(13, 13);
			this->label88->TabIndex = 64;
			this->label88->Text = L"0";
			// 
			// label89
			// 
			this->label89->AutoSize = true;
			this->label89->Location = System::Drawing::Point(148, 196);
			this->label89->Name = L"label89";
			this->label89->Size = System::Drawing::Size(13, 13);
			this->label89->TabIndex = 63;
			this->label89->Text = L"0";
			// 
			// label90
			// 
			this->label90->AutoSize = true;
			this->label90->Location = System::Drawing::Point(149, 172);
			this->label90->Name = L"label90";
			this->label90->Size = System::Drawing::Size(13, 13);
			this->label90->TabIndex = 62;
			this->label90->Text = L"0";
			// 
			// label91
			// 
			this->label91->AutoSize = true;
			this->label91->Location = System::Drawing::Point(148, 147);
			this->label91->Name = L"label91";
			this->label91->Size = System::Drawing::Size(13, 13);
			this->label91->TabIndex = 61;
			this->label91->Text = L"0";
			// 
			// label92
			// 
			this->label92->AutoSize = true;
			this->label92->Location = System::Drawing::Point(148, 124);
			this->label92->Name = L"label92";
			this->label92->Size = System::Drawing::Size(13, 13);
			this->label92->TabIndex = 60;
			this->label92->Text = L"0";
			// 
			// label93
			// 
			this->label93->AutoSize = true;
			this->label93->Location = System::Drawing::Point(148, 85);
			this->label93->Name = L"label93";
			this->label93->Size = System::Drawing::Size(13, 13);
			this->label93->TabIndex = 59;
			this->label93->Text = L"0";
			// 
			// label94
			// 
			this->label94->AutoSize = true;
			this->label94->Location = System::Drawing::Point(148, 65);
			this->label94->Name = L"label94";
			this->label94->Size = System::Drawing::Size(13, 13);
			this->label94->TabIndex = 58;
			this->label94->Text = L"0";
			// 
			// label95
			// 
			this->label95->AutoSize = true;
			this->label95->Location = System::Drawing::Point(148, 45);
			this->label95->Name = L"label95";
			this->label95->Size = System::Drawing::Size(13, 13);
			this->label95->TabIndex = 57;
			this->label95->Text = L"0";
			// 
			// label_Filename_2
			// 
			this->label_Filename_2->AutoSize = true;
			this->label_Filename_2->Location = System::Drawing::Point(79, 5);
			this->label_Filename_2->Name = L"label_Filename_2";
			this->label_Filename_2->Size = System::Drawing::Size(10, 13);
			this->label_Filename_2->TabIndex = 56;
			this->label_Filename_2->Text = L":";
			// 
			// checkBox127
			// 
			this->checkBox127->AutoSize = true;
			this->checkBox127->Checked = true;
			this->checkBox127->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox127->Enabled = false;
			this->checkBox127->Location = System::Drawing::Point(6, 4);
			this->checkBox127->Name = L"checkBox127";
			this->checkBox127->Size = System::Drawing::Size(82, 17);
			this->checkBox127->TabIndex = 55;
			this->checkBox127->Text = L" File Name: ";
			this->checkBox127->UseVisualStyleBackColor = true;
			// 
			// checkBox_Overh_2
			// 
			this->checkBox_Overh_2->AutoSize = true;
			this->checkBox_Overh_2->Enabled = false;
			this->checkBox_Overh_2->Location = System::Drawing::Point(7, 235);
			this->checkBox_Overh_2->Name = L"checkBox_Overh_2";
			this->checkBox_Overh_2->Size = System::Drawing::Size(73, 17);
			this->checkBox_Overh_2->TabIndex = 53;
			this->checkBox_Overh_2->Text = L"Overhead";
			this->checkBox_Overh_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_Lostpkt_2
			// 
			this->checkBox_Lostpkt_2->AutoSize = true;
			this->checkBox_Lostpkt_2->Enabled = false;
			this->checkBox_Lostpkt_2->Location = System::Drawing::Point(7, 213);
			this->checkBox_Lostpkt_2->Name = L"checkBox_Lostpkt_2";
			this->checkBox_Lostpkt_2->Size = System::Drawing::Size(88, 17);
			this->checkBox_Lostpkt_2->TabIndex = 52;
			this->checkBox_Lostpkt_2->Text = L"Lost Packets";
			this->checkBox_Lostpkt_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_DrpByts_2
			// 
			this->checkBox_DrpByts_2->AutoSize = true;
			this->checkBox_DrpByts_2->Enabled = false;
			this->checkBox_DrpByts_2->Location = System::Drawing::Point(7, 192);
			this->checkBox_DrpByts_2->Name = L"checkBox_DrpByts_2";
			this->checkBox_DrpByts_2->Size = System::Drawing::Size(123, 17);
			this->checkBox_DrpByts_2->TabIndex = 51;
			this->checkBox_DrpByts_2->Text = L"Total Dropped Bytes";
			this->checkBox_DrpByts_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_Drppks_2
			// 
			this->checkBox_Drppks_2->AutoSize = true;
			this->checkBox_Drppks_2->Enabled = false;
			this->checkBox_Drppks_2->Location = System::Drawing::Point(7, 170);
			this->checkBox_Drppks_2->Name = L"checkBox_Drppks_2";
			this->checkBox_Drppks_2->Size = System::Drawing::Size(136, 17);
			this->checkBox_Drppks_2->TabIndex = 50;
			this->checkBox_Drppks_2->Text = L"Total Dropped Packets";
			this->checkBox_Drppks_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_Receive_2
			// 
			this->checkBox_Receive_2->AutoSize = true;
			this->checkBox_Receive_2->Enabled = false;
			this->checkBox_Receive_2->Location = System::Drawing::Point(7, 147);
			this->checkBox_Receive_2->Name = L"checkBox_Receive_2";
			this->checkBox_Receive_2->Size = System::Drawing::Size(140, 17);
			this->checkBox_Receive_2->TabIndex = 49;
			this->checkBox_Receive_2->Text = L"Total Received packets";
			this->checkBox_Receive_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_Sent_2
			// 
			this->checkBox_Sent_2->AutoSize = true;
			this->checkBox_Sent_2->Enabled = false;
			this->checkBox_Sent_2->Location = System::Drawing::Point(7, 124);
			this->checkBox_Sent_2->Name = L"checkBox_Sent_2";
			this->checkBox_Sent_2->Size = System::Drawing::Size(117, 17);
			this->checkBox_Sent_2->TabIndex = 48;
			this->checkBox_Sent_2->Text = L"Total Sent Packets";
			this->checkBox_Sent_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_EED_2
			// 
			this->checkBox_EED_2->AutoSize = true;
			this->checkBox_EED_2->Enabled = false;
			this->checkBox_EED_2->Location = System::Drawing::Point(7, 84);
			this->checkBox_EED_2->Name = L"checkBox_EED_2";
			this->checkBox_EED_2->Size = System::Drawing::Size(109, 17);
			this->checkBox_EED_2->TabIndex = 47;
			this->checkBox_EED_2->Text = L"End to End Delay";
			this->checkBox_EED_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_NRL_2
			// 
			this->checkBox_NRL_2->AutoSize = true;
			this->checkBox_NRL_2->Enabled = false;
			this->checkBox_NRL_2->Location = System::Drawing::Point(7, 64);
			this->checkBox_NRL_2->Name = L"checkBox_NRL_2";
			this->checkBox_NRL_2->Size = System::Drawing::Size(78, 17);
			this->checkBox_NRL_2->TabIndex = 46;
			this->checkBox_NRL_2->Text = L"Normalized";
			this->checkBox_NRL_2->UseVisualStyleBackColor = true;
			// 
			// checkBox_PDF_2
			// 
			this->checkBox_PDF_2->AutoSize = true;
			this->checkBox_PDF_2->Enabled = false;
			this->checkBox_PDF_2->Location = System::Drawing::Point(7, 45);
			this->checkBox_PDF_2->Name = L"checkBox_PDF_2";
			this->checkBox_PDF_2->Size = System::Drawing::Size(129, 17);
			this->checkBox_PDF_2->TabIndex = 45;
			this->checkBox_PDF_2->Text = L"Packet Delivery Ratio";
			this->checkBox_PDF_2->UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this->tabPage3->Controls->Add(this->label111);
			this->tabPage3->Controls->Add(this->checkBox_Throughput_1);
			this->tabPage3->Controls->Add(this->checkBox_Analysis_time_1);
			this->tabPage3->Controls->Add(this->label_analysis_time_1);
			this->tabPage3->Controls->Add(this->label_Unknown_1);
			this->tabPage3->Controls->Add(this->checkBox116);
			this->tabPage3->Controls->Add(this->label18);
			this->tabPage3->Controls->Add(this->label17);
			this->tabPage3->Controls->Add(this->label16);
			this->tabPage3->Controls->Add(this->label15);
			this->tabPage3->Controls->Add(this->label14);
			this->tabPage3->Controls->Add(this->label13);
			this->tabPage3->Controls->Add(this->label12);
			this->tabPage3->Controls->Add(this->label11);
			this->tabPage3->Controls->Add(this->label10);
			this->tabPage3->Controls->Add(this->label9);
			this->tabPage3->Controls->Add(this->label_Filename_1);
			this->tabPage3->Controls->Add(this->checkBox_Filename_1);
			this->tabPage3->Controls->Add(this->checkBox_Simtime_1);
			this->tabPage3->Controls->Add(this->checkBox_Overh_1);
			this->tabPage3->Controls->Add(this->checkBox_Lostpkt_1);
			this->tabPage3->Controls->Add(this->checkBox_DrpByts_1);
			this->tabPage3->Controls->Add(this->checkBox_Drppks_1);
			this->tabPage3->Controls->Add(this->checkBox_Receive_1);
			this->tabPage3->Controls->Add(this->checkBox_Sent_1);
			this->tabPage3->Controls->Add(this->checkBox_EED_1);
			this->tabPage3->Controls->Add(this->checkBox_NRL_1);
			this->tabPage3->Controls->Add(this->checkBox_PDF_1);
			this->tabPage3->Location = System::Drawing::Point(4, 22);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Size = System::Drawing::Size(314, 273);
			this->tabPage3->TabIndex = 2;
			this->tabPage3->Text = L"File1";
			this->tabPage3->UseVisualStyleBackColor = true;
			// 
			// label111
			// 
			this->label111->AutoSize = true;
			this->label111->Location = System::Drawing::Point(145, 110);
			this->label111->Name = L"label111";
			this->label111->Size = System::Drawing::Size(13, 13);
			this->label111->TabIndex = 46;
			this->label111->Text = L"0";
			// 
			// checkBox_Throughput_1
			// 
			this->checkBox_Throughput_1->AutoSize = true;
			this->checkBox_Throughput_1->Enabled = false;
			this->checkBox_Throughput_1->Location = System::Drawing::Point(6, 108);
			this->checkBox_Throughput_1->Name = L"checkBox_Throughput_1";
			this->checkBox_Throughput_1->Size = System::Drawing::Size(81, 17);
			this->checkBox_Throughput_1->TabIndex = 45;
			this->checkBox_Throughput_1->Text = L"Throughput";
			this->checkBox_Throughput_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Analysis_time_1
			// 
			this->checkBox_Analysis_time_1->AutoSize = true;
			this->checkBox_Analysis_time_1->Checked = true;
			this->checkBox_Analysis_time_1->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_Analysis_time_1->Enabled = false;
			this->checkBox_Analysis_time_1->Location = System::Drawing::Point(145, 29);
			this->checkBox_Analysis_time_1->Name = L"checkBox_Analysis_time_1";
			this->checkBox_Analysis_time_1->Size = System::Drawing::Size(55, 17);
			this->checkBox_Analysis_time_1->TabIndex = 44;
			this->checkBox_Analysis_time_1->Text = L"Time: ";
			this->checkBox_Analysis_time_1->UseVisualStyleBackColor = true;
			// 
			// label_analysis_time_1
			// 
			this->label_analysis_time_1->AutoSize = true;
			this->label_analysis_time_1->Location = System::Drawing::Point(196, 32);
			this->label_analysis_time_1->Name = L"label_analysis_time_1";
			this->label_analysis_time_1->Size = System::Drawing::Size(49, 13);
			this->label_analysis_time_1->TabIndex = 43;
			this->label_analysis_time_1->Text = L"00:00:00";
			// 
			// label_Unknown_1
			// 
			this->label_Unknown_1->AutoSize = true;
			this->label_Unknown_1->Location = System::Drawing::Point(85, 30);
			this->label_Unknown_1->Name = L"label_Unknown_1";
			this->label_Unknown_1->Size = System::Drawing::Size(53, 13);
			this->label_Unknown_1->TabIndex = 42;
			this->label_Unknown_1->Text = L"Unknown";
			// 
			// checkBox116
			// 
			this->checkBox116->AutoSize = true;
			this->checkBox116->Checked = true;
			this->checkBox116->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox116->Enabled = false;
			this->checkBox116->Location = System::Drawing::Point(6, 28);
			this->checkBox116->Name = L"checkBox116";
			this->checkBox116->Size = System::Drawing::Size(86, 17);
			this->checkBox116->TabIndex = 41;
			this->checkBox116->Text = L" File Format: ";
			this->checkBox116->UseVisualStyleBackColor = true;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(145, 254);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(13, 13);
			this->label18->TabIndex = 40;
			this->label18->Text = L"0";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(145, 235);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(13, 13);
			this->label17->TabIndex = 39;
			this->label17->Text = L"0";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(145, 218);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(13, 13);
			this->label16->TabIndex = 38;
			this->label16->Text = L"0";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(145, 196);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(13, 13);
			this->label15->TabIndex = 37;
			this->label15->Text = L"0";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(145, 174);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(13, 13);
			this->label14->TabIndex = 36;
			this->label14->Text = L"0";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(145, 153);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(13, 13);
			this->label13->TabIndex = 35;
			this->label13->Text = L"0";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(145, 132);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(13, 13);
			this->label12->TabIndex = 34;
			this->label12->Text = L"0";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(145, 92);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(13, 13);
			this->label11->TabIndex = 33;
			this->label11->Text = L"0";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(145, 72);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(13, 13);
			this->label10->TabIndex = 32;
			this->label10->Text = L"0";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(145, 51);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(13, 13);
			this->label9->TabIndex = 31;
			this->label9->Text = L"0";
			// 
			// label_Filename_1
			// 
			this->label_Filename_1->AutoSize = true;
			this->label_Filename_1->Location = System::Drawing::Point(78, 5);
			this->label_Filename_1->Name = L"label_Filename_1";
			this->label_Filename_1->Size = System::Drawing::Size(10, 13);
			this->label_Filename_1->TabIndex = 30;
			this->label_Filename_1->Text = L":";
			// 
			// checkBox_Filename_1
			// 
			this->checkBox_Filename_1->AutoSize = true;
			this->checkBox_Filename_1->Checked = true;
			this->checkBox_Filename_1->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_Filename_1->Enabled = false;
			this->checkBox_Filename_1->Location = System::Drawing::Point(6, 4);
			this->checkBox_Filename_1->Name = L"checkBox_Filename_1";
			this->checkBox_Filename_1->Size = System::Drawing::Size(82, 17);
			this->checkBox_Filename_1->TabIndex = 29;
			this->checkBox_Filename_1->Text = L" File Name: ";
			this->checkBox_Filename_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Simtime_1
			// 
			this->checkBox_Simtime_1->AutoSize = true;
			this->checkBox_Simtime_1->Enabled = false;
			this->checkBox_Simtime_1->Location = System::Drawing::Point(7, 253);
			this->checkBox_Simtime_1->Name = L"checkBox_Simtime_1";
			this->checkBox_Simtime_1->Size = System::Drawing::Size(143, 17);
			this->checkBox_Simtime_1->TabIndex = 28;
			this->checkBox_Simtime_1->Text = L"Total Simulation Packets";
			this->checkBox_Simtime_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Overh_1
			// 
			this->checkBox_Overh_1->AutoSize = true;
			this->checkBox_Overh_1->Enabled = false;
			this->checkBox_Overh_1->Location = System::Drawing::Point(7, 234);
			this->checkBox_Overh_1->Name = L"checkBox_Overh_1";
			this->checkBox_Overh_1->Size = System::Drawing::Size(73, 17);
			this->checkBox_Overh_1->TabIndex = 27;
			this->checkBox_Overh_1->Text = L"Overhead";
			this->checkBox_Overh_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Lostpkt_1
			// 
			this->checkBox_Lostpkt_1->AutoSize = true;
			this->checkBox_Lostpkt_1->Enabled = false;
			this->checkBox_Lostpkt_1->Location = System::Drawing::Point(7, 214);
			this->checkBox_Lostpkt_1->Name = L"checkBox_Lostpkt_1";
			this->checkBox_Lostpkt_1->Size = System::Drawing::Size(88, 17);
			this->checkBox_Lostpkt_1->TabIndex = 26;
			this->checkBox_Lostpkt_1->Text = L"Lost Packets";
			this->checkBox_Lostpkt_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_DrpByts_1
			// 
			this->checkBox_DrpByts_1->AutoSize = true;
			this->checkBox_DrpByts_1->Enabled = false;
			this->checkBox_DrpByts_1->Location = System::Drawing::Point(7, 192);
			this->checkBox_DrpByts_1->Name = L"checkBox_DrpByts_1";
			this->checkBox_DrpByts_1->Size = System::Drawing::Size(123, 17);
			this->checkBox_DrpByts_1->TabIndex = 25;
			this->checkBox_DrpByts_1->Text = L"Total Dropped Bytes";
			this->checkBox_DrpByts_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Drppks_1
			// 
			this->checkBox_Drppks_1->AutoSize = true;
			this->checkBox_Drppks_1->Enabled = false;
			this->checkBox_Drppks_1->Location = System::Drawing::Point(6, 170);
			this->checkBox_Drppks_1->Name = L"checkBox_Drppks_1";
			this->checkBox_Drppks_1->Size = System::Drawing::Size(136, 17);
			this->checkBox_Drppks_1->TabIndex = 24;
			this->checkBox_Drppks_1->Text = L"Total Dropped Packets";
			this->checkBox_Drppks_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Receive_1
			// 
			this->checkBox_Receive_1->AutoSize = true;
			this->checkBox_Receive_1->Enabled = false;
			this->checkBox_Receive_1->Location = System::Drawing::Point(6, 149);
			this->checkBox_Receive_1->Name = L"checkBox_Receive_1";
			this->checkBox_Receive_1->Size = System::Drawing::Size(140, 17);
			this->checkBox_Receive_1->TabIndex = 23;
			this->checkBox_Receive_1->Text = L"Total Received packets";
			this->checkBox_Receive_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_Sent_1
			// 
			this->checkBox_Sent_1->AutoSize = true;
			this->checkBox_Sent_1->Enabled = false;
			this->checkBox_Sent_1->Location = System::Drawing::Point(6, 128);
			this->checkBox_Sent_1->Name = L"checkBox_Sent_1";
			this->checkBox_Sent_1->Size = System::Drawing::Size(117, 17);
			this->checkBox_Sent_1->TabIndex = 22;
			this->checkBox_Sent_1->Text = L"Total Sent Packets";
			this->checkBox_Sent_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_EED_1
			// 
			this->checkBox_EED_1->AutoSize = true;
			this->checkBox_EED_1->Enabled = false;
			this->checkBox_EED_1->Location = System::Drawing::Point(6, 88);
			this->checkBox_EED_1->Name = L"checkBox_EED_1";
			this->checkBox_EED_1->Size = System::Drawing::Size(109, 17);
			this->checkBox_EED_1->TabIndex = 21;
			this->checkBox_EED_1->Text = L"End to End Delay";
			this->checkBox_EED_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_NRL_1
			// 
			this->checkBox_NRL_1->AutoSize = true;
			this->checkBox_NRL_1->Enabled = false;
			this->checkBox_NRL_1->Location = System::Drawing::Point(6, 68);
			this->checkBox_NRL_1->Name = L"checkBox_NRL_1";
			this->checkBox_NRL_1->Size = System::Drawing::Size(78, 17);
			this->checkBox_NRL_1->TabIndex = 20;
			this->checkBox_NRL_1->Text = L"Normalized";
			this->checkBox_NRL_1->UseVisualStyleBackColor = true;
			// 
			// checkBox_PDF_1
			// 
			this->checkBox_PDF_1->AutoSize = true;
			this->checkBox_PDF_1->Enabled = false;
			this->checkBox_PDF_1->Location = System::Drawing::Point(6, 48);
			this->checkBox_PDF_1->Name = L"checkBox_PDF_1";
			this->checkBox_PDF_1->Size = System::Drawing::Size(129, 17);
			this->checkBox_PDF_1->TabIndex = 19;
			this->checkBox_PDF_1->Text = L"Packet Delivery Ratio";
			this->checkBox_PDF_1->UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this->tabPage2->BackColor = System::Drawing::Color::White;
			this->tabPage2->Controls->Add(this->label4);
			this->tabPage2->Controls->Add(this->label2);
			this->tabPage2->Controls->Add(this->label3);
			this->tabPage2->ForeColor = System::Drawing::SystemColors::ActiveBorder;
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(314, 273);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"Results TabPages";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label4->Location = System::Drawing::Point(78, 141);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(191, 57);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Tab Pages";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label2->Location = System::Drawing::Point(20, 32);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(162, 57);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Analysis";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label3->Location = System::Drawing::Point(45, 85);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(137, 57);
			this->label3->TabIndex = 1;
			this->label3->Text = L"Results";
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage3);
			this->tabControl1->Controls->Add(this->tabPage6);
			this->tabControl1->Controls->Add(this->tabPage11);
			this->tabControl1->Location = System::Drawing::Point(271, 80);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(322, 299);
			this->tabControl1->TabIndex = 18;
			this->tabControl1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::tabControl1_SelectedIndexChanged);
			// 
			// label125
			// 
			this->label125->AutoSize = true;
			this->label125->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label125->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label125->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label125->Location = System::Drawing::Point(309, 470);
			this->label125->Name = L"label125";
			this->label125->Size = System::Drawing::Size(211, 57);
			this->label125->TabIndex = 26;
			this->label125->Text = L"Information";
			// 
			// label126
			// 
			this->label126->AutoSize = true;
			this->label126->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label126->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label126->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label126->Location = System::Drawing::Point(346, 527);
			this->label126->Name = L"label126";
			this->label126->Size = System::Drawing::Size(111, 57);
			this->label126->TabIndex = 27;
			this->label126->Text = L"Page";
			this->label126->Click += gcnew System::EventHandler(this, &Form1::label126_Click);
			// 
			// label124
			// 
			this->label124->AutoSize = true;
			this->label124->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label124->Font = (gcnew System::Drawing::Font(L"Edwardian Script ITC", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label124->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label124->Location = System::Drawing::Point(295, 426);
			this->label124->Name = L"label124";
			this->label124->Size = System::Drawing::Size(115, 57);
			this->label124->TabIndex = 28;
			this->label124->Text = L"File\'s";
			// 
			// Form1
			// 
			this->AllowDrop = true;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1117, 765);
			this->Controls->Add(this->label124);
			this->Controls->Add(this->label126);
			this->Controls->Add(this->label125);
			this->Controls->Add(this->groupBox7);
			this->Controls->Add(this->groupBox_Results_graphics);
			this->Controls->Add(this->groupBox9);
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->groupBox8);
			this->Controls->Add(this->Process_Notes);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox_SystemTime);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->checkBox_Records);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->label_Record);
			this->Controls->Add(this->progressBar1);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->MainMenuStrip = this->menuStrip1;
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
			this->Text = L"GUI: Ns2 Trace File Analyser         Dependable Systems Group at Heriot-Watt Univ" 
				L"ersity";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox6->ResumeLayout(false);
			this->groupBox_SystemTime->ResumeLayout(false);
			this->groupBox_SystemTime->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->Process_Notes->ResumeLayout(false);
			this->Process_Notes->PerformLayout();
			this->groupBox8->ResumeLayout(false);
			this->groupBox8->PerformLayout();
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->tabPage7->ResumeLayout(false);
			this->tabPage7->PerformLayout();
			this->tabPage8->ResumeLayout(false);
			this->tabPage8->PerformLayout();
			this->tabPage9->ResumeLayout(false);
			this->tabPage9->PerformLayout();
			this->tabPage10->ResumeLayout(false);
			this->tabPage10->PerformLayout();
			this->tabPage4->ResumeLayout(false);
			this->tabPage4->PerformLayout();
			this->tabPage5->ResumeLayout(false);
			this->tabPage5->PerformLayout();
			this->groupBox9->ResumeLayout(false);
			this->groupBox9->PerformLayout();
			this->groupBox_PDF->ResumeLayout(false);
			this->groupBox_PDF->PerformLayout();
			this->groupBox_Results_graphics->ResumeLayout(false);
			this->groupBox_DropPkts->ResumeLayout(false);
			this->groupBox_DropPkts->PerformLayout();
			this->groupBox_Throughput->ResumeLayout(false);
			this->groupBox_Throughput->PerformLayout();
			this->groupBox_OH->ResumeLayout(false);
			this->groupBox_OH->PerformLayout();
			this->groupBox_EED->ResumeLayout(false);
			this->groupBox_EED->PerformLayout();
			this->groupBox_NRL->ResumeLayout(false);
			this->groupBox_NRL->PerformLayout();
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->groupBox7->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->tabPage11->ResumeLayout(false);
			this->tabPage11->PerformLayout();
			this->tabPage6->ResumeLayout(false);
			this->tabPage6->PerformLayout();
			this->tabPage3->ResumeLayout(false);
			this->tabPage3->PerformLayout();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->tabControl1->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
						Form1::CenterToScreen();
                        this->ClientSize = System::Drawing::Size(606, 765);
			 }

private: System::Void Select_Trace_File_button_Click(System::Object^  sender, System::EventArgs^  e){	 
     // Displays an OpenFileDialog so the user can select a Cursor.
     // OpenFileDialog ^ openFileDialog1 = gcnew OpenFileDialog();

this->groupBox_Results_graphics->Visible=false;
this->ClientSize = System::Drawing::Size(606, 765);

     this->progressBar1->Value=0;
	  openFileDialog1->Filter = "Trace Files|*.tr";
      openFileDialog1->Title = "Select a Trace File";
	  openFileDialog1->FileName=" ";
	  file_select=false;
      // Show the Dialog.
      // If the user clicked OK in the dialog and
      // a .CUR file was selected, open it.
   if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   {    
	 //MessageBox::Show("The File has been Selected SUCCESSULLY","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Information);
	   this->radioButton_Fileselect->Enabled=true;
	   this->radioButton_Fileselect->Checked=true;
	   this->radioButton_Startanalysis->Enabled=false;
	   this->radioButton_Perfoprmance->Enabled=false;
	   this->radioButton_Results_save->Enabled=false;
       file_select=true;
   }
   else // if cancel is pressed from the open file dialog return with doing nothing
	   MessageBox::Show("No File has been Selected","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Hand);
   return; 
}

private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
// This code retrieves file properties. The example uses Notepad.exe.
listBox1->Items->Clear();
String^ testfile = String::Concat(windir,"\\notepad.exe");
FileInfo^ pFileProps = gcnew FileInfo(testfile);

listBox1->Items->Add(String::Concat("File Name = ", pFileProps->FullName));
listBox1->Items->Add(String::Concat("Creation Time = ", pFileProps->CreationTime.ToString()));
listBox1->Items->Add(String::Concat("Last Access Time = ", pFileProps->LastAccessTime.ToString()));
listBox1->Items->Add(String::Concat("Last Write Time = ", pFileProps->LastWriteTime.ToString()));
listBox1->Items->Add(String::Concat("Size = ", pFileProps->Length.ToString()));
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
// This shows you how to obtain a list of disk drivers.
cli::array<String^>^ drives = Directory::GetLogicalDrives();
int numDrives = drives->Length;
for(int i=0; i<numDrives; i++){listBox1->Items->Add(drives[i]);}
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
// This code obtains a list of folders. This example uses the Windows folder.
			 cli::array<String^>^ dirs = Directory::GetDirectories("c:\\");
int numDirs = dirs->Length;
for(int i=0; i<numDirs; i++){listBox1->Items->Add(dirs[i]);}
 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
// This code obtains a list of files. This example uses the Windows folder.
			 cli::array<String^>^ files = Directory::GetFiles("c:\\");
int numFiles = files->Length;
for(int i=0; i<numFiles; i++){listBox1->Items->Add(files[i]);}
 }

void file_information(FileInfo^ pFileProps, int Trace_file)
{
// This code retrieves file properties. The example uses Notepad.exe.
//listBox1->Items->Clear();
// String^ testfile = String::Concat(file_name);
// FileInfo^ pFileProps = gcnew FileInfo(testfile);
//listBox1->Items->Add(String::Concat("Date: ",System::DateTime::Now ));// print date, time
	  /*  if(Trace_file==1)
			listBox1->Items->Add(String::Concat("File Format Type: Old"));// print one time
		else if(Trace_file==2)
			   listBox1->Items->Add(String::Concat("File Format Type: Normal Tagged"));// print one time
		    else if (Trace_file==3)
			   listBox1->Items->Add(String::Concat("File Format Type: New"));// print one time*/
	    listBox1->Items->Clear(); // clear listBox1
		listBox1->Items->Add(String::Concat(" "));
		listBox1->Items->Add(String::Concat("File Information :"));
		listBox1->Items->Add(String::Concat("----------------------------------------------------------------------------------------------------------------------------"));		
		//listBox1->Items->Add(String::Concat("File Name = ", pFileProps->FullName));	
		listBox1->Items->Add(String::Concat("File Direcory :", pFileProps->Directory));
		listBox1->Items->Add(String::Concat("File Name :", pFileProps->Name));
if(this->checkBox_Fileinformation->Checked == true)
	{
        if(Trace_file==1)
			listBox1->Items->Add(String::Concat("File Format Type: Old"));// print one time
		else if(Trace_file==2)
			   listBox1->Items->Add(String::Concat("File Format Type: Normal Tagged"));// print one time
		    else if (Trace_file==3)
			   listBox1->Items->Add(String::Concat("File Format Type: New"));// print one time
		listBox1->Items->Add(String::Concat("Creation Time = ", pFileProps->CreationTime.ToString()));
		listBox1->Items->Add(String::Concat("Last Access Time = ", pFileProps->LastAccessTime.ToString()));
		listBox1->Items->Add(String::Concat("Last Write Time = ", pFileProps->LastWriteTime.ToString()));
		listBox1->Items->Add(String::Concat("Size = ", pFileProps->Length.ToString()));
     }

listBox1->Items->Add(String::Concat(" "));
listBox1->Items->Add(String::Concat("Performance Evaluation :"));
listBox1->Items->Add(String::Concat("--------------------------------------------------------------------------------------------------------------------------"));
}
double File_size(FileInfo^ pFileProps2)
{

	return (System::Convert::ToInt64(pFileProps2->Length.ToString())); // returns file size


}


private: System::Void timer2_Tick(System::Object^  sender, System::EventArgs^  e) {			
			 if(checkBox_Sys_Date->Checked)
			    this->label_Sys_Date->Text=Convert::ToString(System::DateTime::Now);
			 //System::Time::Now;
		 }
private: System::Void Text_Board_clear_button_Click(System::Object^  sender, System::EventArgs^  e) {
				listBox1->Items->Clear(); // clear listBox1
				label_Record->Text="0";
		 }
private: System::Void Set_all_Metrics_button_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->checkBox_DropBytes->Checked= true;
			 this->checkBox_DropPkt->Checked= true;
			 this->checkBox_EED->Checked= true;
			 this->checkBox_Throughput->Checked= true;
			 this->checkBox_Fileinformation->Checked= true;
			 this->checkBox_LostPkt->Checked= true;
			 this->checkBox_NRL->Checked= true;
			 this->checkBox_PDF->Checked= true;
			 this->checkBox_Records->Checked= true;
			 this->checkBox_RecvPkt->Checked= true;
			 this->checkBox_RoutingPkt->Checked= true;
			 this->checkBox_SentPkt->Checked= true;
			 this->checkBox_SimTime->Checked= true;
		 }
private: System::Void Clearall_button_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->checkBox_DropBytes->Checked = false;
			 this->checkBox_DropPkt->Checked = false;
			 this->checkBox_EED->Checked = false;
			 this->checkBox_Throughput->Checked= false;
			 this->checkBox_Fileinformation->Checked = false;
			 this->checkBox_LostPkt->Checked= false;
			 this->checkBox_NRL->Checked= false;
			 this->checkBox_PDF->Checked= false;
			 this->checkBox_Records->Checked= true;
			 this->checkBox_RecvPkt->Checked= false;
			 this->checkBox_RoutingPkt->Checked= false;
			 this->checkBox_SentPkt->Checked= false;
			 this->checkBox_SimTime->Checked= false;
		 }
private: System::Void Most_used_Metrics_button_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->checkBox_DropBytes->Checked = false;
			 this->checkBox_DropPkt->Checked = true;
			 this->checkBox_EED->Checked = true;
			 this->checkBox_Throughput->Checked= false;
			 this->checkBox_Fileinformation->Checked = false;
			 this->checkBox_LostPkt->Checked= false;
			 this->checkBox_NRL->Checked= true;
			 this->checkBox_PDF->Checked= true;
			 this->checkBox_Records->Checked= true;
			 this->checkBox_RecvPkt->Checked= false;
			 this->checkBox_RoutingPkt->Checked= true;
			 this->checkBox_SentPkt->Checked= false;
			 this->checkBox_SimTime->Checked= false;  
		 }
private: System::Void Start_Analysis_button_Click(System::Object^  sender, System::EventArgs^  e) {
 
   
	int Line_counter=1; // how many Lines	 
    int Total_r_Times=0;
	int Total_f_Times=0;
	int Total_d_Times=0;
	int Total_M_Times=0;
     
    /*int beacon_no=0;		  //for control packet
    int frip_no=0;			  //for control packet
    int rsup_no=0;			  //for control packet
    int rrep_no=0;		      //for control packet   
    int rreq_no=0;			  //for control packet
    int Control_Total_packet=0;  //for control packet*/
    file_read=false;
	  
    int cbr_no=0;			  // for data packet
    int tcp_no=0;			  // for data packet
    int ack_no=0;		      // for data packet
	int hdr_size=0;           // for data packet header
	
    //int Data_Total_packet=0 ;	  // for data packet

    double recvdSize = 0.0;	  // for throughput
	double start_time[9999]= {0.0} ;
	double end_time[9999]={0.0} ;
	int Highest_Packet_Id=0;
	double sum=0.0;
    double time;
	int Packet_id;
	int Packet_size;
      
	// Global Parameters Intialization
	/////////////////////////////////////////////////////
	Simulation_Packet_Counter=0;
    routing_packets=0;
    Total_Sent_Pkt=0;
    Total_Received_Pkt=0;
	Control_Total_pkt=0;
    Total_Dropped_Packets=0;
	Total_Dropped_Bytes=0;
	NRL=0.0;
	PDF=0.0;
    Throughput=0.0;
    EEDelay;
	Total_lost=0.0;
	startTime  = 1e6 ;	  // for throughput
    stopTime   = 0.0 ;	  // for throughput
    ////////////////////////////////////////////////////////
      // Displays an OpenFileDialog so the user can select a Cursor.
      ///OpenFileDialog ^ openFileDialog1 = gcnew OpenFileDialog();
      //openFileDialog1->Filter = "Trace Files|*.tr";
      //openFileDialog1->Title = "Select a Trace File";
	 
      // Show the Dialog.
      // If the user clicked OK in the dialog and
      // a .CUR file was selected, open it.
  //if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   //{  

	int Trace_file_is_known=0;  // flag 
	try {
		// Open the selected file openFileDialog1->FileName
		StreamReader^ reader = gcnew StreamReader(openFileDialog1->FileName); 
		progressBar1->Value=0;
		double Maximum_size=File_size(gcnew FileInfo(openFileDialog1->FileName));
		   if(Maximum_size>=999999)
			   Maximum_size=Maximum_size/100;
		   else if (Maximum_size>=99999)
			   Maximum_size=Maximum_size/10;
        progressBar1->Maximum=Maximum_size/2; 
	   do  // read a line by line until reaches the end of the file  
	   {
			    String ^t_$2=" ";
			    String ^time_=" ";
				String ^event_=" ";
				String ^node_id=" ";
				String ^level=" ";
				String ^packet_type=" ";
				String ^packet_size=" ";
				String ^packet_id=" ";
				String ^flow_id=" ";
				String ^flow_t =" ";
				int Column_No=1;
				String ^Column_text_="";
				String ^str1= System::Convert::ToString(reader->ReadLine());
				
				 this->progressBar1->Value=progressBar1->Value+1;
                 if(this->progressBar1->Value>=progressBar1->Maximum)
					 progressBar1->Value=0;
				char* str2 =(char*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(str1).ToPointer(); // to convert  string  to char string ,pointer string(to able string functions using)
				int len_Line = strlen(str2);
	            // This part is To check the Trace File Format type
			    //=============================================================================
					if(Trace_file_is_known==0) // flag  to print file format only one time   
					{	if(str1[2]=='-' && str1[3]=='t') 						 
						    Trace_file_is_known=3; 
						 else if(str1[0]=='-' || str1[0]=='+' || str1[0]=='r' || str1[0]=='d'|| str1[0]=='h' || str1[0]=='M' && str1[1]==' ' && System::Convert::ToDouble(str1[2])>=0 && str1[3]=='.')
								Trace_file_is_known=2; 
							  else if(str1[0]=='s' || str1[0]=='r'|| str1[0]=='D' || str1[0]=='d'|| str1[0]=='M'&& str1[1]==' ' && System::Convert::ToDouble(str1[2])>=0 && str1[3]=='.')
									 Trace_file_is_known=1;
					}			
		          //=============================================================================
				   if(Trace_file_is_known!=0) // 1,2 or 3 
					for(int i=0;i<len_Line;i++) // Reads the line character by character
					{
					  if(str1[i]!=' ') //  if the characterit is not a blank somthing, read it (save it)
					   Column_text_ =String::Concat(Column_text_,str1[i]); // save the character in Column_text_ variabl
					  else // blank (space), it means the first column was read (already is read)
					  {
						if(Column_No==1) // the first character (field #1)is the event 
					    	event_ = Column_text_; //event is the contents of field #1 in the trace file which is s(+),r,f (h) or d (D)
						else if(Column_No==2)
						     t_$2 = Column_text_;     // -t contents of field #2
						//==========================================================================
						// Now let us see the file format 
						if(Trace_file_is_known==3 && event_!="M")//3- New format
						{	if(Column_No==3)//time = contents of 2nd field in the trace file 
								  time_= Column_text_;
								else if(Column_No==5)
									   node_id = Column_text_;  
									 else if(Column_No==19)
											level = Column_text_;
										  else if(Column_No==35)//packet_type is the contents of field #35 in the trace file
												 packet_type = Column_text_;
											   else if(Column_No==37)//packet_size is the contents of field #37 in the trace file
													  packet_size = Column_text_;
													else if(Column_No==39)
													  flow_id = Column_text_;
														 else if(Column_No==41)//packet_id =contents of field #41 in the trace file
														 {packet_id = Column_text_;
													      break;}
						}	
						else if (Trace_file_is_known==2 && event_!="M") //2- tagged trace format 
						{   if(Column_No==2)
								time_= Column_text_;//time = contents of 2nd field in the trace file 
							   else if(Column_No==4)
									node_id = Column_text_;
									else if(Column_No==7)
									     packet_id = Column_text_;
									     else if(Column_No==8)//packet_type is the contents of field #8 in the trace file
									          packet_type = Column_text_;
									          else if(Column_No==10)
									               level = Column_text_;
											       else if(Column_No==38)
										                packet_size = Column_text_;	
														else if(Column_No==42)//packet_id =contents of field #43 in the trace file
														{packet_id = Column_text_;
												         break;}
						 }
						else if (Trace_file_is_known==1 && event_!="M") //1- Old trace format 
						{	if(Column_No==2)
								time_= Column_text_;//time = contents of 2nd field in the trace file 
							  else if(Column_No==3)
								   node_id = Column_text_;
								   else if(Column_No==4)
								        level = Column_text_;
								    	else if(Column_No==7)
										     packet_id = Column_text_;
										   else if(Column_No==8)//packet_type is the contents of field #8 in the trace file
											    packet_type = Column_text_;
										        else if(Column_No==9)
												{packet_size = Column_text_;
										         break;}
						}
						    //Trace Format Prints one time only @ the begining
						    //listBox1->Items->Add(String::Concat(Column_No,"   ",Column_text_));
							Column_No++;
							Column_text_ ="";
					  }
					  if (Column_text_=="M"){Line_counter++; // count this line eventhough is is M
						  break;}
					}
					if (Column_text_!="M" && Column_text_!=""){// Don't print any line starts with M (No need)
				          //listBox1->Items->Add(String::Concat(Line_counter.ToString()," ",event_ ,"   ",time_,"   ",node_id,"   ",level,"   ",packet_id,"   ",packet_type,"   ",packet_size));
					      //listBox1->Items->Add("===================================");
						  //label1->Text=Line_counter.ToString();
						  // how many Lines 
						  Line_counter++; 
				
						  //====== Start of Performance calculation  //idris
						  //CALCULATE packetDELIVERY FRACTION (Data Packets)
						  time= System::Convert::ToDouble(time_);
						  Packet_id= System::Convert::ToInt16(packet_id);
						  Packet_size= System::Convert::ToInt16(packet_size);
      
  
						  if (( event_ == "s" || event_ == "+") &&  (packet_type == "cbr" || packet_type == "tcp" || packet_type == "ack") && (level=="AGT")) {Total_Sent_Pkt++;}
						  else if (( event_ == "r") &&  (packet_type == "cbr" || packet_type == "tcp" || packet_type == "ack") && (level=="AGT")) {Total_Received_Pkt++;}
						       
						  // CALCULATE DELAY for a Specific Packet
						  if ( start_time[Packet_id] == 0) start_time[Packet_id] =  time; 
						  if (( event_ == "r") &&  ( packet_type == "cbr" || packet_type == "tcp" || packet_type == "ack" ) && (level=="AGT")) { end_time[Packet_id]= time;}
						   else {end_time[Packet_id] = -1;  }
						 
						     
						  //# CALCULATE TOTAL OVERHEAD (Control Packets), Only the send and forwared  packets 
						   /*if ((event_ == "s" || event_ == "+" || event_ == "f" || event_ == "h") && (level=="RTR") && (packet_type == "DSDV" || packet_type =="REQUEST" || packet_type =="REPLY"|| packet_type == "AODV" || 
						    packet_type == "DSR" || packet_type =="message" || packet_type =="BEACON" || packet_type =="FRIP" || packet_type =="RSUP" || packet_type =="ROUTE_REQ" || packet_type =="ROUTE_REP"))
						    routing_packets++; */
						    
						   if ((event_ == "s" || event_ == "+" || event_ == "f" || event_ == "h") && (level=="RTR" ) &&  (packet_type != "cbr" && packet_type != "ack" && packet_type != "tcp"))
							  Control_Total_pkt++;
					    
						 
						// DROPPED   PACKETS 
						  if (( event_ == "d" || event_ == "D") &&  (packet_type == "cbr" || packet_type == "tcp")  && ( time>0 ))
							   {
									 Total_Dropped_Bytes=Total_Dropped_Bytes + Packet_size;     
									 Total_Dropped_Packets++;
							   }
						   
						// find the number of packets in the simulation
						 if (Packet_id > Highest_Packet_Id)
						    {Highest_Packet_Id = Packet_id;
						     Simulation_Packet_Counter++; }
						 
						 //====== End of Performance calculation*/

						//====== Start of Throughput calculation
						// # Store start time
						 if ((level == "AGT") && (event_ == "+" || event_ == "s") && Packet_size >= 512) {
							if (time < startTime) {
									 startTime = time;
									 }
							   }
					  // Update total received packets' size and store packets arrival time
						 if (level == "AGT" && event_== "r" && Packet_size >= 512) {
						   if (time > stopTime) {
								 stopTime = time;
								 }
						   // Rip off the header
						   hdr_size = Packet_size % 512;
						   Packet_size -= hdr_size;
						  // Store received packet's size;
						   recvdSize += Packet_size;
						   }
					//====== End of Throughput calculation

					}
					
		}
		while(reader->Peek() != -1);  // this while is for do, it means the EOF
		reader->Close(); // close the file
		this->progressBar1->Value=progressBar1->Maximum;
        file_read=true;
	  if(this->checkBox_Records->Checked == true) 
		label_Record->Text=Line_counter.ToString();
	  else label_Record->Text="0";
    	if(Trace_file_is_known==1 || Trace_file_is_known==2 ||Trace_file_is_known==3)
	    	{
			//This part should deleted later on, it is just for double check
			/*listBox1->Items->Add(String::Concat("Total Times of s event= " , Total_s_Times));
			listBox1->Items->Add(String::Concat("Total Times of r event= " , Total_r_Times));
			listBox1->Items->Add(String::Concat("Total Times of f event= " , Total_f_Times));
			listBox1->Items->Add(String::Concat("Total Times of d event= " , Total_d_Times));
			listBox1->Items->Add(String::Concat("Total Times of M event= " , Total_M_Times));*/

			//====== This part for Performance calculation
 /*	   for ( i in end_time )
  { 
  start = start_time[i];
  end = end_time[i];
  packet_duration = end - start;
  if ( packet_duration > 0 )  
  {    sum += packet_duration;
       recvnum++; 
  }
  
  } */
			  double sum;
              int recvnum;
			for (int i=0;i<=Packet_id;i++)
			{
				  double start = start_time[i];
				  double end = end_time[i];
				  double packet_duration = end - start;
				  if ( packet_duration > 0 ){ 
					    sum += packet_duration;
					    recvnum++; }			  
			  }  
				 if(recvnum==0)
					recvnum++; // set to 1 
				 if(Total_Sent_Pkt==0)
				 { MessageBox::Show("NOTE: No Data Sent .......","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Exclamation);
				   Total_Sent_Pkt++; return;}  // set to 1, no divid by 0
				 if(Total_Received_Pkt==0)
				 {MessageBox::Show("NOTE: No Data Received .......","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Exclamation);
					Total_Received_Pkt++;return;}  // set to 1, no divid by 0
			      
				   EEDelay=sum/recvnum;
				   NRL = (Control_Total_pkt / Total_Received_Pkt);  // normalized routing load 
				   PDF = (Total_Received_Pkt / Total_Sent_Pkt)*100;  // packet delivery ratio[fraction]
			       Throughput=((recvdSize/(stopTime-startTime))* 8/1000);
				   Total_lost = Total_Sent_Pkt-Total_Received_Pkt-Total_Dropped_Packets;	   

			//This is the Performance calculation print part
			// call the get a file informaton function to get the selected file information 	  
			file_information(gcnew FileInfo(openFileDialog1->FileName),Trace_file_is_known);
			
			listBox1->Items->Add(String::Concat("Transmition Start Time .....=",startTime));
			if(this->checkBox_PDF->Checked == true)				
			  listBox1->Items->Add(String::Concat("Packet Delivery Ratio..(PDF)= " , PDF));
			
			if(this->checkBox_NRL->Checked == true)			
			  listBox1->Items->Add(String::Concat("Normalized ............(NRL)= " , NRL));
			 
			if(this->checkBox_EED->Checked == true)			
			  listBox1->Items->Add(String::Concat("End to End Delay ......(EED)= " ,EEDelay*1000)); // miliseconds
			
			if(this->checkBox_Throughput->Checked==true) 
			listBox1->Items->Add(String::Concat("Average Throughput[kbps] = ",Throughput));

			if(this->checkBox_SentPkt->Checked == true)			
			  listBox1->Items->Add(String::Concat("Total Sent Packets .........= " , Total_Sent_Pkt));
              
			if(this->checkBox_RecvPkt->Checked == true)			
			 listBox1->Items->Add(String::Concat("Total Received Packets .....= " , Total_Received_Pkt));
			 
			if(this->checkBox_DropPkt->Checked == true)			 
			  listBox1->Items->Add(String::Concat("Total Dropped Packets ......= " , Total_Dropped_Packets));
			 
			if(this->checkBox_DropBytes->Checked == true)			
			  listBox1->Items->Add(String::Concat("Total Dropped Bytes ........= " , Total_Dropped_Bytes));
			 
			if(this->checkBox_LostPkt->Checked == true)			
			  listBox1->Items->Add(String::Concat("Total Lost Packets .........= " , Total_lost));
			 
			if(this->checkBox_RoutingPkt->Checked == true)			
			  listBox1->Items->Add(String::Concat("Routing Packets ..(Overhead)=",Control_Total_pkt));
			 
			if(this->checkBox_SimTime->Checked == true)			
			  listBox1->Items->Add(String::Concat("Total Simulation Packets ...= " , Simulation_Packet_Counter));
			 
			listBox1->Items->Add(String::Concat("Transmition Stop Time .....=",stopTime));
   
           
			
			listBox1->Items->Add(String::Concat("Date: ",System::DateTime::Now ));// print date, time
		    listBox1->Items->Add(String::Concat("==================================================================")); // print date, time
			
			if(file_read==true && file_select == true)
			   { File_num++; // file selection counter 
			     file_read=false;file_select =false;}
			if(File_num==1)
			  TabpageFile1(gcnew FileInfo(openFileDialog1->FileName),Trace_file_is_known);
			else if(File_num==2)
			  TabpageFile2(gcnew FileInfo(openFileDialog1->FileName),Trace_file_is_known);
                else if(File_num>=3)
				{ TabpageFile3(gcnew FileInfo(openFileDialog1->FileName),Trace_file_is_known);
					File_num=0;}// for using tabpages in continuing form 

		   this->radioButton_Fileselect->Enabled=false;
		   this->radioButton_Startanalysis->Enabled=true;
		   this->radioButton_Startanalysis->Checked=true;
		   this->radioButton_Perfoprmance->Enabled=false;
		   this->radioButton_Results_save->Enabled=false;
		   this->radioButton_Read_error->Enabled=false;
		   this->radioButton_Read_error->Checked=false;
		}
		if(Trace_file_is_known==0)MessageBox::Show("This is not a Trace File","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Exclamation);
		}
		// In case of Error such file can't Open
		catch(FileNotFoundException^ ex)
		{
			MessageBox::Show("No File has been Selected or File Error","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Error);
			this->radioButton_Read_error->Enabled=true;
			this->radioButton_Read_error->Checked=true;
		}
		catch(System::Exception^ e)
		{
			MessageBox::Show(" Could be there is an Error or No File has been Selected ","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Error);
		    this->radioButton_Read_error->Enabled=true;
		    this->radioButton_Read_error->Checked=true;
		}
		//}
		//else // if cancel is pressed from the open file dialog return with doing nothing
		 //  return; 
		}

void TabpageFile1(FileInfo^ pFileProps, int Trace_file){
      if(Trace_file==1)
		this->label_Unknown_1->Text=" Old  ";
		else if(Trace_file==2)
			this->label_Unknown_1->Text=" Tagged";
		    else if (Trace_file==3)
			   this->label_Unknown_1->Text=" New  ";

	this->checkBox_Filename_1->Checked = true;
	this->label_Filename_1->Text=String::Concat(pFileProps->Name);
	this->label_analysis_time_1->Text=System::Convert::ToString(System::DateTime::Now);// print  time
	
	if(this->checkBox_PDF->Checked == true)				
	{this->checkBox_PDF_1->Checked = true;
	 this->label9->Text=System::Convert::ToString(PDF);
	 this->progressBar2->Value= PDF;}
	
	if(this->checkBox_NRL->Checked == true)			
	{this->checkBox_NRL_1->Checked = true;
	this->label10->Text=System::Convert::ToString(NRL);
	this->progressBar7->Value=NRL*10;} // x 100 to seen clearly the progressbar 
	
	if(this->checkBox_EED->Checked == true)			
	{this->label11->Text=System::Convert::ToString(EEDelay*1000);
	this->checkBox_EED_1->Checked = true;
	this->progressBar10->Value=EEDelay*1000;}
	
	if(this->checkBox_Throughput->Checked == true)			
	{this->label111->Text=System::Convert::ToString(Throughput);
	this->checkBox_Throughput_1->Checked = true;
	this->progressBar16->Value=Throughput;}
	
	if(this->checkBox_SentPkt->Checked == true)			
	{this->label12->Text=System::Convert::ToString(Total_Sent_Pkt);
	 this->checkBox_Sent_1->Checked = true;}
	
	if(this->checkBox_RecvPkt->Checked == true)			
	{this->label13->Text=System::Convert::ToString(Total_Received_Pkt);
	this->checkBox_Receive_1->Checked = true;}
	
	if(this->checkBox_DropPkt->Checked == true)			 
	{this->label14->Text=System::Convert::ToString(Total_Dropped_Packets);
	this->checkBox_Drppks_1->Checked = true;
	this->progressBar19->Value=Total_Dropped_Packets;}
	
	if(this->checkBox_DropBytes->Checked == true)			
	{this->label15->Text=System::Convert::ToString(Total_Dropped_Bytes);
	this->checkBox_DrpByts_1->Checked = true;}
	
	if(this->checkBox_LostPkt->Checked == true)			
	{this->label16->Text=System::Convert::ToString(Total_lost);
	this->checkBox_Lostpkt_1->Checked = true;}
	 

	if(this->checkBox_RoutingPkt->Checked == true)			
	{this->label17->Text=System::Convert::ToString(Control_Total_pkt);
	this->checkBox_Overh_1->Checked = true;
	this->progressBar13->Value=Control_Total_pkt;}

	if(this->checkBox_SimTime->Checked == true)			
	{this->label18->Text=System::Convert::ToString(Simulation_Packet_Counter);
	this->checkBox_Simtime_1->Checked = true;}
	this->label_analysis_time_1->Text=System::Convert::ToString(System::DateTime::Now);// print  time
}
void TabpageFile2(FileInfo^ pFileProps, int Trace_file){
	
	if(Trace_file==1)
		this->label_Unknown_2->Text=" Old  ";
		else if(Trace_file==2)
			  this->label_Unknown_2->Text=" Tagged";
		    else if (Trace_file==3)
			   this->label_Unknown_2->Text=" New  ";

	this->label_Filename_2->Text=String::Concat(pFileProps->Name);
	this->label_analysis_time_2->Text=System::Convert::ToString(System::DateTime::Now);// print  time
	
	if(this->checkBox_PDF->Checked == true)				
	{this->checkBox_PDF_2->Checked = true;
	this->label95->Text=System::Convert::ToString(PDF);
	this->progressBar3->Value=PDF;}
	
	if(this->checkBox_NRL->Checked == true)			
	{this->label94->Text=System::Convert::ToString(NRL); 
	this->checkBox_NRL_2->Checked = true;
	this->progressBar6->Value=NRL*10;}// x 100 to be seen clearly the progressbar 
	
	if(this->checkBox_Throughput->Checked == true)			
	{this->label112->Text=System::Convert::ToString(Throughput);
	this->checkBox_Throughput_2->Checked = true;
	this->progressBar15->Value=Throughput;}
	
	if(this->checkBox_EED->Checked == true)			
	{this->label93->Text=System::Convert::ToString(EEDelay*1000);
	this->checkBox_EED_2->Checked = true;
	this->progressBar9->Value=EEDelay*1000;}
	
	if(this->checkBox_SentPkt->Checked == true)			
	{this->label92->Text=System::Convert::ToString(Total_Sent_Pkt);
	 this->checkBox_Sent_2->Checked = true;}
	
	if(this->checkBox_RecvPkt->Checked == true)			
	{this->label91->Text=System::Convert::ToString(Total_Received_Pkt);
	this->checkBox_Receive_2->Checked = true;}
	
	if(this->checkBox_DropPkt->Checked == true)			 
	{this->label90->Text=System::Convert::ToString(Total_Dropped_Packets);
	this->checkBox_Drppks_2->Checked = true;
	this->progressBar18->Value=Total_Dropped_Packets;}
	
	if(this->checkBox_DropBytes->Checked == true)			
	{this->label89->Text=System::Convert::ToString(Total_Dropped_Bytes);
	this->checkBox_DrpByts_2->Checked = true;}
	
	if(this->checkBox_LostPkt->Checked == true)			
	{this->label88->Text=System::Convert::ToString(Total_lost);
	this->checkBox_Lostpkt_2->Checked = true;}
	
	if(this->checkBox_RoutingPkt->Checked == true)			
	{this->label87->Text=System::Convert::ToString(Control_Total_pkt);
	this->checkBox_Overh_2->Checked = true;
	this->progressBar12->Value=Control_Total_pkt;}
	
	if(this->checkBox_SimTime->Checked == true)			
	{this->label86->Text=System::Convert::ToString(Simulation_Packet_Counter);
	this->checkBox_Simtime_2->Checked = true;}
	this->label_analysis_time_2->Text=System::Convert::ToString(System::DateTime::Now);// print  time
}
void TabpageFile3(FileInfo^ pFileProps, int Trace_file){
      if(Trace_file==1)
		this->label_Unknown_3->Text=" Old  ";
		else if(Trace_file==2)
			this->label_Unknown_3->Text=" Tagged";
		    else if (Trace_file==3)
			   this->label_Unknown_3->Text=" New  ";
	
	this->label_Filename_3->Text=String::Concat(pFileProps->Name);
	this->label_analysis_time_3->Text=System::Convert::ToString(System::DateTime::Now);// print  time
	
	if(this->checkBox_PDF->Checked == true)				
	{this->checkBox_PDF_3->Checked = true;
	this->label122->Text=System::Convert::ToString(PDF);
	 this->progressBar4->Value=PDF;}
	
	if(this->checkBox_NRL->Checked == true)			
	{this->checkBox_NRL_3->Checked = true;
	this->label121->Text=System::Convert::ToString(NRL);
	this->progressBar5->Value=NRL*10;}// x 100 to be seen clearly  the progressbar 
	
    if(this->checkBox_Throughput->Checked == true)			
	{this->label123->Text=System::Convert::ToString(Throughput);
	this->checkBox_Throughput_3->Checked = true;
	this->progressBar14->Value=Throughput;}
	
	if(this->checkBox_EED->Checked == true)			
	{this->label120->Text=System::Convert::ToString(EEDelay*1000);
	this->checkBox_EED_3->Checked = true;
	this->progressBar8->Value=EEDelay*1000;}
	
	if(this->checkBox_SentPkt->Checked == true)			
	{this->label119->Text=System::Convert::ToString(Total_Sent_Pkt);
	 this->checkBox_Sent_3->Checked = true;}
	
	if(this->checkBox_RecvPkt->Checked == true)			
	{this->label118->Text=System::Convert::ToString(Total_Received_Pkt);
	this->checkBox_Receive_3->Checked = true;}
	
	if(this->checkBox_DropPkt->Checked == true)			 
	{this->label117->Text=System::Convert::ToString(Total_Dropped_Packets);
	this->checkBox_Drppks_3->Checked = true;
	this->progressBar17->Value=Total_Dropped_Packets;}
	
	if(this->checkBox_DropBytes->Checked == true)			
	{this->label116->Text=System::Convert::ToString(Total_Dropped_Bytes);
	this->checkBox_DrpByts_3->Checked = true;}
	
	if(this->checkBox_LostPkt->Checked == true)			
	{this->label115->Text=System::Convert::ToString(Total_lost);
	this->checkBox_Lostpkt_3->Checked = true;}

	if(this->checkBox_RoutingPkt->Checked == true)			
	{this->label114->Text=System::Convert::ToString(Control_Total_pkt);
	this->checkBox_Overh_3->Checked = true;
	this->progressBar11->Value=Control_Total_pkt;}

	if(this->checkBox_SimTime->Checked == true)			
	{this->label113->Text=System::Convert::ToString(Simulation_Packet_Counter);
	this->checkBox_Simtime_3->Checked = true;}
	this->label_analysis_time_3->Text=System::Convert::ToString(System::DateTime::Now);// print  time
}

private: System::Void tabControl1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Perormance_Comparison_button_Click(System::Object^  sender, System::EventArgs^  e) {
	this->ClientSize = System::Drawing::Size(1118, 765);
	this->progressBar1->Value=0;
	this->groupBox_Results_graphics->Visible=true;
	this->radioButton_Fileselect->Enabled=false;
    this->radioButton_Startanalysis->Enabled=false;
    this->radioButton_Perfoprmance->Enabled=true;
	this->radioButton_Perfoprmance->Checked=true;
    this->radioButton_Results_save->Enabled=false;
}

private: System::Void progressBar19_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void progressBar13_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void richTextBox4_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void tabPage11_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void progressBar7_Click(System::Object^  sender, System::EventArgs^  e) {
		 }

private: System::Void savetoolStripMenuItem_Click_1(System::Object^  sender, System::EventArgs^  e) {
// This shows you how to create and to write to a text file.
// Displays an OpenFileDialog so the user can select a Cursor.
    
   String^ folderName; 
   FolderBrowserDialog^ folderBrowserDialog1 = gcnew FolderBrowserDialog();    
   folderName = folderBrowserDialog1->SelectedPath;

   if (folderBrowserDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   {    
	   folderName = folderBrowserDialog1->SelectedPath;
	   String^ path = String::Concat(folderName,"\\Trace_file_analysis.txt");
	   // StreamWriter^ pwriter = gcnew StreamWriter(Path_);
  
	// This text is added only once to the file.
 /*  if (  !File::Exists( path ) )
      // Create a file to write to.
      StreamWriter^ pwriter = File::CreateText( path );
     
   else  */
   // This text is always added, making the file longer over time
   // if it is not deleted.
   StreamWriter^ pwriter = File::AppendText( path );
   try
   {
		//pwriter->WriteLine("The file was created by using the StreamWriter class.");
			pwriter->WriteLine(startTime);
            if(this->checkBox_PDF->Checked == true)			
			  pwriter->WriteLine(PDF);
			if(this->checkBox_NRL->Checked == true)			
              pwriter->WriteLine(NRL);
			if(this->checkBox_EED->Checked == true)			
			  pwriter->WriteLine(EEDelay*1000); // miliseconds
			if(this->checkBox_Throughput->Checked == true)	
              pwriter->WriteLine(Throughput);
			if(this->checkBox_SentPkt->Checked == true)			
		      pwriter->WriteLine(Total_Sent_Pkt);
			if(this->checkBox_RecvPkt->Checked == true)			
  			  pwriter->WriteLine(Total_Received_Pkt);
			if(this->checkBox_DropPkt->Checked == true)			 
			  pwriter->WriteLine(Total_Dropped_Packets);
			if(this->checkBox_DropBytes->Checked == true)			
              pwriter->WriteLine(PDF);Total_Dropped_Bytes;
			if(this->checkBox_LostPkt->Checked == true)			
              pwriter->WriteLine(Total_lost);
			if(this->checkBox_RoutingPkt->Checked == true)			
			  pwriter->WriteLine(Control_Total_pkt);
            if(this->checkBox_SimTime->Checked == true)			
              pwriter->WriteLine(Simulation_Packet_Counter);
			  pwriter->WriteLine(stopTime);
			  pwriter->WriteLine("=================================================================="); // print date, time
pwriter->Close();
   
	this->radioButton_Fileselect->Enabled=false;
    this->radioButton_Startanalysis->Enabled=false;
    this->radioButton_Perfoprmance->Enabled=false;
    this->radioButton_Results_save->Enabled=true;
	this->radioButton_Results_save->Checked=true;
//listBox1->Items->Clear();
//String^ filew = gcnew String("Ok the data written to c:\\Trace_file_analysis.txt  File " );
    listBox1->Items->Add("The data ( Successfully ) saved into this File : ");
	listBox1->Items->Add(path);
   }
   finally
   {
      if ( pwriter)
         delete (IDisposable^)pwriter;
   }


 }
		 }
private: System::Void Tab_Pages_clear_button_Click(System::Object^  sender, System::EventArgs^  e) {
this->groupBox_Results_graphics->Visible=false;
this->ClientSize = System::Drawing::Size(606, 765);
File1_tabpage_clear();
File2_tabpage_clear();
File3_tabpage_clear(); 
File_num=0;		 
		 }

void File1_tabpage_clear()
{
	this->label_Filename_1->Text=" ";
    this->label_Unknown_1->Text="Unkown";
	this->label_analysis_time_1->Text="00:00:00";
 
	this->label9->Text=" ";
	this->progressBar2->Value=0;
	this->checkBox_PDF_1->Checked = false;	 
	 		
	this->checkBox_NRL_1->Checked = false;
	this->label10->Text="         ";
	this->progressBar7->Value=0;	
	 
	this->label11->Text=" ";
	this->checkBox_EED_1->Checked = false;
	this->progressBar10->Value=0; 

	this->label111->Text=" ";
	this->checkBox_Throughput_1->Checked = false;
	this->progressBar16->Value=0;

	this->label12->Text=" ";
	this->checkBox_Sent_1->Checked = false; 
	
	this->label13->Text=" ";
	this->checkBox_Receive_1->Checked = false; 
	 		 
	this->label14->Text=" ";
	this->checkBox_Drppks_1->Checked = false;
	this->progressBar19->Value=0; 
			
	this->label15->Text=" ";
	this->checkBox_DrpByts_1->Checked = false;
	
	this->label16->Text=" ";
	this->checkBox_Lostpkt_1->Checked = false;
	this->progressBar16->Value=0;
		
	this->label17->Text=" ";
	this->checkBox_Overh_1->Checked = false;
	this->progressBar13->Value=0;

	this->label18->Text=" ";
	this->checkBox_Simtime_1->Checked = false; 	  
		 }

void File2_tabpage_clear()
{
	this->label_Filename_2->Text=" ";
    this->label_Unknown_2->Text="Unkown";
	this->label_analysis_time_2->Text="00:00:00";
 
	this->label95->Text=" ";
	this->progressBar3->Value=0;
	this->checkBox_PDF_2->Checked = false;
	 		
	this->checkBox_NRL_2->Checked = false;
	this->label94->Text="         ";
	this->progressBar6->Value=0;	
	 
	this->label93->Text=" ";
	this->checkBox_EED_2->Checked = false;
	this->progressBar9->Value=0; 
	
	this->label112->Text=" ";
	this->checkBox_Throughput_2->Checked = false;
	this->progressBar15->Value=0;

	this->label92->Text=" ";
	this->checkBox_Sent_2->Checked = false; 
	
	this->label91->Text=" ";
	this->checkBox_Receive_2->Checked = false; 
	
	this->label87->Text=" ";
	this->checkBox_Overh_2->Checked = false;
	this->progressBar12->Value=0; 
		
	this->label89->Text=" ";
	this->checkBox_DrpByts_2->Checked = false;
	
	this->label88->Text=" ";
	this->checkBox_Lostpkt_2->Checked = false;
	this->progressBar15->Value=0;
		
	this->label90->Text=" ";
	this->checkBox_Drppks_2->Checked = false;
	this->progressBar18->Value=0; 

	this->label86->Text=" ";
	this->checkBox_Simtime_2->Checked = false; 	 
		 }
void File3_tabpage_clear()
{
	this->label_Unknown_3->Text="Unkown";
	this->label_Filename_3->Text=" ";
	this->label_analysis_time_3->Text="00:00:00";
	
	this->label122->Text=" ";
	this->progressBar4->Value=0;
			
	this->label121->Text=" ";
	this->progressBar5->Value=0;
	
	this->label120->Text=" ";
	this->checkBox_EED_3->Checked = false;
	this->progressBar8->Value=0;
	
	this->label123->Text=" ";
	this->checkBox_Throughput_3->Checked = false;
	this->progressBar14->Value=0;	

	this->label119->Text=" ";
	this->checkBox_Sent_3->Checked = false; 
	 			
	this->label118->Text=" ";
	this->checkBox_Receive_3->Checked = false; 
	 	 
	this->label117->Text=" ";
	this->checkBox_Drppks_3->Checked = false;
	this->progressBar17->Value=0;
	
	this->label116->Text=" ";
	this->checkBox_DrpByts_3->Checked = false;
	 			
	this->label115->Text=" ";
	this->checkBox_Lostpkt_3->Checked = false;
	this->progressBar14->Value=0; 

	this->label114->Text=" ";
	this->checkBox_Overh_3->Checked = false;
	this->progressBar11->Value=0;
	
	this->label113->Text=" ";
	this->checkBox_Simtime_3->Checked = false;  
	 }
private: System::Void OpentoolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

this->groupBox_Results_graphics->Visible=false;
this->ClientSize = System::Drawing::Size(606, 765);
int Line_counter=0; // how many Lines	
this->progressBar1->Value=0;
listBox1->Items->Clear(); // clear listBox1
label_Record->Text="0";openFileDialog1->Filter = "Trace Files|*.tr|Text File|*.txt";
openFileDialog1->Title = "Select a Trace or Text File";
openFileDialog1->FileName =" ";	 
      // Show the Dialog.
      // If the user clicked OK in the dialog and
      // a .CUR file was selected, open it.
   if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   {  
	 //MessageBox::Show("The File has been Selected SUCCESSULLY","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Information);
	   try {
		// Open the selected file openFileDialog1->FileName
		StreamReader^ reader = gcnew StreamReader(openFileDialog1->FileName); 
		progressBar1->Value=0;
		double Maximum_size=File_size(gcnew FileInfo(openFileDialog1->FileName));
		   if(Maximum_size>=999999)
			   Maximum_size=Maximum_size/100;
		   else if (Maximum_size>=99999)
			   Maximum_size=Maximum_size/10;
        progressBar1->Maximum=Maximum_size/2; 
		do
		{
				//String ^str1= System::Convert::ToString(reader->ReadLine());
				listBox1->Items->Add(System::Convert::ToString(reader->ReadLine()));
				this->progressBar1->Value=progressBar1->Value+1;
                 if(this->progressBar1->Value>=progressBar1->Maximum)
					 progressBar1->Value=0;
              Line_counter++; // how many Lines	

      	}while(reader->Peek() != -1);  // this while is for do, it means the EOF
		reader->Close(); // close the file
		this->progressBar1->Value=progressBar1->Maximum;
        if(this->checkBox_Records->Checked == true) 
		  label_Record->Text=Line_counter.ToString();
	    else label_Record->Text="0";
	   }
	   catch(FileNotFoundException^ ex){MessageBox::Show("No File has been Selected or File Error","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Error);}
	   catch(System::Exception^ e){MessageBox::Show(" Could be there is an Error","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Error);}
   }
   else // if cancel is pressed from the open file dialog return with doing nothing
    MessageBox::Show("No File has been Selected","Message Box",MessageBoxButtons::OK,MessageBoxIcon::Hand);
		 }
private: System::Void resultsTabPagesToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(this->resultsTabPagesToolStripMenuItem->Checked==true)
			   {this->tabControl1->Visible=true;
                this->groupBox_Results_graphics->Visible=false;
				this->performanceProgressToolStripMenuItem->Checked=false;
				this->ClientSize = System::Drawing::Size(606, 765);
			    if(this->textBoardToolStripMenuItem->Checked==true)
			     {this->tabControl1->Location = System::Drawing::Point(271, 80);
			      this->tabControl1->Size = System::Drawing::Size(322, 299); 
			      this->listBox1->Location = System::Drawing::Point(271, 385);
				  this->listBox1->Size = System::Drawing::Size(319, 316);
			      }
			  else
			  { this->tabControl1->Location = System::Drawing::Point(271, 80);
			  this->tabControl1->Size = System::Drawing::Size(322, 621);}
			 }
			 else 
			 {this->tabControl1->Visible=false;
			  if(this->textBoardToolStripMenuItem->Checked==true)
			     {this->listBox1->Size = System::Drawing::Size(319, 615);
			     this->listBox1->Location = System::Drawing::Point(271, 86);}
			  else
			  { this->tabControl1->Location = System::Drawing::Point(271, 80);
			  this->tabControl1->Size = System::Drawing::Size(30022, 621);}
			 }

			  if(resultsTabPagesToolStripMenuItem->Checked==false && textBoardToolStripMenuItem->Checked==false)
			   {checkBox_Records->Visible=false;
			    label_Record->Visible=false;
				progressBar1->Visible=false;  
			    if(this->performanceProgressToolStripMenuItem->Checked==true)
			     {this->groupBox_Results_graphics->Location= System::Drawing::Point(270,72);
				  this->groupBox_Results_graphics->Size= System::Drawing::Size(512,682);	
				  this->ClientSize = System::Drawing::Size(812, 765);}
			   }
			 else
				{checkBox_Records->Visible=true;
				 label_Record->Visible=true;
				 progressBar1->Visible=true;}
show_Menu_Only();
		 }
private: System::Void textBoardToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(this->textBoardToolStripMenuItem->Checked==true)
			 {listBox1->Visible=true;
			  this->groupBox_Results_graphics->Visible=false;
			  this->performanceProgressToolStripMenuItem->Checked=false;
			  this->ClientSize = System::Drawing::Size(606, 765);
			   if(resultsTabPagesToolStripMenuItem->Checked==true)
			   {this->tabControl1->Location = System::Drawing::Point(271, 80);
			      this->tabControl1->Size = System::Drawing::Size(322, 299); 
			      this->listBox1->Location = System::Drawing::Point(271, 385);
				  this->listBox1->Size = System::Drawing::Size(319, 316);}
			  else
			  { this->listBox1->Location = System::Drawing::Point(271, 86);
			   this->listBox1->Size = System::Drawing::Size(319, 615);}
			 }
			 else 
			 {this->listBox1->Visible=false;
             this->tabControl1->Location = System::Drawing::Point(271, 80);
			 this->tabControl1->Size = System::Drawing::Size(322, 621);
			 }
           	
			 
			  if(resultsTabPagesToolStripMenuItem->Checked==false && textBoardToolStripMenuItem->Checked==false)
			   {checkBox_Records->Visible=false;
			    label_Record->Visible=false;
				progressBar1->Visible=false;  
			    if(this->performanceProgressToolStripMenuItem->Checked==true)
			     {this->groupBox_Results_graphics->Location= System::Drawing::Point(270,72);
				  this->groupBox_Results_graphics->Size= System::Drawing::Size(512,682);	
				  this->ClientSize = System::Drawing::Size(812, 765);}
			   }
			 else
				{checkBox_Records->Visible=true;
				 label_Record->Visible=true;
				 progressBar1->Visible=true;}

		show_Menu_Only();	  
		 }
private: System::Void performanceProgressToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(this->performanceProgressToolStripMenuItem->Checked==true)
			 {this->groupBox_Results_graphics->Visible=true;
			    if(resultsTabPagesToolStripMenuItem->Checked==false && textBoardToolStripMenuItem->Checked==false)
				  {this->groupBox_Results_graphics->Location= System::Drawing::Point(270,72);
				  this->groupBox_Results_graphics->Size= System::Drawing::Size(512,682);	
				  this->ClientSize = System::Drawing::Size(812, 765);}
				else{this->groupBox_Results_graphics->Location= System::Drawing::Point(597, 24);
				   this->ClientSize = System::Drawing::Size(1127, 765);}
			 }else{
				this->groupBox_Results_graphics->Visible=false;
				this->ClientSize = System::Drawing::Size(606, 765);
			  }
          show_Menu_Only();
		 }
//private: System::Void performanceProgressToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
//		 }


 void show_Menu_Only(){
    if(resultsTabPagesToolStripMenuItem->Checked==false && textBoardToolStripMenuItem->Checked==false&&
    systemTimeToolStripMenuItem->Checked==false && performanceProgressToolStripMenuItem->Checked ==false )
    this->ClientSize = System::Drawing::Size(276, 801); 
 }
private: System::Void systemTimeToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
          
			 if(this->systemTimeToolStripMenuItem->Checked==true)
			 {this->groupBox_SystemTime->Visible=true;
			 this->ClientSize = System::Drawing::Size(606, 765);
			 }
			 else
				 this->groupBox_SystemTime->Visible=false;

			 if(resultsTabPagesToolStripMenuItem->Checked==false && textBoardToolStripMenuItem->Checked==false&&
				 systemTimeToolStripMenuItem->Checked==false && performanceProgressToolStripMenuItem->Checked ==false )
		        this->ClientSize = System::Drawing::Size(276, 801); 
		 }
private: System::Void saveAsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
// Displays a SaveFileDialog so the user can save the Image
      // assigned to Button2.
      SaveFileDialog ^ saveFileDialog1 = gcnew  SaveFileDialog();
      saveFileDialog1->Filter = "Text File|*.txt";
      saveFileDialog1->Title = "Save File as";
     // saveFileDialog1->ShowDialog();

if (saveFileDialog1->ShowDialog() != System::Windows::Forms::DialogResult::Cancel)
{
      // If the file name is not an empty string, open it for saving.
	  StreamWriter^ pwriter = gcnew StreamWriter(saveFileDialog1->FileName);
            //pwriter->WriteLine("The file was created by using the StreamWriter class.");
	  pwriter->Write(startTime);
            //if(this->checkBox_PDF->Checked == true)			
			  pwriter->Write(PDF);
			//if(this->checkBox_NRL->Checked == true)			
              pwriter->Write(NRL);
			//if(this->checkBox_EED->Checked == true)			
			  pwriter->Write(EEDelay*1000); // miliseconds
			//if(this->checkBox_Throughput->Checked == true)	
              pwriter->Write(Throughput);
			//if(this->checkBox_SentPkt->Checked == true)			
		      pwriter->Write(Total_Sent_Pkt);
			//if(this->checkBox_RecvPkt->Checked == true)			
  			  pwriter->Write(Total_Received_Pkt);
			//if(this->checkBox_DropPkt->Checked == true)			 
			  pwriter->Write(Total_Dropped_Packets);
			//if(this->checkBox_DropBytes->Checked == true)			
              pwriter->Write(Total_Dropped_Bytes);
			//if(this->checkBox_LostPkt->Checked == true)			
              pwriter->Write(Total_lost);
			//if(this->checkBox_RoutingPkt->Checked == true)			
			  pwriter->Write(Control_Total_pkt);
			//if(this->checkBox_SimTime->Checked == true)			
              pwriter->Write(Simulation_Packet_Counter);
			  pwriter->Write(stopTime);
			  pwriter->WriteLine("=================================================================="); // print date, time
pwriter->Close();
	this->radioButton_Fileselect->Enabled=false;
    this->radioButton_Startanalysis->Enabled=false;
    this->radioButton_Perfoprmance->Enabled=false;
    this->radioButton_Results_save->Enabled=true;
	  this->radioButton_write_error->Enabled=false;
//listBox1->Items->Clear();
//String^ filew = gcnew String(Direcory_"Ok the data written to c:\\Trace_file_analysis.txt  File " );
	listBox1->Items->Add("The data ( Successfully ) saved into this File : ");
	listBox1->Items->Add(saveFileDialog1->FileName);
   }
else
{this->radioButton_Fileselect->Enabled=false;
    this->radioButton_Startanalysis->Enabled=false;
    this->radioButton_Perfoprmance->Enabled=false;
    this->radioButton_Results_save->Enabled=false;
	this->radioButton_write_error->Enabled=true;
	this->radioButton_write_error->Checked=true;}
 }	 
 
private: System::Void performanceProgressToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void resultsTabPagesToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label126_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

