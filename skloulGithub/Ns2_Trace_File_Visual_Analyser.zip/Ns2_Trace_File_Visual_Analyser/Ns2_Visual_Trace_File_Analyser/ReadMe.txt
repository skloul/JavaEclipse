========================================================================
    APPLICATION : Ns2_Visual_Trace_File_Analyser Project Overview
========================================================================

AppWizard has created this Ns2_Visual_Trace_File_Analyser Application for you.  

This file contains a summary of what you will find in each of the files that
make up your Ns2_Visual_Trace_File_Analyser application.

Ns2_Visual_Trace_File_Analyser.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Ns2_Visual_Trace_File_Analyser.cpp
    This is the main application source file.
    Contains the code to display the form.

Form1.h
    Contains the implementation of your form class and InitializeComponent() function.

AssemblyInfo.cpp
    Contains custom attributes for modifying assembly metadata.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named Ns2_Visual_Trace_File_Analyser.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
